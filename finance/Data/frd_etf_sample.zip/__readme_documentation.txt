Complete ETF Historical Dataset
================================== 

NOTE: Only intraday-bars with trading volume are included. Bars with zero volume are excluded.

Timeframes : 1-minute, 5-minutes, 30-minutes, 1-hour, 1-day


Adjustments
------------

We provide three types of data:
Unadjusted - actual historic traded prices with no adjustments (only the 1-minute and 1-day timeframes are available for unadjusted data)
Split Adjusted - prices adjusted for stock splits and reverse splits only
Split+Dividend Adjusted - prices adjusted for both splits and dividends

More details on the adjustment process is at https://firstratedata.com/about/price_adjustment


Format
-------
Data is in the format : { DateTime (yyyy-MM-dd HH:mm:ss), Open, High, Low, Close, Volume}  

- Volume Numbers are in individual shares
- Timestamps run from the start of the period (eg 1min bars stamped 09:30 run from 09:30.00 to 09:30.59)
- Times with zero volume are omitted (thus gaps in the data sequence are when there have been no trades)


Updates
-------
This dataset is updated daily (update files are available by 11.45pm US Eastern time and 3am the following day for the full historical archive files). 

New ETF tickers are added at the end of every week.

 

Notes
-----
 
- Timezone is US Eastern Time    
- Excel will usually fail to open large files directly. 
  To use the data in Excel, open the files using notepad and then break into smaller files or copy/paste into Excel 
- Data license is available at https://firstratedata.com/about/license
 
   
Sample Data
-------
 
2 weeks of sample data is included for IWM, QQQ, SPY
 
 
 
Tickers (total tickers : 5117)
--------
All tickers updated to 2026-04-09
 
AAA (Listed Funds Trust Aaf First Priority Clo Bond ETF) Start Date:2020-09-09
AAAU (Perth Mint Physical Gold ETF) Start Date:2018-08-15
AADR (AdvisorShares Dorsey Wright ADR ETF) Start Date:2010-07-21
AAPB (Graniteshares 1.75X Long Aapl Daily ETF) Start Date:2022-08-09
AAPD (Direxion Daily Aapl Bear 1X Shares) Start Date:2022-08-09
AAPR (Shl Telemedicine Innovator Equity Defined Protection ETF -) Start Date:2024-04-01
AAPU (Direxion Daily Aapl Bull 1.5X Shares) Start Date:2022-08-09
AAPX (ETF Opportunities Trust T-Rex 2X Long Apple Daily Target ETF) Start Date:2024-01-11
AAPY (Neos ETF Trust Kurv Yield Premium Strategy Apple) Start Date:2023-10-27
AAVM (Alpha Architect Global Factor Equity ETF) Start Date:2017-05-03
AAXJ (iShares MSCI All Country Asia) Start Date:2008-08-15
ABCS (Guggenheim Abc High Dividend Et) Start Date:2023-12-20
ABEQ (Absolute Core Strategy ETF) Start Date:2020-01-22
ABFL (Abacus Fcf Leaders ETF) Start Date:2024-12-13
ABHY (Abacus Tactical High Yield ETF) Start Date:2024-12-13
ABLD (Abacus Fcf Real Assets Leaders ETF) Start Date:2024-12-13
ABLG (Abacus Fcf International Leaders ETF) Start Date:2024-12-13
ABNY (Tidal Trust Ii Yieldmax Abnb Option Income Strategy ETF) Start Date:2024-06-25
ABOT (Abacus Fcf Innovation Leaders ETF) Start Date:2024-12-13
ABXB (Abacus Flexible Bond Leaders ETF) Start Date:2025-06-06
ACES (Alps Clean Energy ETF) Start Date:2018-06-29
ACGR (American Century Large Cap Growth ETF) Start Date:2021-07-01
ACIO (ETF Series Solutions) Start Date:2019-07-10
ACLC (American Century Large Cap Equity ETF) Start Date:2020-07-15
ACSI (American Customer Satisfaction ETF) Start Date:2016-11-01
ACTX (Global X Guru Activist ETF) Start Date:2007-06-11
ACVF (American Conservative Values ETF) Start Date:2020-11-02
ACWF (iShares MSCI Global Multifactor ETF) Start Date:2015-05-04
ACWI (iShares MSCI Acwi Index Fund) Start Date:2008-03-28
ACWV (iShares MSCI Global Min Vol Factor ETF) Start Date:2011-10-20
ACWX (iShares MSCI Acwi Ex U.S. ETF) Start Date:2008-03-31
ADFI (Anfield Dynamic Fixed Income ETF) Start Date:2020-08-18
ADIV (Smartetfs Asia Pacific Dividend Builder ETF) Start Date:2021-03-29
ADME (Aptus Drawdown Managed Equity ETF) Start Date:2019-11-08
ADPV (Series Portfolios Trust Adaptiv Select ETF) Start Date:2022-11-04
ADRE (Invesco Bldrs Emerging Markets 50 ADR Index Fund) Start Date:2002-11-26
ADVE (Matthews International Funds Matthews Asia Dividend Active ETF) Start Date:2023-09-22
AEMB (American Century Emerging Markets Bond ETF) Start Date:2021-07-01
AESR (Anfield U.S. Equity Sector Rotation ETF) Start Date:2019-12-17
AETH (Bitwise Funds Trust Bitwise Ethereum Strategy ETF) Start Date:2023-10-02
AFIF (Two Roads Shared Trust) Start Date:2018-09-18
AFIX (Allspring Exchange-Traded Funds Trust Allspring Broad Market C) Start Date:2024-12-05
AFK (Vaneck Vectors Africa ETF) Start Date:2008-07-14
AFLG (First Trust Active Factor Large Cap ETF) Start Date:2019-12-04
AFMC (First Trust Active Factor Mid Cap ETF) Start Date:2019-12-04
AFSC (Abrdn Focused U.S. Small Cap Active ETF) Start Date:2025-02-18
AFSM (First Trust Active Factor Small Cap ETF) Start Date:2019-12-04
AFTY (Csop FTSE China A50 ETF) Start Date:2015-03-12
AGEM (Egshares Gems Composite ETF) Start Date:2009-07-22
AGG (iShares Barclays Aggregate Bond) Start Date:2003-09-29
AGGH (Simplify Exchange Traded Funds Simplify Aggregate Bond Plus Cr) Start Date:2022-02-15
AGGS (Harbor ETF Trust Harbor Disciplined Bond ETF) Start Date:2024-05-02
AGGY (WisdomTree Barclays Yield Enhanced U.S. Aggregate Bond Fund) Start Date:2015-07-09
AGIH (iShares Us ETF Trust iShares Inflation Hedged Us Aggregate) Start Date:2022-06-24
AGIX (Kraneshares Artificial Intelligence & Technology ETF) Start Date:2024-07-18
AGMI (Themes Silver Miners ETF) Start Date:2024-05-03
AGNG (Global X Aging Population ETF) Start Date:2016-05-10
AGOV (Etc Gavekal Asia Pacific Government Bond ETF) Start Date:2021-07-22
AGOX (Adaptive Alpha Opportunities ETF) Start Date:2021-05-10
AGQ (ProShares Ultra Silver) Start Date:2008-12-04
AGQI (First Trust Exchange-Traded Fund Viii First Trust Active Globa) Start Date:2023-11-21
AGRH (iShares Us ETF Trust iShares Interest Rate Hedged Us Aggre) Start Date:2022-07-01
AGZ (iShares Agency Bond) Start Date:2008-11-11
AGZD (WisdomTree Barclays Intrrthgusaggtbd ETF) Start Date:2013-12-18
AHHX (Adaptive High Income ETF) Start Date:2021-11-15
AHLT (American Beacon Select Funds American Beacon Ahl Trend ETF) Start Date:2023-08-31
AHOY (Tidal ETF Trust Newday Ocean Health ETF) Start Date:2022-06-07
AHYB (American Century Select High Yield ETF) Start Date:2021-11-18
AIA (iShares S&P Asia ETF) Start Date:2007-11-16
AIBD (Direxion Shares ETF Trust Direxion Daily AI And Big Data Bear) Start Date:2024-05-15
AIBU (Direxion Shares ETF Trust Direxion Daily AI And Big Data Bull) Start Date:2024-05-15
AIEQ (Ai Powered Equity ETF) Start Date:2017-10-17
AIFD (Engine No. 1 ETF Trust TCWArtificial Intelligence ETF) Start Date:2024-05-06
AINP (Allspring Exchange-Traded Funds Trust Allspring Income Plus) Start Date:2024-12-09
AIPI (Rex AI Equity Premium Income ETF) Start Date:2024-06-04
AIQ (Global X Future Analytics Tech ETF) Start Date:2018-05-11
AIRL (Themes Airlines ETF) Start Date:2023-12-08
AIRR (First Trust Rba American Industrial Renaissance ETF) Start Date:2014-03-11
AIS (Tidal Trust Iii Vistashares Artificial Intelligence Supercycle) Start Date:2004-09-23
AIVC (Amplify Bloomberg AI Value Chain ETF) Start Date:2024-10-21
AIVI (WisdomTree International AI Enhanced Value Fund) Start Date:2007-05-08
AIVL (WisdomTree U.S. AI Enhanced Value Fund) Start Date:2022-01-18
AIYY (Tidal Trust Ii Yieldmax AI Option Income Strategy ETF) Start Date:2023-11-28
AJAN (Innovator ETFs Trust Innovator Equity Defined Protection ETF -) Start Date:2024-01-02
AJUL (Shl Telemedicine Innovator Equity Defined Protection ETF -) Start Date:2024-07-01
ALAI (The Alger ETF Trust Alger AI Enablers & Adopters ETF) Start Date:2024-04-05
ALLW (SPDR Bridgewater All Weather ETF) Start Date:2025-03-06
ALTL (Rbs Us Large Cap Alternator ETN) Start Date:2020-06-25
ALTY (Global X Superdividend Alternatives ETF) Start Date:2015-07-14
ALUM (Global X Aluminum ETF) Start Date:2011-01-05
AMAX (Rh Hedged Multi-Asset Income ETF) Start Date:2021-11-15
AMDD (Direxion Daily Amd Bear 1X Shares) Start Date:2025-02-12
AMDG (Leverage Shares 2X Long Amd Daily ETF) Start Date:2025-01-24
AMDL (Graniteshares 2X Long Amd Daily ETF) Start Date:2024-03-18
AMDS (Graniteshares 1X Short Amd Daily ETF) Start Date:2023-08-22
AMDY (Tidal Trust Ii Yieldmax Amd Option Income Strategy ETF) Start Date:2023-09-19
AMID (Argent Mid Cap ETF) Start Date:2022-08-17
AMJ (JP Morgan Chase Capital Xvi Jp M) Start Date:2009-04-02
AMJB (JP Morgan Chase & Co. Alerian Mlp Index ETNs Due January 28 20) Start Date:2024-02-05
AMLP (Alerian Mlp ETF) Start Date:2010-08-25
AMNA (Etracs Alerian Midstream Energy Index ETN) Start Date:2020-06-22
AMND (Ubs Ag Etracs Alerian Midstream Energy High Dividend Index ETN) Start Date:2020-07-16
AMOM (Qraft Ai-Enhanced U.S. Large Cap Momentum ETF) Start Date:2019-05-21
AMPD (Return Stacked Bonds & Managed Futures ETF Cnic Ice Us Carbo) Start Date:2023-05-19
AMTR (Etracs Alerian Midstream Energy Total Return Index ETN) Start Date:2020-11-02
AMUB (Ubs Etracs Alerian Mlp Index ETN Series B Due 18 July 2042) Start Date:2015-10-09
AMUU (Direxion Daily Amd Bull 2X Shares) Start Date:2025-04-03
AMZA (Infracap Mlp ETF) Start Date:2014-10-07
AMZD (Direxion Daily Amzn Bear 1X Shares) Start Date:2022-09-07
AMZP (Neos ETF Trust Kurv Yield Premium Strategy Amazon) Start Date:2023-10-31
AMZU (Direxion Daily Amzn Bull 1.5X Shares) Start Date:2022-09-07
AMZY (Tidal ETF Trust Ii Yieldmax Amzn Option Income Strategy ETF) Start Date:2023-07-25
AMZZ (Graniteshares 2X Long Amzn Daily ETF) Start Date:2024-03-18
ANEW (ProShares MSCI Transformational Changes ETF) Start Date:2020-10-16
ANGL (Vaneck Vectors Fallen Angel High Yield Bond ETF) Start Date:2012-04-11
AOA (iShares Core Aggressive Allocation ETF) Start Date:2008-11-12
AOCT (Innovator Equity Defined Protection ETF - 2 Yr To October 2026) Start Date:2024-10-01
AOHY (Angel Oak Funds Trust Angel Oak High Yield Opportunities ETF) Start Date:2024-02-20
AOK (iShares Core Conservative Allocation ETF) Start Date:2008-11-10
AOM (iShares Moderate Allocation ETF) Start Date:2008-11-11
AOR (iShares Core Growth Allocation ETF) Start Date:2008-11-12
AOTG (Aot Growth And Innovation ETF) Start Date:2022-06-29
APCB (Trust For Professional Managers Activepassive Core Bond ETF) Start Date:2023-05-04
APED (Stkd 100% Mstr & 100% Coin ETF) Start Date:2025-03-06
APIE (Trust For Professional Managers Activepassive International Eq) Start Date:2023-05-03
APLU (Allspring Exchange-Traded Funds Trust Allspring Core Plus ETF) Start Date:2024-12-05
APLY (Tidal ETF Trust Ii Yieldmax Aapl Option Income Strategy ETF) Start Date:2023-04-18
APMU (Trust For Professional Managers Activepassive Intermediate Mun) Start Date:2023-05-04
APOC (Innovator Equity Defined Protection ETF - 6Mo Apr/Oct) Start Date:2024-10-01
APRD (Innovator ETFs Trust Innovator Premium Income 10 Barrier ETF -) Start Date:2023-04-03
APRH (Innovator ETFs Trust Innovator Premium Income 20 Barrier ETF -) Start Date:2023-04-03
APRJ (Innovator ETFs Trust Innovator Premium Income 30 Barrier ETF -) Start Date:2007-05-22
APRP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - April) Start Date:2024-04-01
APRQ (Innovator ETFs Trust Innovator Premium Income 40 Barrier ETF -) Start Date:2023-04-03
APRT (Allianzim Us Large Cap Buffer10 Apr ETF) Start Date:2020-06-01
APRW (Allianzim Us Large Cap Buffer20 Apr ETF) Start Date:2020-06-01
APRZ (Trust Trueshares Structured Outcome) Start Date:2021-04-01
APUE (Trust For Professional Managers Activepassive Us Equity ETF) Start Date:2023-05-03
AQGX (Ai Quality Growth ETF) Start Date:2021-11-08
AQWA (Global X Clean Water ETF) Start Date:2021-04-12
ARB (Altshares Merger Arbitrage ETF) Start Date:2020-05-07
ARCM (Arrow Investments Trust) Start Date:2017-03-31
ARGT (Global X MSCI Argentina) Start Date:2011-03-03
ARKA (Ea Series Trust ARK21Shares Active Bitcoin Futures Strategy E) Start Date:2023-11-14
ARKB (ARK21Shares Bitcoin ETF) Start Date:2024-01-11
ARKC (Ea Series Trust ARK21Shares Active On-Chain Bitcoin Strategy) Start Date:2023-11-15
ARKD (Ea Series Trust ARK21Shares Blockchain And Digital Economy In) Start Date:2008-11-10
ARKF (ARKFintech Innovation ETF) Start Date:2019-02-04
ARKG (ARKGenomic Revolution ETF) Start Date:2014-10-31
ARKK (ARKInnovation ETF) Start Date:2014-10-31
ARKQ (ARKIndustrial Innovation ETF) Start Date:2014-09-30
ARKW (ARKNext Generation Internet ETF) Start Date:2014-09-30
ARKX (ARKSpace Exploration & Innovation ETF) Start Date:2021-11-02
ARKY (Ea Series Trust ARK21Shares Active Bitcoin Ethereum Strategy) Start Date:2023-11-15
ARKZ (Ea Series Trust ARK21Shares Active Ethereum Futures Strategy) Start Date:2023-11-14
ARLU (Shl Telemedicine Allianzim Us Equity Buffer15 Uncapped A) Start Date:2024-04-01
ARMG (Leverage Shares 2X Long Arm Daily ETF) Start Date:2025-01-14
ARMR (Armor Us Equity Index ETF) Start Date:2020-02-11
ARP (The Advisors Inner Circle Fund Ii Pmv Adaptive Risk Parity Et) Start Date:2022-12-22
ARTY (iShares Future AI & Tech ETF) Start Date:2024-08-12
ARVR (First Trust Indxx Metaverse ETF) Start Date:2022-04-20
ASEA (Global X FTSE Southeast Asia ETF) Start Date:2011-02-17
ASET (Flexshares Real Assets Allocation ETF) Start Date:2015-11-24
ASHR (Xtrackers Harvest CSI 300 China A-Shares) Start Date:2013-11-06
ASHS (Deutsche X-Trackers Hrvstcsi500chn A Sc) Start Date:2014-05-21
ASHX (Xtrackers MSCI China A Inclusion Equity ETF) Start Date:2015-10-20
ASIA (Matthews International Funds Matthews Pacific Tiger Active ETF) Start Date:2023-10-02
ASMF (Virtus ETF Trust Ii Virtus Alphasimplex Managed Futures ETF) Start Date:2024-05-16
ASMG (Leverage Shares 2X Long Asml Daily ETF) Start Date:2025-01-14
ASPY (Asymshares Asymmetric S&P 500 ETF) Start Date:2021-03-10
ATFV (Alger 35 ETF) Start Date:2021-05-04
ATMP (Barclays ETN+ Select Mlp) Start Date:2013-03-13
AUGP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - August) Start Date:2024-06-11
AUGT (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 Aug E) Start Date:2023-08-01
AUGW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 Aug E) Start Date:2023-08-01
AUGZ (Trueshares Structured Outcome) Start Date:2020-08-03
AUMI (Themes Gold Miners ETF) Start Date:2023-12-13
AUSF (Global X Funds Global X Adaptive U.S. Factor ETF) Start Date:2018-08-28
AVDE (Avantis International Equity ETF) Start Date:2019-09-26
AVDS (American Century ETF Trust Avantis International Small Cap Equ) Start Date:2023-07-20
AVDV (Avantis International Small Cap Value ETF) Start Date:2019-09-26
AVEE (American Century ETF Trust Avantis Emerging Markets Small Cap) Start Date:2023-11-09
AVEM (Avantis Emerging Markets Equity ETF) Start Date:2019-09-19
AVES (Avantis Emerging Markets Value ETF) Start Date:2021-09-30
AVGE (American Century ETF Trust Avantis All Equity Markets ETF) Start Date:2022-09-29
AVGV (American Century ETF Trust Avantis All Equity Markets Value Et) Start Date:2023-06-29
AVGX (Defiance Daily Target 2X Long Avgo ETF) Start Date:2024-08-22
AVIE (American Century ETF Trust Avantis Inflation Focused Equity Et) Start Date:2022-09-29
AVIG (Avantis Core Fixed Income ETF) Start Date:2020-10-15
AVIV (Avantis International Large Cap Value ETF) Start Date:2021-09-30
AVL (Direxion Daily Avgo Bull 2X Shares) Start Date:2024-10-10
AVLC (American Century ETF Trust Avantis Us Large Cap Equity ETF) Start Date:2023-09-28
AVLV (Avantis U.S. Large Cap Value ETF) Start Date:2021-09-23
AVMA (American Century ETF Trust Avantis Moderate Allocation ETF) Start Date:2023-06-29
AVMC (American Century ETF Trust Avantis Us Mid Cap Equity ETF) Start Date:2023-11-09
AVMU (Avantis Core Municipal Fixed Income ETF) Start Date:2020-12-10
AVMV (American Century ETF Trust Avantis Us Mid Cap Value ETF) Start Date:2023-11-09
AVNM (American Century ETF Trust Avantis All International Markets E) Start Date:2023-06-29
AVNV (American Century ETF Trust Avantis All International Markets V) Start Date:2023-06-29
AVRE (Avantis Real Estate ETF) Start Date:2021-09-30
AVS (Direxion Daily Avgo Bear 1X Shares) Start Date:2025-01-02
AVSC (American Century ETF Trust Avantis U.S Small Cap Equity ETF) Start Date:2022-01-13
AVSD (American Century ETF Trust Avantis Responsible International E) Start Date:2022-03-17
AVSE (American Century ETF Trust Avantis Responsible Emerging Market) Start Date:2022-03-30
AVSF (Avantis Short-Term Fixed Income ETF) Start Date:2020-10-15
AVSU (American Century ETF Trust Avantis Responsible Us Equity ETF) Start Date:2022-03-17
AVUS (Avantis U.S. Equity ETF) Start Date:2019-09-26
AVUV (Avantis U.S. Small Cap Value ETF) Start Date:2019-09-26
AVXC (Avantis Emerging Markets Ex-China Equity ETF) Start Date:2024-03-21
AWAY (ETFmg Travel Tech ETF) Start Date:2020-02-13
AWEG (The Alger ETF Trust Alger Weatherbie Enduring Growth ETF) Start Date:2023-03-07
AWYX (ETFmg 2X Daily Travel Tech ETF) Start Date:2021-06-16
AZTD (Tidal ETF Trust Aztlan Global Stock Selection Dm Smid ETF) Start Date:2022-08-18
BAB (Invesco Taxable Municipal Bond ETF) Start Date:2009-11-17
BABO (Tidal Trust Ii Yieldmax Baba Option Income Strategy ETF) Start Date:2024-08-08
BABX (Graniteshares 1.75X Long Baba Daily ETF) Start Date:2022-12-13
BAFE (Brown Advisory Flexible Equity ETF) Start Date:2024-11-18
BAI (Blackrock ETF Trust iShares A.I. Innovation And Tech Active Et) Start Date:2024-10-22
BAL (iPath Bloomberg Cotton Subtr ETN) Start Date:2008-10-01
BALI (Blackrock ETF Trust Blackrock Advantage Large Cap Income ETF) Start Date:2023-09-28
BALT (Innovator Defined Wealth Shield ETF) Start Date:2010-03-10
BAMA (Brookstone Intermediate Bond ETF Brookstone Active ETF) Start Date:2023-10-09
BAMD (Brookstone Intermediate Bond ETF Brookstone Dividend Stock ETF) Start Date:2023-10-03
BAMG (Brookstone Intermediate Bond ETF Brookstone Growth Stock ETF) Start Date:2023-10-03
BAMO (Brookstone Intermediate Bond ETF Brookstone Opportunities ETF) Start Date:2023-10-12
BAMU (Brookstone Intermediate Bond ETF Brookstone Ultra-Short Bond E) Start Date:2023-10-03
BAMV (Brookstone Intermediate Bond ETF Brookstone Value Stock ETF) Start Date:2023-10-03
BAMY (Brookstone Intermediate Bond ETF Brookstone Yield ETF) Start Date:2023-10-12
BAPR (Innovator S&P 500 Buffer ETF) Start Date:2019-04-01
BAR (Graniteshares Gold Trust) Start Date:2017-08-31
BATT (Amplify Lithium & Battery Technology ETF) Start Date:2018-06-06
BAUG (Innovator Us Equity Buffer ETF - August) Start Date:2019-08-01
BBAG (JP Morgan Betabuilders Us Aggregate Bond ETF) Start Date:2023-02-01
BBAX (JP Morgan Betabuilders Developed Asia Ex-Japan ETF) Start Date:2018-08-08
BBBI (Bondbloxx ETF Trust Bondbloxx Bbb Rated 5-10 Year Corporate Bo) Start Date:2024-01-25
BBBL (Bondbloxx ETF Trust Bondbloxx Bbb Rated 10+ Year Corporate Bon) Start Date:2024-01-25
BBBS (Bondbloxx ETF Trust Bondbloxx Bbb Rated 1-5 Year Corporate Bon) Start Date:2024-01-25
BBC (Bioshares Biotechnology Clinical Trials) Start Date:2014-12-17
BBCA (JP Morgan Betabuilders Canada ETF) Start Date:2018-08-08
BBCB (JP Morgan Betabuilders Usd Investment Grade Corporate Bond ETF) Start Date:2023-02-02
BBEM (JP Morgan Exchange-Traded Fund Trust JP Morgan Betabuilders E) Start Date:2023-05-11
BBEU (JP Morgan Betabuilders Europe ETF) Start Date:2018-06-18
BBH (Vaneck Vectors Biotech ETF) Start Date:2016-02-01
BBHY (JP Morgan Betabuilders Usd High Yield Corporate Bond ETF) Start Date:2023-02-01
BBIB (JP Morgan Exchange-Traded Fund Trust JP Morgan Betabuilders U) Start Date:2023-04-20
BBIN (JP Morgan Betabuilders International Equity ETF) Start Date:2019-12-05
BBIP (JP Morgan Exchange-Traded Fund Trust JP Morgan Betabuilders U) Start Date:2023-05-11
BBJP (JP Morgan Betabuilders Japan ETF) Start Date:2018-06-21
BBLB (JP Morgan Exchange-Traded Fund Trust JP Morgan Betabuilders U) Start Date:2023-04-20
BBLU (Ea Series Trust Ea Bridgeway Blue Chip ETF) Start Date:2022-10-17
BBMC (JP Morgan Betabuilders U.S. Mid Cap Equity ETF) Start Date:2020-04-15
BBP (Bioshares Biotechnology Products) Start Date:2014-12-17
BBRE (JP Morgan Betabuilders MSCI Us Reit ETF) Start Date:2018-06-18
BBSA (JP Morgan Betabuilders 1-5 Year Us Aggregate Bd ETF) Start Date:2019-03-13
BBSB (JP Morgan Exchange-Traded Fund Trust JP Morgan Betabuilders U) Start Date:2023-04-20
BBSC (JP Morgan Betabuilders U.S. Small Cap Equity ETF) Start Date:2020-11-17
BBUS (J.P. Morgan Exchange-Traded Fund Trust) Start Date:2019-03-13
BCD (Aberdeen Standard Bloomberg All Commodity Longer Dated Strateg) Start Date:2017-03-31
BCDF (Listed Funds Trust Horizon Kinetics Blockchain Development ETF) Start Date:2022-08-02
BCHI (The 2023 ETF Series Trust Ii Gmo Beyond China ETF) Start Date:2025-02-13
BCHP (Egshares Blue Chip ETF) Start Date:2007-05-22
BCI (Aberdeen Standard Bloomberg All Commodity Strategy K-1 Free ETF) Start Date:2017-03-31
BCIL (Exchange Listed Funds Trust Bancreek International Large Cap E) Start Date:2024-03-21
BCIM (Abrdn Bloomberg Industrial Metals Strategy K-1 Free ETF) Start Date:2021-09-23
BCLO (iShares Bbb-B Clo Active ETF) Start Date:2025-01-30
BCM (iPath Pure Beta Broad Commodity ETN) Start Date:2011-04-21
BCUS (Exchange Listed Funds Trust Bancreek Us Large Cap ETF) Start Date:2023-12-21
BDCX (Etracs Quarterly Pay 1.5X Leveraged Wells Fargo Bdc Index ETN) Start Date:2020-06-03
BDCZ (Etracs Mvis Business Development Companies Index ETN) Start Date:2015-10-09
BDEC (Innovator Us Equity Buffer ETF - December) Start Date:2019-12-02
BDGS (Bridges Capital Tactical ETF) Start Date:2023-05-11
BDIV (ETF Series Solutions Aam Brentview Dividend Growth ETF) Start Date:2024-07-31
BDRY (Breakwave Dry Bulk Shipping ETF) Start Date:2018-03-22
BDVG (Litman Gregory Funds Trust Imgp Berkshire Dividend Growth ETF) Start Date:2023-06-30
BECO (Blackrock Future Climate And Sustainable Economy ETF) Start Date:2021-08-05
BEDZ (AdvisorShares Hotel ETF) Start Date:2021-04-21
BEEZ (Honeytree Us Equity ETF) Start Date:2023-11-08
BELT (Blackrock Long-Term Us Equity ETF) Start Date:2024-06-18
BENJ (Horizon Funds Horizon Landmark ETF) Start Date:2025-01-23
BERZ (Microsectors Fang & Innovation -3X Inverse Leveraged ETN) Start Date:2021-08-18
BETE (ProShares Trust ProShares Bitcoin & Ether Equal Weight Strateg) Start Date:2023-10-02
BETH (ProShares Trust ProShares Bitcoin & Ether Market Cap Weight St) Start Date:2023-10-02
BETZ (Roundhill Sports Betting & Igaming ETF) Start Date:2020-06-04
BFEB (Innovator S&P 500 Buffer ETF February Series) Start Date:2020-02-03
BFIT (Global X Health & Wellness Thematic ETF) Start Date:2016-05-10
BFIX (Build Funds Trust Build Bond Innovation ETF) Start Date:2022-02-10
BFOR (Barron's 400 ETF) Start Date:2013-06-04
BFTR (Blackrock Future Innovators ETF) Start Date:2020-10-01
BGDV (ETF Series Solutions Bahl & Gaynor Dividend ETF) Start Date:2024-12-12
BGIG (ETF Series Solutions Bahl & Gaynor Income Growth ETF) Start Date:2023-09-15
BGLD (FTCboe Vest Gold Strategy Quarterly Buffer ETF) Start Date:2021-01-21
BGRN (iShares Global Green Bond ETF) Start Date:2018-11-27
BGRO (Blackrock Large Cap Growth ETF) Start Date:2024-06-05
BHYB (DBx ETF Trust Xtrackers Usd High Yield Bb-B Ex Financials ETF) Start Date:2023-10-30
BIB (ProShares Ultra Nasdaq Biotechnology) Start Date:2010-04-08
BIBL (Inspire 100 ETF) Start Date:2017-10-31
BICK (First Trust Bick ETF) Start Date:2010-04-13
BIDD (iShares International Dividend Active ETF) Start Date:2024-11-18
BIDS (Amplify Digital & Online Trading ETF) Start Date:2021-09-22
BIL (SPDR Lehman 1-3 Month T-Bill ETF) Start Date:2007-05-30
BILD (Macquarie ETF Trust Macquarie Global Listed Infrastructure ETF) Start Date:2023-11-29
BILS (SPDR Bloomberg 3-12 Month T-Bill ETF) Start Date:2020-09-24
BILZ (Pimco Us Treasury Index Fund Pimco Ultra Short Government Ac) Start Date:2023-06-22
BINC (Blackrock ETF Trust Ii Blackrock Flexible Income ETF) Start Date:2023-05-23
BINV (Brandes International ETF Brandes International ETF) Start Date:2023-10-05
BIS (ProShares Ultrashort Nasdaq Biotech) Start Date:2010-04-08
BITB (Bitwise Bitcoin Etp Trust) Start Date:2024-01-11
BITC (Bitwise Funds Trust Bitwise Bitcoin Strategy Optimum Roll ETF) Start Date:2023-03-21
BITI (ProShares Trust ProShares Short Bitcoin Strategy ETF) Start Date:2022-06-21
BITO (ProShares Bitcoin Strategy ETF) Start Date:2021-10-19
BITQ (Bitwise Crypto Industry Innovators ETF) Start Date:2021-05-12
BITS (Global X Blockchain & Bitcoin Strategy ETF) Start Date:2021-11-16
BITU (ProShares Trust ProShares Ultra Bitcoin ETF) Start Date:2024-04-02
BITX (Volatility Shares Trust 2X Bitcoin Strategy ETF) Start Date:2023-06-27
BIV (Vanguard It Bond ETF) Start Date:2007-04-10
BIZD (Vaneck Vectors Bdc Income ETF) Start Date:2013-02-12
BJAN (Innovator S&P 500 Buffer ETF) Start Date:2019-01-02
BJK (Vaneck Vectors Gaming ETF) Start Date:2008-01-24
BJUL (Innovator S&P 500 Buffer ETF) Start Date:2018-08-29
BJUN (Innovator Us Equity Buffer ETF - June) Start Date:2019-06-03
BKAG (Bny Mellon Core Bond ETF) Start Date:2020-04-24
BKCH (Global X Blockchain ETF) Start Date:2021-07-14
BKCI (Bny Mellon ETF Trust Bny Mellon Concentrated International ETF) Start Date:2021-12-08
BKDV (Bny Mellon ETF Trust Ii Bny Mellon Dynamic Value ETF) Start Date:2024-11-05
BKEM (Bny Mellon Emerging Markets Equity ETF) Start Date:2020-04-24
BKF (iShares MSCI Bric) Start Date:2007-11-16
BKGI (Bny Mellon ETF Trust Bny Mellon Global Infrastructure Income E) Start Date:2022-12-02
BKHY (Bny Mellon High Yield Beta ETF) Start Date:2020-04-24
BKIE (Bny Mellon International Equity ETF) Start Date:2020-04-24
BKIV (Bny Mellon Innovators ETF) Start Date:2023-05-17
BKLC (Bny Mellon Us Large Cap Core Equity ETF) Start Date:2020-04-09
BKLN (PowerShares Exchange-Traded Fund) Start Date:2011-03-03
BKMC (Bny Mellon Us Mid Cap Core Equity ETF) Start Date:2020-04-09
BKSB (Bny Mellon Short Duration Corporate Bond ETF) Start Date:2020-04-24
BKSE (Bny Mellon Us Small Cap Core Equity ETF) Start Date:2020-04-09
BKUI (Bny Mellon Ultra Short Income ETF) Start Date:2021-08-11
BKWO (Bny Mellon Women's Opportunities ETF) Start Date:2023-05-17
BLCN (Reality Shares Nasdaq Nexgen Economy ETF) Start Date:2018-01-17
BLCR (Blackrock Large Cap Core ETF) Start Date:2023-10-26
BLCV (Blackrock ETF Trust Blackrock Large Cap Value ETF) Start Date:2023-05-23
BLDG (Cambria Global Real Estate ETF) Start Date:2020-09-24
BLES (Inspire Global Hope Large Cap ETF) Start Date:2017-02-28
BLHY (Virtus Newfleet Dynamic Credit) Start Date:2016-12-06
BLLD (JP Morgan Sustainable Infrastructure ETF) Start Date:2022-09-08
BLNG (iPath Pure Beta Precious Metal) Start Date:2021-09-20
BLOK (Amplify Transformational Data Sharing ETF) Start Date:2018-01-17
BLV (Vanguard Long-Term Bond ETF) Start Date:2007-04-10
BMAR (Innovator Us Equity Buffer ETF - March) Start Date:2020-03-02
BMAY (Innovator Us Equity Buffer ETF - May) Start Date:2020-05-01
BMDL (Victoryshares Westend Economic Cycle Bond ETF) Start Date:2024-06-21
BMED (Blackrock Future Health ETF) Start Date:2020-10-01
BMVP (Invesco Bloomberg Mvp Multi-Factor ETF) Start Date:2007-04-26
BND (Vanguard Total Bond Market ETF) Start Date:2007-04-10
BNDC (Flexshares Core Select Bond ETF) Start Date:2016-11-21
BNDD (Quadratic Deflation ETF) Start Date:2021-09-21
BNDI (Neos ETF Trust Neos Enhanced Income Aggregate Bond ETF) Start Date:2022-08-30
BNDS (SPDR Blmbg Barclays Aggregate Bond ETF) Start Date:2025-01-15
BNDW (Vanguard Total World Bond ETF) Start Date:2018-09-06
BNDX (Vanguard Total International Bond ETF) Start Date:2013-06-04
BNE (ETF Series Solutions Blue Horizon Bne ETF) Start Date:2020-12-09
BNGE (First Trust S-Network Streaming And Gaming ETF) Start Date:2022-01-26
BNKD (Microsectors U S Big Banks Index 3X Inverse Leveraged ETN) Start Date:2019-04-04
BNKU (Microsectors U S Big Banks Index 3X Leveraged ETN) Start Date:2019-04-03
BNO (United States Brent Oil Fund) Start Date:2010-06-02
BNOV (Innovator Us Equity Buffer ETF - November) Start Date:2019-11-01
BOAT (Sonicshares Global Shipping ETF) Start Date:2021-08-04
BOCT (Innovator S&P 500 Buffer ETF) Start Date:2018-10-01
BOIL (ProShares Ultra Bloomberg Natural Gas) Start Date:2011-10-06
BOND (Pimco Total Return ETF) Start Date:2012-03-01
BOSS (Global X Founder-Run Companies ETF) Start Date:2017-02-15
BOTT (Themes Robotics & Automation ETF) Start Date:2024-04-22
BOTZ (Global X Funds Global X Robotics & Artificial Intelligence ETF) Start Date:2016-09-13
BOUT (Innovator Ibd Breakout Opportunities ETF) Start Date:2018-09-13
BOXX (Ea Series Trust Alpha Architect 1-3 Month Box ETF) Start Date:2022-12-28
BPAY (Blackrock ETF Trust Blackrock Future Financial And Technology) Start Date:2022-08-18
BRAZ (Global X Brazil Mid Cap ETF) Start Date:2023-08-18
BRF (Vaneck Vectors Brazil Small-Cap ETF) Start Date:2009-05-14
BRHY (Blackrock High Yield ETF) Start Date:2024-06-18
BRIF (Neos ETF Trust Fis Bright Portfolios Focused Equity ETF) Start Date:2024-12-27
BRKD (Direxion Daily Brkb Bear 1X Shares) Start Date:2025-01-02
BRKU (Direxion Daily Brkb Bull 2X Shares) Start Date:2024-12-11
BRLN (Blackrock ETF Trust Ii Blackrock Floating Rate Loan ETF) Start Date:2022-10-06
BRNY (Burney Us Factor Rotation ETF) Start Date:2022-10-14
BRRR (Valkyrie Bitcoin Fund) Start Date:2024-01-11
BRTR (Blackrock Total Return ETF) Start Date:2023-12-14
BRZU (Direxion Daily Brazil Bull 2X Shares) Start Date:2013-04-10
BSCE (Guggenheim Bulletshares 2014 Co) Start Date:2018-10-10
BSCN (Invesco Bulletshares 2023 Corporate Bond ETF) Start Date:2014-09-17
BSCO (Invesco Bulletshares 2024 Corporate Bond ETF) Start Date:2014-09-19
BSCP (Guggenheim Bulletshrs 2025 Bd ETF) Start Date:2015-10-09
BSCQ (Invesco Bulletshares 2026 Corporate Bond ETF) Start Date:2016-09-16
BSCR (Invesco Bulletshares 2027 Corporate Bond ETF) Start Date:2017-09-27
BSCS (Invesco Bulletshares 2028 Corporate Bond ETF) Start Date:2018-08-09
BSCT (Invesco Bulletshares 2029 Corporate Bond ETF) Start Date:2019-09-12
BSCU (Invesco Bulletshares 2030 Corporate Bond ETF) Start Date:2020-09-17
BSCV (Invesco Bulletshares 2031 Corporate Bond ETF) Start Date:2021-09-16
BSCW (Invesco Bulletshares 2032 Corporate Bond ETF) Start Date:2022-09-08
BSCX (Invesco Bulletshares 2033 Corporate Bond ETF) Start Date:2023-09-20
BSCY (Invesco Bulletshares 2034 Corporate Bond ETF) Start Date:2024-06-12
BSDE (Invesco Bulletshares 2024 Usd Emerging Markets Debt ETF) Start Date:2018-10-16
BSEA (ETFmg Breakwave Sea Decarbonization Tech ETF) Start Date:2021-09-21
BSEP (Innovator Us Equity Buffer ETF - September) Start Date:2019-09-03
BSJN (Invesco Bulletshares 2023 High Yield Corporate Bond ETF) Start Date:2015-10-14
BSJO (Invesco Bulletshares 2024 High Yield Corporate Bond ETF) Start Date:2016-09-14
BSJP (Invesco Bulletshares 2025 High Yield Corporate Bond ETF) Start Date:2017-09-27
BSJQ (Invesco Bulletshares 2026 High Yield Corporate Bond ETF) Start Date:2018-08-09
BSJR (Invesco Bulletshares 2027 High Yield Corporate Bond ETF) Start Date:2019-09-12
BSJS (Invesco Bulletshares 2028 High Yield Corporate Bond ETF) Start Date:2020-09-16
BSJT (Invesco Bulletshares 2029 High Yield Corporate Bond ETF) Start Date:2021-09-15
BSJU (Invesco Bulletshares 2030 High Yield Corporate Bond ETF) Start Date:2022-09-08
BSJV (Invesco Bulletshares 2031 High Yield Corporate Bond ETF) Start Date:2023-09-20
BSJW (Invesco Bulletshares 2032 High Yield Corporate Bond ETF) Start Date:2024-06-12
BSMC (Brandes International ETF Brandes Us Small-Mid Cap Value ETF) Start Date:2023-10-09
BSMN (Invesco Bulletshares 2023 Municipal Bond ETF) Start Date:2019-09-26
BSMO (Invesco Bulletshares 2024 Municipal Bond ETF) Start Date:2019-09-26
BSMP (Invesco Bulletshares 2025 Municipal Bond ETF) Start Date:2019-09-26
BSMQ (Invesco Bulletshares 2026 Municipal Bond ETF) Start Date:2019-09-26
BSMR (Invesco Bulletshares 2027 Municipal Bond ETF) Start Date:2019-09-26
BSMS (Invesco Bulletshares 2028 Municipal Bond ETF) Start Date:2019-09-26
BSMT (Invesco Bulletshares 2029 Municipal Bond ETF) Start Date:2019-09-25
BSMU (Invesco Bulletshares 2030 Municipal Bond ETF) Start Date:2020-10-12
BSMV (Invesco Bulletshares 2031 Municipal Bond ETF) Start Date:2021-10-27
BSMW (Invesco Bulletshares 2032 Municipal Bond ETF) Start Date:2023-03-01
BSMY (Invesco Bulletshares 2034 Municipal Bond ETF) Start Date:2024-09-11
BSR (Northern Lights Fund Trust Ii Beacon Selective Risk ETF) Start Date:2007-07-20
BSSX (Invesco Bulletshares 2033 Municipal Bond ETF) Start Date:2023-09-20
BSTP (Innovator ETFs Trust Innovator Buffer Step-Up Strategy ETF) Start Date:2022-03-08
BSV (Vanguard St Bond ETF) Start Date:2007-04-10
BSVO (Ea Bridgeway Omni Small-Cap Value ETF) Start Date:2023-03-13
BTAL (Agfiq Us Market Neutral Anti-Beta Fund) Start Date:2011-09-13
BTC (Grayscale Bitcoin Mini Trust) Start Date:2024-07-31
BTCL (T-Rex 2X Long Bitcoin Daily Target ETF T-Rex 2X Long Bitcoin D) Start Date:2024-07-10
BTCO (Invesco Galaxy Bitcoin ETF) Start Date:2024-01-11
BTCW (WisdomTree Bitcoin Trust) Start Date:2024-01-11
BTCZ (T-Rex 2X Long Bitcoin Daily Target ETF T-Rex 2X Inverse Bitcoi) Start Date:2024-07-10
BTEC (Principal Healthcare Innovators ETF) Start Date:2016-08-22
BTEK (Blackrock Future Tech ETF) Start Date:2020-10-01
BTF (Valkyrie Bitcoin Strategy ETF) Start Date:2021-10-22
BTFX (Valkyrie Bitcoin Futures Leveraged Strategy ETF) Start Date:2024-02-22
BTGD (Stkd 100% Bitcoin & 100% Gold ETF) Start Date:2024-10-16
BTHM (Blackrock ETF Trust Blackrock Future Us Themes ETF) Start Date:2021-12-16
BTOP (Bitwise Funds Trust Bitwise Bitcoin And Ether Equal Weight Str) Start Date:2023-10-02
BTR (Northern Lights Fund Trust Ii Beacon Tactical Risk ETF) Start Date:2023-04-18
BTRN (Global X Funds Global X Bitcoin Trend Strategy ETF) Start Date:2024-03-21
BUCK (Simplify Exchange Traded Funds Simplify Stable Income ETF) Start Date:2022-10-28
BUFB (Innovator ETFs Trust Innovator Laddered Allocation Buffer ETF) Start Date:2022-02-09
BUFC (Ab Conservative Buffer ETF) Start Date:2023-12-13
BUFD (FTCboe Vest Fund Of Deep Buffer ETF) Start Date:2021-01-21
BUFF (Laddered Fund Of S&P 500 Power Buffer ETFs) Start Date:2015-07-22
BUFG (FTCboe Vest Buffered Allocation Growth ETF) Start Date:2021-10-27
BUFI (Ab International Buffer ETF) Start Date:2024-12-10
BUFM (Ab Moderate Buffer ETF) Start Date:2024-12-10
BUFP (Shl Telemedicine Pgim Laddered Fund Of Buffer 12 ETF) Start Date:2024-06-13
BUFR (First Trust Exchange-Traded Fund Viii) Start Date:2020-08-11
BUFS (First Trust Exchange-Traded Fund Viii FTVest Laddered Small C) Start Date:2024-06-03
BUFT (FTCboe Vest Buffered Allocation Defensive ETF) Start Date:2021-10-27
BUFZ (FTVest Laddered Moderate Buffer ETF) Start Date:2023-10-27
BUG (Global X Cybersecurity ETF) Start Date:2019-10-31
BUL (Pacer Us Cash Cows Growth ETF) Start Date:2019-05-03
BULD (Pacer Bluestar Engineering The Future ETF) Start Date:2022-05-05
BULZ (Microsectors Fang & Innovation 3X Leveraged ETN) Start Date:2021-08-18
BUSA (Brandes International ETF Brandes Us Value ETF) Start Date:2023-10-05
BUXX (Ea Series Trust Strive Enhanced Income Short Maturity ETF) Start Date:2023-08-10
BUYO (Kraneshares Trust Kraneshares Man Buyout Beta Index ETF) Start Date:2024-10-09
BUYW (Northern Lights Fund Trust Iv Main Buywrite ETF) Start Date:2022-09-12
BUYZ (Franklin Templeton ETF Trust) Start Date:2020-02-27
BUZZ (Vaneck Social Sentiment ETF) Start Date:2021-03-04
BVAL (Brand Value ETF) Start Date:2017-06-14
BWEB (Bitwise Funds Trust Bitwise Web3 ETF) Start Date:2022-10-04
BWET (ETF Managers Commodity Trust I Breakwave Tanker Shipping) Start Date:2023-05-03
BWTG (ETF Opportunities Trust Brendan Wood Topgun Index ETF) Start Date:2023-11-09
BWX (SPDR Lehman Intl Treasury Bd) Start Date:2007-10-05
BWZ (SPDR Blmbg Barclays St Intrn Trsbd ETF) Start Date:2009-01-27
BYLD (iShares Yield Optimized Bond) Start Date:2014-04-24
BYRE (Principal Exchange-Traded Funds Principal Real Estate Active O) Start Date:2022-05-19
BYTE (Roundhill Io Digital Infrastructure ETF) Start Date:2021-10-28
BZQ (ProShares Ultrashort MSCI Brazil Capped) Start Date:2009-06-19
CA (Xtrackers California Municipal Bonds ETF) Start Date:2023-12-14
CAAA (First Trust Exchange-Traded Fund Iv First Trust Commercial Mor) Start Date:2024-02-29
CACG (Clearbridge All Cap Growth ETF) Start Date:2017-05-04
CAFG (Pacer Us Small Cap Cash Cows Growth Leaders ETF) Start Date:2023-05-02
CAFX (Professionally Managed Portfolios Congress Intermediate Bond E) Start Date:2024-09-13
CALF (Pacer Us Small Cap Cash Cows 100 ETF) Start Date:2017-06-19
CALI (iShares Short-Term California Muni Active ETF) Start Date:2023-07-24
CAML (Professionally Managed Portfolios Congress Large Cap Growth Et) Start Date:2023-08-22
CAMX (The Advisors Inner Circle Fund Cambiar Aggressive Value ETF) Start Date:2023-02-13
CANC (Tema Oncology ETF) Start Date:2023-08-15
CANE (Teucrium Sugar ETF) Start Date:2011-09-19
CANQ (Calamos Alternative Nasdaq & Bond ETF) Start Date:2024-02-13
CAOS (Ea Series Trust Alpha Architect Tail Risk ETF) Start Date:2023-03-06
CAPE (Barclays ETN+ Shiller Capet) Start Date:2022-04-05
CARD (Bank Of Montreal Max Auto Industry -3X Inverse Leveraged ETN) Start Date:2023-06-28
CARK (The Advisors Inner Circle Fund Ii Castleark Large Growth ETF) Start Date:2023-12-07
CARU (Bank Of Montreal Max Auto Industry 3X Leveraged ETN) Start Date:2023-06-28
CARY (Angel Oak Funds Trust Angel Oak Income ETF) Start Date:2022-11-08
CARZ (First Trust Nasdaq Global Auto Index Fund) Start Date:2011-05-10
CAS (Simplify Exchange Traded Funds Simplify China A Shares Plus In) Start Date:2025-01-22
CATF (American Century ETF Trust American Century California Municip) Start Date:2024-07-18
CATH (Global X S&P 500 Catholic Values ETF) Start Date:2016-04-19
CBLS (Changebridge Capital Long/Short Equity ETF) Start Date:2020-11-13
CBON (Vaneck Vectors Chinaamc China Bond ETF) Start Date:2014-11-11
CBSE (Changebridge Capital Sustainable Equity ETF) Start Date:2020-11-13
CCEF (Calamos ETF Trust Calamos Cef Income & Arbitrage ETF) Start Date:2024-01-16
CCMG (Ea Series Trust Ccm Global Equity ETF) Start Date:2024-01-18
CCNR (Alps/Corecommodity Natural Resources ETF) Start Date:2024-07-11
CCOR (Core Alternative ETF) Start Date:2017-05-24
CCRV (iShares U.S. ETF Trust iShares Commodity Curve Carry Strategy) Start Date:2020-09-03
CCSB (Carbon Collective Short Duration Green Bond ETF) Start Date:2024-04-12
CCSO (Carbon Collective Climate Solutions Us Equity ETF) Start Date:2022-09-20
CDC (Victoryshares Us Eq Ome Enhanced Volatility Wtd ETF) Start Date:2014-07-02
CDEI (Morgan Stanley ETF Trust Calvert Us Large-Cap Diversity Equit) Start Date:2023-02-01
CDL (Victoryshares Us Lgcp Hi Div Vol Wtd ETF) Start Date:2015-07-08
CDX (Simplify Exchange Traded Funds Simplify High Yield Plus Credit) Start Date:2022-02-15
CEF (Sprott Physical Gold And Silver Trust) Start Date:2018-01-18
CEFA (Global X S&P Catholic Values Developed Ex-U.S. ETF) Start Date:2020-06-24
CEFD (Etracs Monthly Pay 1.5X Leveraged Closed-End Fund Index ETN) Start Date:2020-06-03
CEFS (Exchange Listed Funds Trust) Start Date:2017-03-21
CEMB (iShares Emerging Markets Corporate Bond) Start Date:2012-04-19
CEPI (Rex Crypto Equity Premium Income ETF) Start Date:2024-12-04
CERY (SPDR Series Trust SPDR Bloomberg Enhanced Roll Yield Commodity) Start Date:2024-09-11
CETH (21Shares Core Ethereum ETF 21Shares Core Ethereum ETF) Start Date:2024-07-23
CEW (WisdomTree Emerging Currency Strat ETF) Start Date:2009-05-06
CFA (Victoryshares Us 500 Volatility Wtd ETF) Start Date:2014-07-02
CFCV (Clearbridge Focus Value ESG ETF) Start Date:2020-06-02
CFO (Victoryshares Us 500 Enhanced Volatility Wtd ETF) Start Date:2014-07-02
CGBL (Capital Core Balanced ETF Capital Core Balanced Et) Start Date:2023-09-28
CGCB (Capital Fixed Income ETF Trust Capital Core Bond E) Start Date:2023-09-28
CGCP (Capital Core Plus Income ETF Capital Core Plus Inc) Start Date:2022-02-24
CGCV (Capital Conservative Equity ETF Capital) Start Date:2024-06-27
CGDG (Capital Dividend Growers ETF Capital Dividend Grow) Start Date:2023-09-28
CGDV (Capital Dividend Value ETF Capital Dividend Value) Start Date:2022-02-24
CGGE (Capital Global Equity ETF Capital Global Equity) Start Date:2024-06-27
CGGO (Capital Global Growth Equity ETF Capital Global Gr) Start Date:2022-02-24
CGGR (Capital Growth ETF Capital Growth ETF) Start Date:2022-02-24
CGHM (Capital Fixed Income ETF Trust Capital Municipal) Start Date:2024-06-27
CGIB (Capital Fixed Income ETF Trust Capital Internation) Start Date:2024-06-27
CGIC (Capital International Core Equity ETF Capital) Start Date:2024-06-27
CGIE (Capital International Equity ETF Capital Internati) Start Date:2023-09-28
CGMM (Capital Equity ETF Trust I Capital U.S. Small) Start Date:2025-01-16
CGMS (Capital Fixed Income ETF Trust Capital Us Multi-) Start Date:2022-10-27
CGMU (Capital Fixed Income ETF Trust Capital Municipal I) Start Date:2022-10-27
CGNG (Capital New Geography Equity ETF Capital) Start Date:2024-06-27
CGRO (Tidal Trust Ii Corevalues Alpha Greater China Growth ETF) Start Date:2023-10-17
CGSD (Capital Fixed Income ETF Trust Capital Short Durat) Start Date:2022-10-27
CGSM (Capital Fixed Income ETF Trust Capital Short Durat) Start Date:2023-09-28
CGUI (Capital Fixed Income ETF Trust Capital Ultra Short) Start Date:2024-06-27
CGUS (Capital Core Equity ETF Capital Core Equity ETF) Start Date:2022-02-24
CGV (Affinity World Leaders Equity ETF Conductor Global Equity Valu) Start Date:2022-08-01
CGW (Invesco S&P Global Water Index ETF) Start Date:2007-05-14
CGXU (Capital International Focus Equity ETF Capital Int) Start Date:2022-02-24
CHAD (Direxion Dly CSI 300 Chn A Shr Br 1X ETF) Start Date:2015-06-17
CHAT (Return Stacked Bonds & Managed Futures ETF Roundhill Generativ) Start Date:2023-05-18
CHAU (Direxion Dly CSI 300 Chn A Shr Bl 2X ETF) Start Date:2015-04-16
CHB (Global X China Biotech Innovation ETF) Start Date:2020-09-25
CHGX (Change Finance U.S. Large Cap Fossil Fuel Free ETF) Start Date:2017-10-10
CHIC (Global X MSCI China Communication Services ETF) Start Date:2009-12-09
CHIE (Global X China Energy ETF) Start Date:2009-12-16
CHIH (Global X Funds Global X MSCI China Health Care ETF) Start Date:2018-12-11
CHII (Global X China Industrials ETF) Start Date:2009-12-01
CHIK (Global X MSCI China Information Technology ETF) Start Date:2018-12-11
CHIM (Global X China Materials ETF) Start Date:2010-01-14
CHIQ (Global X MSCI China Consumer Discretionary ETF) Start Date:2009-12-01
CHIR (Global X Funds Global X MSCI China Real Estate ETF) Start Date:2018-12-11
CHIS (Global X MSCI Consumer Staples ETF) Start Date:2018-12-11
CHIU (Global X Funds Global X MSCI China Utilities ETF) Start Date:2018-12-11
CHIX (Global X China Financials ETF) Start Date:2009-12-11
CHNA (PowerShares China A-Share ETF) Start Date:2018-08-15
CHPS (Xtrackers Semiconductor Select Equity ETF) Start Date:2023-07-13
CIBR (First Trust Nasdaq Cea Cybersecurity ETF) Start Date:2015-07-07
CID (Victoryshares Intl Hi Div Vol Wtd ETF) Start Date:2015-08-20
CIL (Victoryshares International Vol Wtd ETF) Start Date:2015-08-20
CIZ (Victoryshares Developed Enh Vol Wtd ETF) Start Date:2014-10-01
CLDL (Direxion Daily Cloud Computing Bull 2X Shares) Start Date:2021-01-08
CLIP (Global X Funds Global X 1-3 Month T-Bill ETF) Start Date:2023-06-22
CLIX (ProShares Long Online/Short Stores ETF) Start Date:2017-11-16
CLNR (IQ Cleaner Transport ETF) Start Date:2021-10-21
CLOA (Blackrock Aaa Clo ETF) Start Date:2023-01-12
CLOB (Vaneck ETF Trust Vaneck Aa-Bb Clo ETF) Start Date:2024-09-25
CLOD (Themes Cloud Computing ETF) Start Date:2023-12-15
CLOI (Vaneck ETF Trust Vaneck Clo ETF) Start Date:2022-06-23
CLOU (Global X Cloud Computing ETF) Start Date:2019-04-16
CLOX (Series Portfolios Trust Panagram Aaa Clo ETF) Start Date:2023-07-19
CLOZ (Series Portfolios Trust Panagram Bbb-B Clo ETF) Start Date:2023-01-24
CLRG (IQ Chaikin U.S. Large Cap ETF) Start Date:2017-12-13
CLSA (Cabana Target Leading Sector Aggressive ETF) Start Date:2021-07-13
CLSC (Cabana Target Leading Sector Conservative ETF) Start Date:2021-07-13
CLSE (Trust For Professional Managers Convergence Long/Short Equity) Start Date:2022-02-22
CLSM (Cabana Target Leading Sector Moderate ETF) Start Date:2021-07-13
CLTL (PowerShares Treasury Collateral ETF) Start Date:2017-01-12
CMBS (iShares Cmbs) Start Date:2012-02-16
CMCI (Vaneck ETF Trust Vaneck Cmci Commodity Strategy ETF) Start Date:2011-03-11
CMDT (iShares Commodity Optimized Trust) Start Date:2023-05-10
CMDY (iShares Bloomberg Roll Select Commodity Strategy ETF) Start Date:2018-04-05
CMF (iShares California Muni Bond ETF) Start Date:2007-10-05
CN (Deutsche X-Trackers MSCI All China Eq) Start Date:2014-04-30
CNBS (Amplify Seymour Cannabis ETF) Start Date:2019-07-23
CNCR (Loncar Cancer Immunotherapy ETF) Start Date:2015-10-14
CNEQ (The Alger ETF Trust Alger Concentrated Equity ETF) Start Date:2024-04-05
CNRG (SPDR S&P Kensho Clean Power ETF) Start Date:2018-10-23
CNXT (Vaneck Vectors Chinaamc Sme-Chinext ETF) Start Date:2014-07-24
CNYA (iShares MSCI China A ETF) Start Date:2016-06-15
COAL (Exchange Traded Concepts Trust Range Global Coal Index ETF) Start Date:2024-01-24
COLO (Global X MSCI Colombia ETF) Start Date:2009-02-09
COM (Direxion Auspice Broad Commodity Strategy ETF) Start Date:2017-03-30
COMB (Graniteshares Bloomberg Commodity Broad Strategy No K-1 ETF) Start Date:2017-05-25
COMT (iShares Commodities Select Strategy ETF) Start Date:2014-10-16
CONI (Graniteshares 1X Short Coin Daily ETF) Start Date:2024-09-04
CONY (Tidal ETF Trust Ii Yieldmax Coin Option Income Strategy ETF) Start Date:2023-08-15
COPA (Themes ETF Trust Themes Copper Miners ETF) Start Date:2007-10-17
COPJ (Sprott Junior Copper Miners ETF) Start Date:2023-02-02
COPP (Sprott Copper Miners ETF) Start Date:2024-03-06
COPX (Global X Copper Miners ETF) Start Date:2010-04-20
COPY (The Rbb Fund Trust Tweedy Browne Insider + Value ETF) Start Date:2024-12-27
CORN (Teucrium Corn Fund) Start Date:2010-06-09
CORO (iShares International Country Rotation Active ETF) Start Date:2024-12-04
CORP (Pimco Investment Grade Corporate Bd ETF) Start Date:2010-09-21
COW (iPath Bloomberg Livestock Subtr ETN) Start Date:2018-02-01
COWG (Pacer Us Large Cap Cash Cows Growth Leaders ETF) Start Date:2022-12-22
COWS (Direxion Daily Agribusiness Bea) Start Date:2023-09-13
COWZ (Pacer Us Cash Cows 100 ETF) Start Date:2016-12-19
CPAI (Northern Lights Fund Trust Iii Counterpoint Quantitative Equit) Start Date:2023-11-29
CPER (United States Copper Index) Start Date:2011-11-15
CPI (IQ Real Return ETF) Start Date:2009-10-27
CPII (Tidal ETF Trust Ionic Inflation Protection ETF) Start Date:2022-06-29
CPLB (Nyli Mackay Core Plus Bond ETF) Start Date:2021-06-29
CPLS (Ab Core Plus Bond ETF) Start Date:2023-12-13
CPNJ (Calamos ETF Trust Calamos Nasdaq - 100 Structured Alt Protecti) Start Date:2024-06-03
CPNM (Calamos ETF Trust Calamos Nasdaq-100 Structured Alt Protection) Start Date:2025-03-03
CPNQ (Calamos ETF Trust Calamos Nasdaq-100 Structured Alt Protection) Start Date:2024-12-02
CPNS (Calamos ETF Trust Calamos Nasdaq-100 Structured Alt Protection) Start Date:2024-09-03
CPRJ (Calamos ETF Trust Calamos Russell 2000 Structured Alt) Start Date:2024-07-01
CPRO (Calamos ETF Trust Calamos Russell 2000 Structured Alt) Start Date:2024-10-01
CPRY (Calamos ETF Trust Calamos Russell 2000 Structured Alt) Start Date:2025-01-02
CPSA (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2024-08-01
CPSD (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2024-12-02
CPSF (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2025-02-03
CPSJ (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2024-07-01
CPSM (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection Et) Start Date:2024-05-01
CPSN (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2024-11-01
CPSO (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2024-10-01
CPSR (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2020-08-24
CPST (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2000-06-30
CPSY (Calamos ETF Trust Calamos S&P 500 Structured Alt Protection) Start Date:2025-01-02
CPXR (Tidal Trust Iii Uscf Daily Target 2X Copper Index ETF) Start Date:2025-01-22
CQQQ (Invesco China Technology ETF) Start Date:2009-12-08
CRAK (Vaneck Vectors Oil Refiners ETF) Start Date:2015-08-19
CRBN (iShares MSCI Acwi Low Carbon Target ETF) Start Date:2014-12-09
CRDT (WisdomTree Strategic Corporate Bond ETF) Start Date:2023-06-27
CRED (iShares Us Credit Bond) Start Date:2023-04-26
CRIT (Exchange Traded Concepts Trust Optica Rare Earths & Critical M) Start Date:2022-03-30
CRPT (First Trust Skybridge Crypto Industry And Digital Economy ETF) Start Date:2021-09-21
CRSH (Tidal Trust Ii Yieldmax Short Tsla Option Income Strategy ETF) Start Date:2024-05-02
CRTC (DBx ETF Trust Xtrackers Us National Critical Technologies ETF) Start Date:2023-11-16
CRUZ (Defiance Hotel Airline And Cruise ETF) Start Date:2021-06-04
CRWL (Graniteshares 2X Long Crwd Daily ETF) Start Date:2024-11-12
CSA (Victoryshares Us Small Cap Vol Wtd ETF) Start Date:2015-07-08
CSB (Victoryshares Us Smcp Hi Div Vol Wtd ETF) Start Date:2015-07-08
CSD (Guggenheim S&P Spin-Off ETF) Start Date:2006-12-15
CSF (Victoryshares Us Discv Enh Vol Wtd ETF) Start Date:2014-08-01
CSHI (Shp ETF Trust Neos Enhanced Income Cash Alternative ETF) Start Date:2022-08-30
CSHP (Blackrock ETF Trust Blackrock Enhanced Short-Term Bond ETF) Start Date:2024-08-01
CSM (ProShares Large Cap Core Plus) Start Date:2009-07-14
CSMD (Professionally Managed Portfolios Congress Smid Growth ETF) Start Date:2023-08-22
CSML (IQ Chaikin U.S. Small Cap ETF) Start Date:2017-05-16
CSNR (Cohen & Steers ETF Trust Cohen & Steers Natural Resources Acti) Start Date:2025-02-05
CSPF (Cohen & Steers ETF Trust Cohen & Steers Preferred And Income O) Start Date:2025-02-05
CSRE (Cohen & Steers ETF Trust Cohen & Steers Real Estate Active ETF) Start Date:2025-02-05
CTA (Simplify Exchange Traded Funds Simplify Managed Futures Strate) Start Date:2022-03-08
CTEC (Global X Cleantech ETF) Start Date:2020-11-02
CTEX (ProShares S&P Kensho Cleantech ETF) Start Date:2021-09-30
CUBS (Asian Growth Cubs ETF) Start Date:2021-06-17
CURE (Direxion Daily Healthcare Bull 3X Shares) Start Date:2011-06-15
CUT (Guggenheim MSCI Global Timber ETF) Start Date:2007-11-09
CVAR (ETF Opportunities Trust Cultivar ETF) Start Date:2021-12-23
CVIE (Morgan Stanley ETF Trust Calvert International Responsible Ind) Start Date:2023-02-01
CVLC (Morgan Stanley ETF Trust Calvert Us Large-Cap Core Responsible) Start Date:2023-02-01
CVMC (Morgan Stanley ETF Trust Calvert Us Mid-Cap Core Responsible I) Start Date:2023-02-01
CVNY (Tidal Trust Ii Yieldmax Cvna Option Income Strategy ETF) Start Date:2025-01-31
CVRD (Madison ETFs Trust Madison Covered Call ETF) Start Date:2023-08-22
CVRT (PowerShares Convertible Securit) Start Date:2023-10-04
CVSB (Morgan Stanley ETF Trust Calvert Ultra-Short Investment Grade) Start Date:2023-02-01
CVSE (Morgan Stanley ETF Trust Calvert Us Select Equity ETF) Start Date:2023-02-01
CVY (Guggenheim Multi-Asset Income ETF) Start Date:2006-09-21
CWB (SPDR Bloomberg Barclays Convertible Securities) Start Date:2009-04-16
CWEB (Direxion Daily CSI China Internet Index Bull 2X Shares) Start Date:2016-11-02
CWI (SPDR MSCI Acwi Ex-Us ETF) Start Date:2007-01-17
CWS (AdvisorShares Focused Equity ETF) Start Date:2016-09-21
CXRN (Listed Funds Trust Teucrium 2X Daily Corn ETF) Start Date:2025-02-24
CXSE (WisdomTree China Ex-State-Owned Enterprises Fund) Start Date:2012-09-19
CYA (Simplify Tail Risk Strategy ETF) Start Date:2021-09-14
CYB (WisdomTree Chinese Yuan Strategy ETF) Start Date:2008-05-14
CZA (Guggenheim Mid-Cap Core ETF) Start Date:2007-04-03
CZAR (Themes Natural Monopoly ETF) Start Date:2023-12-13
DABS (Doubleline ETF Trust Doubleline Asset-Backed Securities ETF) Start Date:2025-03-04
DALI (First Trust Dorseywright Dali 1 ETF) Start Date:2018-05-15
DALT (Two Roads Shared Trust) Start Date:2017-09-29
DAPP (Vaneck Digital Transformation ETF) Start Date:2021-04-14
DAPR (FTCboe Vest U.S. Equity Deep Buffer ETF - April) Start Date:2021-04-19
DARP (Grizzle Growth ETF) Start Date:2021-12-17
DAT (ProShares Big Data Refiners ETF) Start Date:2021-09-30
DAUG (FTCboe Vest U.S. Equity Deep Buffer ETF - August) Start Date:2019-11-07
DAX (Horizons Dax Germany ETF) Start Date:2014-10-23
DBA (PowerShares DB Agriculture Fund) Start Date:2007-01-05
DBAW (Deutsche X-Trackers MSCI Alwd Exus Hgdeq) Start Date:2014-01-27
DBB (PowerShares DB Base Metals ETF) Start Date:2007-01-05
DBC (PowerShares DB Commodity Index) Start Date:2006-02-03
DBE (PowerShares DB Energy ETF) Start Date:2007-01-05
DBEF (Xtrackers MSCI Eafe Hedged Equity ETF) Start Date:2011-06-09
DBEH (Im DBi Hedge Strategy ETF) Start Date:2019-12-18
DBEM (Deutsche X-Trackers MSCI Em Mkts Hdgd Eq) Start Date:2011-06-09
DBEU (Deutsche X-Trackers MSCI Europe Hedgd Eq) Start Date:2013-10-01
DBEZ (Deutsche X-Trackers MSCI Eurozone Hdg Eq) Start Date:2014-12-15
DBGR (Deutsche X-Trackers MSCI Germany Hdgd Eq) Start Date:2011-06-09
DBJA (Innovator Double Stacker 9 Buffer ETF - Jan) Start Date:2021-01-04
DBJP (Deutsche X-Trackers MSCI Japan Hedged Eq) Start Date:2011-06-09
DBMF (Im DBi Managed Futures Strategy ETF) Start Date:2019-05-08
DBND (Doubleline ETF Trust Doubleline Opportunistic Bond ETF) Start Date:2022-04-07
DBO (Invesco DB Oil Fund) Start Date:2007-01-05
DBOC (Innovator Double Stacker 9 Buffer ETF - Oct) Start Date:2020-10-01
DBP (PowerShares DB Precious Metals ETF) Start Date:2007-01-05
DBS (PowerShares DB Silver ETF) Start Date:2007-01-05
DBV (PowerShares DB G10 Currency Harvest ETF) Start Date:2006-09-20
DCMT (Doubleline ETF Trust Doubleline Commodity Strategy ETF) Start Date:2024-02-01
DCOR (Dimensional ETF Trust Dimensional Us Core Equity 1 ETF) Start Date:2023-09-13
DCRE (Doubleline ETF Trust Doubleline Commercial Real Estate ETF) Start Date:2023-04-04
DDEC (FTCboe Vest U.S. Equity Deep Buffer ETF - Dec) Start Date:2020-12-21
DDIV (First Trust Dorsey Wright Momentum & Dividend ETF) Start Date:2014-03-11
DDLS (WisdomTree Dyn Ccy Hdgd Intl Smcp Eq ETF) Start Date:2016-01-07
DDM (ProShares Ultra Dow30) Start Date:2006-06-21
DDWM (WisdomTree Dynamic Currency Hedged International Equity Fund) Start Date:2016-01-07
DECO (SPDR Galaxy Digital Asset Ecosystem ETF) Start Date:2024-09-10
DECP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - Decembe) Start Date:2024-06-03
DECT (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 Dec E) Start Date:2022-12-01
DECW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 Dec E) Start Date:2022-12-01
DECZ (Trueshares Structured Outcome) Start Date:2020-12-01
DEED (First Trust TCWSecuritized Plus ETF) Start Date:2020-04-30
DEEF (Deutsche X-Trackers FTSE Dev Exuscmpsftr) Start Date:2015-11-24
DEEP (Roundhill Acquirers Deep Value ETF) Start Date:2014-09-23
DEF (Guggenheim Defensive Equity ETF) Start Date:2006-12-15
DEFI (Hashdex Bitcoin ETF) Start Date:2024-01-11
DEHP (Dimensional ETF Trust Dimensional Emerging Markets High Profit) Start Date:2022-04-28
DEM (WisdomTree Emerging Markets Hig) Start Date:2007-07-13
DEMZ (Democratic Large Cap Core ETF) Start Date:2020-11-03
DES (WisdomTree Us Smallcap Dividend ETF) Start Date:2006-06-16
DESK (Vaneck ETF Trust Vaneck Office And Commercial Reit ETF) Start Date:2023-09-21
DEUS (Deutsche X-Trackers Russell 1000 Cmpsftr) Start Date:2015-11-24
DEW (WisdomTree Global High Dividend ETF) Start Date:2006-06-16
DEXC (Dimensional ETF Trust Dimensional Emerging Markets Ex China Co) Start Date:2024-11-14
DFAC (Dimensional U.S. Core Equity 2 ETF) Start Date:2021-06-14
DFAE (Dimensional Emerging Core Equity Market ETF) Start Date:2020-12-02
DFAI (Dimensional International Core Equity Market ETF) Start Date:2020-11-18
DFAR (Dimensional ETF Trust Dimensional Us Real Estate ETF) Start Date:2022-02-24
DFAS (Dimensional U.S. Small Cap ETF) Start Date:2021-06-14
DFAT (Dimensional U.S. Targeted Value ETF) Start Date:2021-06-14
DFAU (Dimensional Us Core Equity Market ETF) Start Date:2020-11-18
DFAW (Dimensional ETF Trust Dimensional World Equity ETF) Start Date:2023-09-27
DFAX (Dimensional World Ex U.S. Core Equity 2 ETF) Start Date:2021-09-13
DFCA (Dimensional ETF Trust Dimensional California Municipal Bond Et) Start Date:2023-06-27
DFCF (Dimensional ETF Trust Dimensional Core Fixed Income ETF) Start Date:2021-11-16
DFE (WisdomTree Europe Smallcap Dividend ETF) Start Date:2006-09-21
DFEB (FTCboe Vest U.S. Equity Deep Buffer ETF - February) Start Date:2020-02-24
DFEM (Dimensional ETF Trust Dimensional Emerging Markets Core Equity) Start Date:2022-04-27
DFEN (Direxion Daily Aerospace & Defense Bull 3X Shares) Start Date:2017-05-03
DFEV (Dimensional ETF Trust Dimensional Emerging Markets Value ETF) Start Date:2022-04-27
DFGP (Dimensional Global Core Plus Fixed Income ETF) Start Date:2023-11-08
DFGR (Dimensional ETF Trust Dimensional Global Real Estate ETF) Start Date:2022-12-07
DFGX (Dimensional Global Ex Us Core Fixed Income ETF) Start Date:2023-11-08
DFHY (Trimtabs ETF Trust Donoghue Forlines Tactical High Yield ETF) Start Date:2020-12-08
DFIC (Dimensional ETF Trust Dimensional International Core Equity 2) Start Date:2022-03-24
DFIP (Dimensional ETF Trust Dimensional Inflation-Protected Securiti) Start Date:2021-11-16
DFIS (Dimensional ETF Trust Dimensional International Small Cap ETF) Start Date:2022-03-24
DFIV (Dimensional International Value ETF) Start Date:2021-09-13
DFJ (WisdomTree Japan Smallcap Dividend ETF) Start Date:2006-06-16
DFLV (Dimensional ETF Trust Dimensional Us Large Cap Value ETF) Start Date:2022-12-07
DFND (Reality Shares Divcon Dividend Defender ETF) Start Date:2016-01-14
DFNL (Davis Select Financial ETF) Start Date:2017-01-12
DFNM (Dimensional ETF Trust Dimensional National Municipal Bond ETF) Start Date:2021-11-16
DFNV (Trimtabs ETF Trust Donoghue Forlines Risk Managed Innovation E) Start Date:2020-12-08
DFRA (Donoghue Forlines Yield Enhanced Real Asset ETF) Start Date:2021-12-14
DFSB (Dimensional ETF Trust Dimensional Global Sustainability Fixed) Start Date:2022-11-16
DFSD (Dimensional ETF Trust Dimensional Short-Duration Fixed Income) Start Date:2021-11-16
DFSE (Dimensional ETF Trust Dimensional Emerging Markets Sustainabil) Start Date:2022-11-02
DFSI (Dimensional ETF Trust Dimensional International Sustainability) Start Date:2022-11-02
DFSU (Dimensional ETF Trust Dimensional Us Sustainability Core 1 ETF) Start Date:2022-11-02
DFSV (Dimensional ETF Trust Dimensional Us Small Cap Value ETF) Start Date:2022-02-24
DFUS (Dimensional U.S. Equity ETF) Start Date:2021-06-14
DFUV (Dimensional ETF Trust Dimensional Us Marketwide Value ETF) Start Date:2022-05-09
DFVE (Doubleline ETF Trust Doubleline Fortune 500 Equal Weight ETF) Start Date:2024-02-01
DFVX (Dimensional ETF Trust Dimensional Us Large Cap Vector ETF) Start Date:2023-11-02
DGCB (Dimensional Global Credit ETF) Start Date:2023-11-08
DGIN (Vaneck ETF Trust Vaneck Digital India ETF) Start Date:2022-02-17
DGL (PowerShares DB Gold ETF) Start Date:2007-01-05
DGP (DB Gold Double Long ETN) Start Date:2008-02-28
DGRE (WisdomTree Emerging Mkts Qual Div Gr ETF) Start Date:2013-08-01
DGRO (iShares Core Dividend Growth ETF) Start Date:2014-06-12
DGRS (WisdomTree U.S. Smallcap Dividend Growth Fund) Start Date:2013-07-25
DGRW (WisdomTree U.S. Dividend Growth Fund) Start Date:2013-05-22
DGS (WisdomTree Emerging Markets Smallcap Divdend Fund) Start Date:2007-10-30
DGT (SPDR Global Dow ETF) Start Date:2002-02-04
DGZ (DB Gold Short ETN) Start Date:2008-03-03
DHDG (WisdomTree Trust) Start Date:2016-11-03
DHS (WisdomTree High Dividend ETF) Start Date:2006-06-16
DHSB (Strategy Shares Day Hagan Smart Buffer ETF) Start Date:2025-02-14
DIA (SPDR Dow Jones Industrial Average) Start Date:2000-01-03
DIAL (Columbia Diversified Fixed Income Allocation ETF) Start Date:2017-10-12
DIEM (Franklin Emerging Market Core Dividend Tilt Index ETF) Start Date:2016-06-03
DIG (ProShares Ultra Oil & Gas) Start Date:2007-02-01
DIHP (Dimensional International High Profitability ETF) Start Date:2022-03-24
DIM (WisdomTree International Midcap Div ETF) Start Date:2006-06-16
DINT (Davis Select International ETF) Start Date:2018-03-02
DIPS (Tidal Trust Ii Yieldmax Short Nvda Option Income Strategy ETF) Start Date:2024-07-24
DISO (Tidal ETF Trust Ii Yieldmax Dis Option Income Strategy ETF) Start Date:2023-08-25
DISV (Dimensional ETF Trust Dimensional International Small Cap Valu) Start Date:2022-03-24
DIV (Global X Super Dividend ETF) Start Date:2013-03-12
DIVB (iShares Us Dividend And Buyback ETF) Start Date:2017-11-09
DIVD (Altrius Global Dividend ETF) Start Date:2022-09-30
DIVG (Invesco Exchange-Traded Fund Trust Ii Invesco S&P 500 High Div) Start Date:2023-12-07
DIVI (Franklin International Core Dividend Tilt Index ETF) Start Date:2016-06-02
DIVL (Madison ETFs Trust Madison Dividend Value ETF) Start Date:2023-08-15
DIVO (Amplify Cwp Enhanced Dividend Ome ETF) Start Date:2016-12-14
DIVP (The Advisors Inner Circle Fund Ii Cullen Enhanced Equity Inco) Start Date:2024-03-07
DIVS (Smartetfs Dividend Builder ETF) Start Date:2021-03-29
DIVY (Reality Shares Divs ETF) Start Date:2020-12-31
DIVZ (Trueshares Low Volatility Equity Income ETF) Start Date:2021-01-28
DJAN (FTCboe Vest U.S. Equity Deep Buffer ETF - January) Start Date:2021-01-19
DJCB (Etracs Bloomberg Commodity Index Total Return ETN Series B Due) Start Date:2019-10-25
DJD (Guggenheim Dow Jones Indl Avg Div ETF) Start Date:2015-12-16
DJIA (Global X Funds Global X Dow 30 Covered Call ETF) Start Date:2022-02-24
DJP (iPath Dow Jones Ubs Commodity) Start Date:2006-10-30
DJUL (FTCboe Vest U.S. Equity Deep Buffer ETF - July) Start Date:2020-07-20
DJUN (FTCboe Vest U.S. Equity Deep Buffer ETF - June) Start Date:2020-06-22
DLLL (Graniteshares 2X Long Dell Daily ETF) Start Date:2025-02-13
DLN (WisdomTree Largecap Dividend Fund) Start Date:2006-06-16
DLS (WisdomTree International Smallcap Dividend) Start Date:2006-06-16
DMAR (FTCboe Vest U.S. Equity Deep Buffer ETF - March) Start Date:2021-03-22
DMAT (Global X Disruptive Materials ETF) Start Date:2022-01-26
DMAY (FTCboe Vest U.S. Equity Deep Buffer ETF - May) Start Date:2020-05-18
DMBS (Doubleline ETF Trust Doubleline Mortgage ETF) Start Date:2023-04-04
DMCY (Democracy International Fund) Start Date:2021-04-01
DMDV (Aam S&P Developed Markets High Dividend Value ETF) Start Date:2018-11-28
DMX (Doubleline ETF Trust Doubleline Multi-Sector Income ETF) Start Date:2024-12-03
DMXF (iShares ESG Advanced MSCI Eafe ETF) Start Date:2020-06-18
DNL (WisdomTree Global Ex-U.S. Quality Dividend Growth Fund) Start Date:2006-06-16
DNOV (FTCboe Vest U.S. Equity Deep Buffer ETF - November) Start Date:2019-11-18
DOCT (FTCboe Vest U.S. Equity Deep Buffer ETF - October) Start Date:2020-10-19
DOG (ProShares Short Dow30) Start Date:2006-06-21
DOL (WisdomTree International Largecp Div ETF) Start Date:2006-06-16
DON (WisdomTree Us Midcap Dividend ETF) Start Date:2006-06-16
DOZR (Direxion Daily Us Infrastructure Bull 2X Shares) Start Date:2021-09-23
DPST (Direxion Daily Regional Banks Bull 3X Shares) Start Date:2015-08-19
DRAI (Ea Series Trust Draco Evolution AI ETF) Start Date:2024-07-11
DRIP (Direxion Daily S&P Oil & Gas Exp. & Prod. Bear 2X Shares) Start Date:2015-05-29
DRIV (Global X Autonomous & Electric Vehicles ETF) Start Date:2018-04-17
DRLL (Ea Series Trust Strive Us Energy ETF) Start Date:2022-08-09
DRN (Direxion Daily Real Estate Bull 3X ETF) Start Date:2009-07-16
DRSK (Aptus Defined Risk ETF) Start Date:2018-08-08
DRUP (Graniteshares Nasdaq Select Disruptors ETF) Start Date:2019-10-07
DRV (Direxion Daily Real Estate Bear 3X ETF) Start Date:2009-07-16
DSCF (Discipline Fund ETF) Start Date:2021-09-21
DSEP (FTCboe Vest U.S. Equity Deep Buffer ETF - September) Start Date:2020-09-21
DSI (iShares MSCI Kld 400 Social ETF) Start Date:2006-11-17
DSJA (Innovator ETFs Trust) Start Date:2021-01-04
DSMC (ETF Series Solutions Distillate Small/Mid Cash Flow ETF) Start Date:2022-10-06
DSOC (Innovator Double Stacker ETF - October) Start Date:2020-10-01
DSTL (Distillate U.S. Fundamental Stability & Value ETF) Start Date:2018-10-24
DSTX (Distillate International Fundamental Stability & Value ETF) Start Date:2020-12-15
DTAN (Ea Series Trust Sparkline International Intangible Value ETF) Start Date:2024-09-10
DTCR (Global X Data Center & Digital Infrastructure ETF) Start Date:2020-11-02
DTD (WisdomTree Total Dividend ETF) Start Date:2006-06-16
DTEC (Alps Disruptive Technologies ETF) Start Date:2017-12-29
DTH (WisdomTree International High Div ETF) Start Date:2006-06-16
DTRE (First Trust Alerian Disruptive Technology Real Estate ETF) Start Date:2007-08-30
DUBS (ETF Series Solutions Aptus Large Cap Enhanced Yield ETF) Start Date:2023-06-14
DUDE (Merlyn.AI Sectorsurfer Momentum ETF) Start Date:2020-12-30
DUG (ProShares Ultrashort Oil & Gas) Start Date:2007-02-01
DUHP (Dimensional ETF Trust Dimensional Us High Profitability ETF) Start Date:2022-02-24
DUKQ (Northern Lights Fund Trust Ocean Park Domestic ETF) Start Date:2024-07-11
DUKX (Ocean Park International ETF) Start Date:2024-07-11
DUKZ (Northern Lights Fund Trust Ocean Park Diversified Income ETF) Start Date:2024-07-11
DULL (Direxion Daily Silver Mnrs Bear 2X ETF) Start Date:2023-02-22
DURA (Vaneck Vectors ETF Trust) Start Date:2018-10-31
DUSA (Davis Select Us Equity ETF) Start Date:2017-01-12
DUSB (Dimensional ETF Trust Dimensional Ultrashort Fixed Income ETF) Start Date:2023-09-27
DUSL (Direxion Daily Industrials Bull 3X Shares) Start Date:2017-05-03
DUST (Direxion Daily Gold Miners Index Bear 2X) Start Date:2010-12-08
DVAL (Brandywineglobal-Dynamic Us Large Cap Value ETF) Start Date:2022-10-31
DVDN (ETF Opportunities Trust Kingsbarn Dividend Opportunity ETF) Start Date:2023-11-02
DVLU (First Trust Dorsey Wright Momentum & Value ETF) Start Date:2018-09-07
DVND (Touchstone ETF Trust Touchstone Dividend Select ETF) Start Date:2022-08-05
DVOL (First Trust Dorsey Wright Momentum & Low Volatility ETF) Start Date:2018-09-07
DVQQ (Webs Defined Volatility Qqq ETF) Start Date:2024-12-17
DVSP (Webs Defined Volatility Spy ETF) Start Date:2024-12-17
DVY (iShares Dow Jones Select) Start Date:2003-11-07
DVYA (iShares Asia/Pacific Dividend) Start Date:2012-02-24
DVYE (iShares Emerging Markets Dividend ETF) Start Date:2012-02-24
DWAC (Elkhorn Commodity Rotation Strategy ETF) Start Date:2021-09-30
DWAS (Invesco DWA Smallcap Momentum ETF) Start Date:2012-07-19
DWAT (Arrow DWA Tactical ETF) Start Date:2014-10-01
DWAW (AdvisorShares Dorsey Wright Fsm All Cap World ETF) Start Date:2019-12-27
DWCR (Arrow DWA Country Rotation ETF) Start Date:2017-12-29
DWEQ (AdvisorShares Dorsey Wright Alpha Equal Weight ETF) Start Date:2019-12-27
DWLD (Davis Select Worldwide ETF) Start Date:2017-01-12
DWM (WisdomTree Defa) Start Date:2006-06-16
DWMC (AdvisorShares Dorsey Wright Micro-Cap ETF) Start Date:2018-07-11
DWMF (WisdomTree International Multifactor Fund) Start Date:2018-08-10
DWSH (AdvisorShares Dorsey Wright Short ETF) Start Date:2018-07-11
DWUS (AdvisorShares Dorsey Wright Fsm Us Core ETF) Start Date:2019-12-27
DWX (SPDR S&P International Dividend ETF) Start Date:2008-02-20
DXD (ProShares Ultrashort Dow30) Start Date:2006-07-13
DXGE (WisdomTree Germany Hedged Equity ETF) Start Date:2013-10-17
DXIV (Dimensional ETF Trust Dimensional International Vector Equity) Start Date:2024-09-12
DXJ (WisdomTree Japan Total Dividend) Start Date:2006-06-16
DXJS (WisdomTree Japan Hedged Smallcap Eq ETF) Start Date:2013-06-28
DXUV (Dimensional ETF Trust Dimensional Us Vector Equity ETF) Start Date:2024-09-12
DYFI (Idx Dynamic Fixed Income ETF) Start Date:2024-01-10
DYLD (Leadershares Dynamic Yield ETF) Start Date:2021-06-29
DYLG (Global X Funds Global X Dow 30 Covered Call & Growth ETF) Start Date:2023-08-02
DYNF (Blackrock U.S. Equity Factor Rotation ETF) Start Date:2019-03-21
DYNI (Idx Dynamic Innovation ETF) Start Date:2023-11-14
DYTA (Sgi Dynamic Tactical ETF) Start Date:2023-03-30
DZZ (DB Gold Double Short ETN) Start Date:2008-02-28
EAFG (Pacer Funds Trust Pacer Developed Markets Cash Cows Growth Lea) Start Date:2024-03-22
EAGG (iShares ESG Aware U.S. Aggregate Bond ETF) Start Date:2018-10-23
EAGL (The 2023 ETF Series Trust Eagle Capital Select Equity ETF) Start Date:2024-03-25
EALT (Innovator ETFs Trust Innovator Us Equity 5 To 15 Buffer ETF) Start Date:2023-10-02
EAOA (iShares ESG Aware Aggressive Allocation ETF) Start Date:2020-06-18
EAOK (iShares ESG Aware Conservative Allocation ETF) Start Date:2020-06-18
EAOM (iShares ESG Aware Moderate Allocation ETF) Start Date:2020-06-18
EAOR (iShares ESG Aware Growth Allocation ETF) Start Date:2020-06-18
EAPR (Innovator Emerging Markets Power Buffer ETF April) Start Date:2021-04-01
EASG (Xtrackers MSCI Eafe ESG Leaders Equity ETF) Start Date:2018-09-06
EATV (Advisors Series Trust Vegtech Plant-Based Innovation & Climate) Start Date:2021-12-29
EATZ (AdvisorShares Restaurant ETF) Start Date:2021-04-21
EBI (Longview Advantage ETF) Start Date:2025-02-28
EBIT (Harbor ETF Trust Harbor Alphaedge Small Cap Earners ETF) Start Date:2024-07-11
EBIZ (Global X E-Commerce ETF) Start Date:2018-11-30
EBLU (Ecofin Global Water ESG Fund) Start Date:2020-08-21
EBND (SPDR Barclays Capital Emerging Markets Local Bond ETF) Start Date:2011-02-24
EBUF (Shl Telemedicine Innovator Emerging Markets 10 Buffer ETF) Start Date:2024-07-01
ECH (iShares MSCI Chile ETF) Start Date:2007-11-16
ECLN (First Trust Eip Carbon Impact ETF) Start Date:2019-08-20
ECML (Ea Series Trust Euclidean Fundamental Value ETF) Start Date:2023-05-18
ECNS (iShares MSCI China Small-Cap) Start Date:2010-09-29
ECON (Columbia Emerging Markets Consumer ETF) Start Date:2010-09-14
ECOW (Pacer Emerging Markets Cash Cows 100 ETF) Start Date:2019-05-06
ECOZ (Trueshares ESG Active Opportunities ETF) Start Date:2020-03-02
EDC (Direxion Emerging Markets Bull) Start Date:2008-12-17
EDEN (iShares MSCI Denmark Capped) Start Date:2012-01-26
EDGF (The Advisors Inner Circle Fund Ii 3Edge Dynamic Fixed Income) Start Date:2024-10-04
EDGH (The Advisors Inner Circle Fund Ii 3Edge Dynamic Hard Assets) Start Date:2024-10-03
EDGI (The Advisors Inner Circle Fund Ii 3Edge Dynamic International) Start Date:2024-10-03
EDGU (The Advisors Inner Circle Fund Ii 3Edge Dynamic Us Equity ETF) Start Date:2024-10-03
EDIV (SPDR S&P Emerging Markets Dividend ETF) Start Date:2011-02-24
EDOC (Global X Telemedicine & Digital Health ETF) Start Date:2020-07-30
EDOG (Alps Emerging Sector Dividend Dogs ETF) Start Date:2014-03-28
EDOW (First Trust Dow 30 Equal Weight ETF) Start Date:2017-08-09
EDUT (Global X Education ETF) Start Date:2020-07-14
EDV (Vanguard Ext Duration Treasury ETF) Start Date:2007-12-13
EDZ (Direxion Daily Emerging Markets Bear 3X Shares) Start Date:2008-12-17
EELV (PowerShares S&P Em Mkts Low Volatil ETF) Start Date:2012-01-13
EEM (iShares MSCI Emerging Markets Index) Start Date:2003-04-14
EEMA (iShares MSCI Emerging Markets Asia ETF) Start Date:2012-02-09
EEMD (Aam S&P Emerging Markets High Dividend Value ETF) Start Date:2017-11-29
EEMO (PowerShares S&P Emerg Mkts Momentum ETF) Start Date:2012-02-24
EEMS (iShares MSCI Emerging Markets Small-Cap) Start Date:2011-08-18
EEMV (iShares Edge MSCI Min Vol Emerging Markets ETF) Start Date:2011-10-20
EEMX (SPDR MSCI Emerging Markets Fuel Reserves Free ETF) Start Date:2016-10-25
EES (WisdomTree Smallcap Earnings ETF) Start Date:2007-02-23
EET (ProShares Ultra MSCI Emerging Markets) Start Date:2009-06-04
EETH (ProShares Trust ProShares Ether Strategy ETF) Start Date:2023-10-02
EEV (ProShares Ultrashort MSCI Emerging Mkts) Start Date:2007-11-01
EFA (iShares MSCI Eafe Index) Start Date:2001-08-27
EFAA (Invesco Actively Managed Exchange-Traded Fund Trus Invesco) Start Date:2024-07-17
EFAD (ProShares MSCI Eafe Dividend Growers) Start Date:2014-08-21
EFAS (Global X MSCI Superdividend Eafe ETF) Start Date:2016-11-16
EFAV (iShares Edge MSCI Min Vol Eafe ETF) Start Date:2011-10-20
EFAX (SPDR MSCI Eafe Fossil Fuel Free ETF) Start Date:2016-10-25
EFFE (Harbor ETF Trust Harbor Osmosis Emerging Markets Resource) Start Date:2014-10-23
EFFI (Harbor ETF Trust Harbor Osmosis International Resource) Start Date:2024-12-17
EFG (iShares MSCI Eafe Growth ETF) Start Date:2005-08-05
EFIV (SPDR S&P 500 ESG ETF) Start Date:2020-07-28
EFIX (First Trust Exchange-Traded Fund Viii First Trust TCWEmerging) Start Date:2021-02-18
EFNL (iShares MSCI Finland Capped) Start Date:2012-01-26
EFO (ProShares Ultra MSCI Eafe) Start Date:2009-06-04
EFRA (iShares Environmental Infrastructure And Industrials ETF) Start Date:2022-11-03
EFU (ProShares Ultrashort MSCI Eafe) Start Date:2007-10-25
EFUT (Vaneck ETF Trust Vaneck Ethereum Strategy ETF) Start Date:2007-04-04
EFV (iShares MSCI Value Index Fund) Start Date:2005-08-05
EFZ (ProShares Short MSCI Eafe) Start Date:2007-10-25
EGGQ (Nestyield Visionary ETF) Start Date:2024-12-30
EGGS (Tidal Trust Iii Nestyield Total Return Guard ETF) Start Date:2024-12-27
EGGY (Nestyield Dynamic Income ETF) Start Date:2024-12-27
EGIS (2Ndvote Society Defended ETF) Start Date:2020-11-18
EGPT (Vaneck Vectors Egypt ETF) Start Date:2010-02-18
EGUS (iShares Trust iShares ESG Aware MSCI Usa Growth ETF) Start Date:2023-02-08
EHLS (Even Herd Long Short ETF) Start Date:2024-04-02
EIDO (iShares MSCI Indonesia ETF) Start Date:2010-05-07
EINC (Vaneck Vectors Energy Income ETF) Start Date:2012-03-13
EIPI (First Trust Exchange-Traded Fund Viii FTEnergy Income Partner) Start Date:2024-05-06
EIPX (First Trust Exchange-Traded Fund Iv FTEnergy Income Partners) Start Date:2022-11-03
EIRL (iShares MSCI Ireland Capped) Start Date:2010-05-07
EIS (iShares MSCI Israel Capped) Start Date:2008-03-28
EJAN (Innovator ETFs Trust Innovator MSCI Emerging Markets Power Buf) Start Date:2020-01-02
EJUL (Innovator MSCI Emerging Markets Power Buffer ETF - July) Start Date:2019-07-01
EKG (First Trust Nasdaq Lux Digital Health Solutions ETF) Start Date:2022-03-23
ELCV (Strategy Shares Eventide High Dividend ETF) Start Date:2024-10-01
ELD (WisdomTree Emerging Markets Lcl DBt ETF) Start Date:2010-08-09
ELM (Series Portfolios Trust Elm Market Navigator ETF) Start Date:2025-02-11
ELON (Tidal Trust Iii Battleshares Tsla Vs F ETF) Start Date:1998-07-28
EMB (iShares JP Morgan Em Bond Fd) Start Date:2007-12-19
EMBD (Global X Emerging Markets Bond ETF) Start Date:2020-06-03
EMC (Global X Funds Global X Emerging Markets Great Consumer ETF) Start Date:2023-05-15
EMCB (WisdomTree Emerging Markets Bd ETF) Start Date:2012-03-08
EMCC (Global X Funds Global X MSCI Emerging Markets Covered Call ETF) Start Date:2023-11-08
EMCR (Xtrackers Emerging Markets Carbon Reduction And Climate Improv) Start Date:2018-12-06
EMCS (Xtrackers MSCI Emerging Markets Climate Selection ETF) Start Date:2018-12-06
EMDM (First Trust Exchange-Traded Fund Ii First Trust Bloomberg Emer) Start Date:2023-03-03
EMDV (ProShares MSCI Emerg Mkts Div Growers) Start Date:2016-01-27
EMEQ (Macquarie Focused Emerging Markets Equity ETF) Start Date:2024-09-05
EMFM (Global X Next Emerging & Frontier ETF) Start Date:2013-11-07
EMFQ (Amplify Emerging Markets Fintech ETF) Start Date:2019-01-30
EMGF (iShares Edge MSCI Multifactor Emerging Markets ETF) Start Date:2015-12-10
EMHC (SPDR Bloomberg Emerging Markets Usd Bond ETF) Start Date:2021-04-07
EMHY (iShares Emerging Markets High Yield Bond) Start Date:2012-04-03
EMIF (iShares Emerging Markets Infrastructure) Start Date:2009-06-19
EMLC (Market Vectors Emerging Markets) Start Date:2010-07-23
EMLP (First Trust North American Energy Infrastructure Fund) Start Date:2012-06-21
EMM (SPDR Dj Wilshire Mid Cap ETF) Start Date:2023-05-15
EMMF (WisdomTree Emerging Markets Multifactor Fund) Start Date:2018-08-10
EMNT (Pimco Enhanced Short Maturity Active ESG Exchange-Traded Fund) Start Date:2019-12-12
EMOT (First Trust Exchange-Traded Fund Vi First Trust S&P 500) Start Date:2024-07-18
EMPB (Ea Series Trust Efficient Market Portfolio Plus ETF) Start Date:2024-12-12
EMQQ (Emerging Markets Internet & Ecommerce ETF) Start Date:2014-11-13
EMSF (Matthews International Funds Matthews Emerging Markets Sustain) Start Date:2023-09-22
EMSG (Xtrackers MSCI Emerging Markets ESG Leaders Equity ETF) Start Date:2018-12-06
EMTL (SPDR Doubleline Emerg Mkts Fxd Inc ETF) Start Date:2016-04-14
EMTY (ProShares Decline Of The Retail Store ETF) Start Date:2017-11-16
EMXC (iShares MSCI Emerging Markets Ex China ETF) Start Date:2017-07-26
EMXF (iShares ESG Advanced MSCI Em ETF) Start Date:2020-10-13
ENFR (Alerian Energy Infrastructure ETF) Start Date:2013-11-01
ENOR (iShares MSCI Norway Capped) Start Date:2012-01-24
ENTR (Ershares Entrepreneur 30 ETF) Start Date:2017-11-08
ENZL (iShares MSCI New Zealand Capped) Start Date:2010-09-02
EOCT (Innovator Emerging Markets Power Buffer ETF - October) Start Date:2021-10-01
EPHE (iShares MSCI Philippines) Start Date:2010-09-29
EPI (WisdomTree India Earnings Fund) Start Date:2008-02-22
EPOL (iShares MSCI Poland ETF) Start Date:2010-05-26
EPP (iShares MSCI Pacific Ex-Japan I) Start Date:2004-01-02
EPRF (Innovator S&P High Quality Preferred ETF) Start Date:2016-05-24
EPS (WisdomTree Earnings 500 ETF) Start Date:2007-02-23
EPU (iShares MSCI Peru ETF) Start Date:2009-06-22
EPV (ProShares Ultrashort FTSE Europe) Start Date:2009-06-19
EQAL (PowerShares Russell 1000 Equal Wght ETF) Start Date:2014-12-29
EQIN (Russell Equity Income ETF) Start Date:2016-06-17
EQL (Alps Equal Sector Weight ETF) Start Date:2009-07-07
EQLS (Simplify Exchange Traded Funds Simplify Market Neutral Equity) Start Date:2023-06-14
EQLT (Workplace Equality ETF) Start Date:2014-02-25
EQOP (Natixis U.S. Equity Opportunities ETF) Start Date:2020-09-17
EQRR (ProShares Equities For Rising Rates ETF) Start Date:2017-07-25
EQTY (Valued Advisers Trust Kovitz Core Equity ETF) Start Date:2022-12-12
EQUL (IQ Engender Equality ETF) Start Date:2021-10-21
EQWL (PowerShares Russell Top 200 Equal Wt ETF) Start Date:2007-05-16
ERET (iShares Environmentally Aware Real Estate ETF) Start Date:2022-11-17
ERM (Equitycompass Risk Manager ETF) Start Date:2017-04-11
ERNZ (Trueshares Active Yield ETF) Start Date:2024-05-01
ERSX (Ershares Non-Us Small Cap ETF) Start Date:2018-12-28
ERTH (Invesco MSCI Sustainable Future ETF) Start Date:2007-05-16
ERX (Direxion Daily Energy Bull 3X Shares) Start Date:2008-11-06
ERY (Direxion Daily Energy Bear 2X Shares) Start Date:2008-11-06
ESCR (Xtrackers Bloomberg Us Inv Grade ESG ETF) Start Date:2020-05-12
ESEB (Xtrackers JP Morgan ESG Emerg Mkts Sovereign ETF) Start Date:2020-05-12
ESG (Flexshares STOXX Us ESG Impact ETF) Start Date:2016-07-14
ESGA (American Century Sustainable Equity ETF) Start Date:2020-07-15
ESGB (IQ Mackay ESG Core Plus Bond ETF) Start Date:2021-06-29
ESGD (iShares Trust iShares ESG Aware MSCI Eafe ETF) Start Date:2016-06-30
ESGE (iShares ESG MSCI Em ETF) Start Date:2016-07-20
ESGG (Flexshares STOXX Glbl ESG Impact ETF) Start Date:2016-07-14
ESGL (Oppenheimer Revenue Weighted ETF Trust Oppenheimer ESG Revenue) Start Date:2023-08-04
ESGN (Columbia Sustainable International Equity Income ETF) Start Date:2016-06-13
ESGS (Columbia Sustainable U.S. Equity Income ETF) Start Date:2016-06-17
ESGU (iShares ESG MSCI Usa ETF) Start Date:2016-12-06
ESGV (Vanguard ESG U.S. Stock ETF) Start Date:2018-09-20
ESGY (American Century Sustainable Growth ETF) Start Date:2021-07-01
ESHY (DB-X MSCI) Start Date:2020-05-12
ESIX (Ssga Active Trust SPDR S&P Smallcap 600 ESG ETF) Start Date:2022-01-11
ESML (iShares ESG Aware MSCI Usa Small-Cap ETF) Start Date:2018-04-12
ESMV (iShares ESG MSCI Usa Min Vol Factor ETF) Start Date:2021-11-04
ESPO (Vaneck Vectors Video Gaming And Esports ETF) Start Date:2018-10-17
ESUS (Etracs 2X Leveraged MSCI Us ESG Focus Tr ETN) Start Date:2021-09-15
ETEC (iShares Breakthrough Environmental Solutions ETF) Start Date:2007-05-17
ETHD (ProShares Trust ProShares Ultrashort Ether ETF) Start Date:2024-06-07
ETHE (Grayscale Ethereum Trust) Start Date:2019-06-20
ETHO (Etho Climate Leadership Us ETF) Start Date:2015-11-18
ETHT (ProShares Trust ProShares Ultra Ether ETF) Start Date:2024-06-07
ETHU (Volatility Shares Trust 2X Ether ETF) Start Date:2024-06-04
ETHV (Vaneck Ethereum ETF Vaneck Ethereum ETF) Start Date:2024-07-23
ETHW (Bitwise Ethereum ETF Common Shares Of Beneficial Interest) Start Date:2024-07-23
ETQ (T-Rex 2X Inverse Ether Daily Target ETF) Start Date:2007-05-16
ETU (T-Rex 2X Long Ether Daily Target ETF) Start Date:2024-10-24
EUDG (WisdomTree Europe Quality Div Gr ETF) Start Date:2014-05-07
EUDV (ProShares MSCI Europe Dividend Growers ETF) Start Date:2015-09-11
EUFN (iShares MSCI Europe Financials ETF) Start Date:2010-02-03
EUM (ProShares Short MSCI Emerging Markets) Start Date:2007-11-01
EUO (ProShares Ultrashort Euro) Start Date:2008-11-25
EURL (Direxion Daily FTSE Europe Bull 3X ETF) Start Date:2014-01-22
EUSA (iShares MSCI Usa Equal Weighted) Start Date:2010-05-07
EUSB (iShares ESG Advanced Total Usd Bond Market ETF) Start Date:2020-06-25
EUSC (WisdomTree Europe Hedged Smallcap Eq ETF) Start Date:2015-03-04
EUSM (Strategy Shares Eventide Us Market ETF) Start Date:2024-12-18
EV (Neos ETF Trust Mast Global Battery Recycling & Production ETF) Start Date:2023-12-21
EVAV (Direxion Shares ETF Trust Direxion Daily Electric And Autonomo) Start Date:2022-08-11
EVHY (Morgan Stanley ETF Trust Eaton Vance High Yield ETF) Start Date:2023-10-19
EVIM (Morgan Stanley ETF Trust Eaton Vance Intermediate Municipal In) Start Date:2023-10-19
EVLN (Morgan Stanley ETF Trust Eaton Vance Floating-Rate ETF) Start Date:2024-02-08
EVMT (Invesco Electric Vehicle Metals Commodity Strategy No K-1 ETF) Start Date:2022-04-27
EVNT (Altshares Event-Driven ETF) Start Date:2021-09-20
EVSB (Morgan Stanley ETF Trust Eaton Vance Ultra-Short Income ETF) Start Date:2023-10-19
EVSD (Eaton Vance Short Duration Income ETF) Start Date:2024-06-17
EVSM (Morgan Stanley ETF Trust Eaton Vance Short Duration Municipal) Start Date:2024-03-25
EVTR (Morgan Stanley ETF Trust Eaton Vance Total Return Bond ETF) Start Date:2024-03-25
EVUS (iShares Trust iShares ESG Aware MSCI Usa Value ETF) Start Date:2023-02-02
EVX (Vaneck Vectors Environmental Svcs ETF) Start Date:2006-10-16
EVYM (Eaton Vance High Income Municipal ETF) Start Date:2025-02-27
EWA (iShares MSCI Australia Index) Start Date:2000-01-03
EWC (iShares MSCI Canada Index Fund) Start Date:2000-01-03
EWCO (Invesco S&P 500 Equal Weight Communication Services ETF) Start Date:2018-11-07
EWD (iShares Sweden) Start Date:2005-11-30
EWEB (Global X Emerging Markets Internet & E-Commerce ETF) Start Date:2020-11-11
EWG (iShares MSCI Germany Index Fund) Start Date:2000-01-03
EWGS (iShares MSCI Germany Small-Cap) Start Date:2012-01-26
EWH (iShares MSCI Hong Kong Index) Start Date:2004-01-02
EWI (iShares MSCI Italy Index Fund) Start Date:2004-01-02
EWJ (iShares MSCI Japan Index Fund) Start Date:2000-01-03
EWJV (iShares MSCI Japan Value ETF) Start Date:2019-03-07
EWK (iShares MSCI Belgium Capped) Start Date:2005-11-30
EWL (iShares MSCI Switzerland ETF) Start Date:2005-11-30
EWM (iShares MSCI Malaysia Index Fund) Start Date:2005-01-03
EWMC (Guggenheim S&P Midcap 400 Equal Wt ETF) Start Date:2010-12-08
EWN (iShares MSCI Netherlands) Start Date:2005-11-30
EWO (iShares MSCI Austria Capped) Start Date:2000-01-03
EWP (iShares MSCI Spain Index Fund) Start Date:2004-01-02
EWQ (iShares MSCI France Index Fund) Start Date:2004-01-02
EWRE (Guggenheim S&P 500 Eql Wght Rel Est ETF) Start Date:2015-08-14
EWS (iShares MSCI Singapore Index) Start Date:2004-01-02
EWSC (Guggenheim S&P Smallcap 600 Eql Wt ETF) Start Date:2010-12-08
EWT (iShares MSCI Taiwan Index Fund) Start Date:2004-01-02
EWU (iShares MSCI United Kingdom Ind) Start Date:2004-01-02
EWUS (iShares MSCI United Kingdom Small-Cap) Start Date:2012-01-26
EWV (ProShares Ultrashort MSCI Japan) Start Date:2007-11-08
EWW (iShares MSCI Mexico Index Fund) Start Date:2000-01-03
EWX (SPDR S&P Emerging Small Cap ETF) Start Date:2008-05-16
EWY (iShares MSCI South Korea Index) Start Date:2004-01-02
EWZ (iShares MSCI Brazil Index) Start Date:2005-01-03
EWZS (iShares MSCI Brazil Small-Cap) Start Date:2010-09-29
EXI (iShares S&P Global Industrials ETF) Start Date:2006-09-27
EYEG (Ab Corporate Bond ETF) Start Date:2023-12-13
EYLD (Cambria Emerging Shareholder Yield ETF) Start Date:2016-07-14
EZA (iShares MSCI South Africa Index) Start Date:2003-02-07
EZBC (Franklin Bitcoin ETF) Start Date:2024-01-11
EZET (Franklin Ethereum ETF Franklin Ethereum ETF) Start Date:2024-07-23
EZJ (ProShares Ultra MSCI Japan) Start Date:2009-06-05
EZM (WisdomTree Midcap Earnings ETF) Start Date:2007-02-23
EZU (iShares MSCI Emu Index Fund) Start Date:2000-07-31
FAAR (First Trust Alternative Absolute Return Strategy ETF) Start Date:2016-05-23
FAB (First Trust Multi Cap Val AlphaDEX ETF) Start Date:2007-05-23
FAD (First Trust Multi Cap Gr AlphaDEX ETF) Start Date:2007-05-23
FAI (First Trust Exchange-Traded Fund Ii First Trust Bloomberg Ai) Start Date:2024-11-21
FAIL (Cambria ETF Trust Cambria Global Tail Risk ETF) Start Date:2021-03-15
FALN (iShares U.S. Fallen Angels Usd Bond ETF) Start Date:2016-06-17
FAN (First Trust Ise Global Wind Energy Index Fund) Start Date:2008-06-18
FAPR (FTCboe Vest U.S. Equity Buffer ETF - April) Start Date:2021-11-02
FARX (The Advisors' Inner Circle Fund Ii Frontier Asset Absolute) Start Date:2024-12-20
FAS (Direxion Daily Financial Bull 3X Shares) Start Date:2008-11-06
FAUG (FTCboe Vest U.S. Equity Buffer ETF - August) Start Date:2019-11-07
FAZ (Direxion Daily Financial Bear 3X Shares) Start Date:2008-11-06
FBCG (Fidelity Blue Chip Growth ETF) Start Date:2020-06-04
FBCV (Fidelity Blue Chip Value ETF) Start Date:2020-06-04
FBGX (Ubs Ag Fi Enhanced Large Cap Growth ETN) Start Date:2014-06-11
FBL (Graniteshares 1.5X Long Meta Daily ETF) Start Date:2022-12-13
FBND (Fidelity Total Bond ETF) Start Date:2014-10-09
FBOT (Fidelity Disruptive Automation ETF) Start Date:2023-06-12
FBT (First Trust Amex Biotechnology Index) Start Date:2006-06-23
FBTC (Fidelity Wise Origin Bitcoin Trust) Start Date:2024-01-11
FBUF (Fidelity Dynamic Buffered Equity ETF Fidelity Dynamic Buffered) Start Date:2024-04-11
FBY (Tidal ETF Trust Ii Yieldmax Meta Option Income Strategy ETF) Start Date:2023-07-28
FBZ (First Trust Brazil AlphaDEX ETF) Start Date:2011-04-19
FCA (First Trust China AlphaDEX ETF) Start Date:2011-04-21
FCAL (First Trust California Municipal High Income ETF) Start Date:2017-06-27
FCBD (The Advisors' Inner Circle Fund Ii Frontier Asset Core Bond) Start Date:2024-12-20
FCEF (First Trust Cef Income Opportunity ETF) Start Date:2016-09-29
FCFY (First Trust Exchange-Traded Fund First Trust S&P 500 Diversifi) Start Date:2023-08-28
FCG (First Trust Natural Gas ETF) Start Date:2007-05-11
FCLD (Fidelity Cloud Computing ETF) Start Date:2021-10-07
FCOM (Fidelity MSCI Communication Services Index ETF) Start Date:2013-10-24
FCOR (Fidelity Corporate Bond ETF) Start Date:2014-10-09
FCPI (Fidelity Stocks For Inflation ETF) Start Date:2019-11-07
FCSH (Federated Hermes ETF Trust Federated Hermes Short Duration Cor) Start Date:2021-12-17
FCTE (Smi 3Fourteen Full-Cycle Trend ETF) Start Date:2024-07-02
FCTR (First Trust Exchange-Traded Fund) Start Date:2018-07-26
FCUS (Tidal ETF Trust Ii Pinnacle Focused Opportunities ETF) Start Date:2022-12-30
FCVT (First Trust Ssi Strat Convert Secs ETF) Start Date:2015-11-04
FDAT (Return Stacked Bonds & Managed Futures ETF Tactical Advantage) Start Date:2023-04-20
FDCE (Affinity World Leaders Equity ETF Foundations Dynamic Core ETF) Start Date:2023-10-26
FDCF (Fidelity Disruptive Communications ETF) Start Date:2023-06-12
FDD (First Trust STOXX European Sel Div ETF) Start Date:2007-08-30
FDEC (FTCboe Vest U.S. Equity Buffer ETF - December) Start Date:2020-12-21
FDEM (Fidelity Emerging Markets Multifactor ETF) Start Date:2019-02-28
FDEV (Fidelity Emerging Markets Multifactor ETF) Start Date:2019-02-28
FDFF (Fidelity Disruptive Finance ETF) Start Date:2023-06-12
FDG (American Century Focused Dynamic Growth ETF) Start Date:2020-04-02
FDGR (Affinity World Leaders Equity ETF Foundations Dynamic Growth E) Start Date:2023-10-26
FDHT (Fidelity Digital Health ETF) Start Date:2021-10-07
FDHY (Fidelity High Yield Factor ETF) Start Date:2018-06-14
FDIF (Fidelity Disruptors ETF) Start Date:2023-06-20
FDIG (Fidelity Crypto Industry And Digital Payments ETF) Start Date:2022-04-21
FDIS (Fidelity MSCI Consumer Discretionary Index ETF) Start Date:2013-10-24
FDIV (First Trust Strategic Income ETF) Start Date:2023-09-20
FDL (First Trust Morningstar Dividend Leaders) Start Date:2006-03-15
FDLO (Fidelity Low Volatility Factor ETF) Start Date:2016-09-15
FDLS (Northern Lights Fund Trust Iv Inspire Fidelis Multi Factor ETF) Start Date:2022-08-24
FDM (First Trust Dow Jones Select Microcap Index Fund) Start Date:2005-09-30
FDMO (Fidelity Momentum Factor ETF) Start Date:2016-09-15
FDN (First Trust Dow Jones Internet Index) Start Date:2006-06-23
FDND (First Trust Exchange-Traded Fund Iv FTVest Dow Jones Internet) Start Date:2024-03-28
FDNI (First Trust Dow Jones International Internet ETF) Start Date:2018-11-07
FDRR (Fidelity Dividend ETF For Rising Rates) Start Date:2016-09-15
FDRV (Fidelity Electric Vehicles And Future Transportation ETF) Start Date:2021-10-07
FDT (First Trust Dev Mkts Ex-Us AlphaDEX ETF) Start Date:2011-04-19
FDTB (Affinity World Leaders Equity ETF Foundations Dynamic Income E) Start Date:2023-12-14
FDTS (First Trust Devmkts Exus Sc AlphaDEXetf) Start Date:2012-02-16
FDTX (Fidelity Disruptive Technology ETF) Start Date:2023-06-12
FDV (First Trust DB Strategic Value) Start Date:2022-11-16
FDVL (Affinity World Leaders Equity ETF Foundations Dynamic Value Et) Start Date:2023-10-12
FDVV (Fidelity Core Dividend ETF) Start Date:2016-09-15
FDWM (Fidelity Women's Leadership ETF) Start Date:2021-06-17
FEAC (Fidelity Covington Trust Fidelity Enhanced U.S. All-Cap Equity) Start Date:2020-04-27
FEAT (Yieldmax Dorsey Wright Featured 5 Income ETF) Start Date:2024-12-17
FEBP (Pgim Us Large-Cap Buffer 12 ETF - January Pgim Us Large-Cap Bu) Start Date:2024-02-01
FEBT (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 Feb E) Start Date:2023-02-01
FEBW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 Feb E) Start Date:2023-02-01
FEBZ (Trueshares Structured Outcome) Start Date:2021-02-01
FEDL (Etracs 2X Leveraged Ifed Invest With The Fed Tr Index ETN) Start Date:2021-09-15
FEDM (Flexshares ESG & Climate Developed Markets Ex-Us Core Index Fu) Start Date:2021-09-21
FEGE (The Rbb Fund Trust First Eagle Global Equity ETF) Start Date:2024-12-20
FEHY (Flexshares ESG & Climate High Yield Corporate Core Index Fund) Start Date:2021-09-21
FEIG (Flexshares ESG & Climate Investment Grade Corporate Core Index) Start Date:2021-09-21
FELC (Fidelity Covington Trust Fidelity Enhanced Large Cap Core ETF) Start Date:2023-11-20
FELG (Fidelity Covington Trust Fidelity Enhanced Large Cap Growth Et) Start Date:2023-11-20
FELV (Fidelity Covington Trust Fidelity Enhanced Large Cap Value ETF) Start Date:2023-11-20
FEM (First Trust Emerging Markets AlphaDEX Fund) Start Date:2011-04-19
FEMB (First Trust Emerging Mkts Lcl Ccy Bd ETF) Start Date:2014-11-05
FEMR (Fidelity Covington Trust Fidelity Enhanced Emerging Markets Et) Start Date:2024-11-21
FEMS (First Trust Emerg Mkts Sc AlphaDEX ETF) Start Date:2012-02-17
FENI (Fidelity Covington Trust Fidelity Enhanced International ETF) Start Date:2023-11-20
FENY (Fidelity MSCI Energy Index ETF) Start Date:2013-10-24
FEOE (The Rbb Fund Trust First Eagle Overseas Equity ETF) Start Date:2024-12-20
FEP (First Trust Europe AlphaDEX ETF) Start Date:2011-04-26
FEPI (Rex Fang & Innovation Equity Premium Income ETF) Start Date:2023-10-11
FESM (Fidelity Covington Trust Fidelity Enhanced Small Cap ETF) Start Date:2023-11-20
FETH (Fidelity Ethereum Fund) Start Date:2024-07-23
FEUS (Flexshares ESG & Climate Us Large Cap Core Index Fund) Start Date:2021-09-21
FEUZ (First Trust Eurozone AlphaDEX ETF) Start Date:2014-10-27
FEX (First Trust Large Cap Core AlphaDEX ETF) Start Date:2007-05-10
FEZ (SPDR Dj Euro STOXX 50 ETF) Start Date:2002-10-21
FFEB (FTCboe Vest U.S. Equity Buffer ETF - February) Start Date:2020-02-24
FFHG (Northern Lights Fund Trust Iv) Start Date:2017-06-06
FFIU (Uva Unconstrained Medium-Term Fixed Income ETF) Start Date:2017-08-21
FFLC (Fidelity Fundamental Large Cap Core ETF) Start Date:2024-02-26
FFLG (Fidelity Fundamental Large Cap Growth ETF) Start Date:2024-02-26
FFLS (Northern Lights Fund Trust Ii The Future Fund Long/Short ETF) Start Date:2023-06-21
FFLV (Fidelity Covington Trust Fidelity Fundamental Large Cap Value) Start Date:2024-02-26
FFND (The Future Fund Active ETF) Start Date:2021-08-24
FFOG (Franklin Templeton ETF Trust Franklin Focused Growth ETF) Start Date:2023-11-06
FFSG (Northern Lights Fund Trust Iv) Start Date:2017-11-01
FFSM (Fidelity Fundamental Small-Mid Cap ETF) Start Date:2024-02-26
FFTG (Northern Lights Fund Trust Iv) Start Date:2017-11-01
FFTI (Northern Lights Fund Trust Iv) Start Date:2017-06-06
FFTY (Innovator Ibd 50 ETF) Start Date:2015-04-09
FGD (First Trust Dow Jones Global Sel Div ETF) Start Date:2007-11-27
FGDL (Franklin Templeton Holdings Trust Franklin Responsibly Sourced) Start Date:2022-06-30
FGM (First Trust Germany AlphaDEX ETF) Start Date:2012-02-17
FGRO (Fidelity Growth Opportunities ETF) Start Date:2021-02-04
FGSM (The Advisors' Inner Circle Fund Ii Frontier Asset Global Small) Start Date:2024-12-20
FHEQ (Fidelity Dynamic Buffered Equity ETF Fidelity Hedged Equity Et) Start Date:2024-04-11
FHLC (Fidelity MSCI Health Care Index ETF) Start Date:2013-10-24
FHYS (Federated Hermes Short Duration High Yield ETF) Start Date:2021-12-17
FIAT (Tidal Trust Ii Yieldmax Short Coin Option Income Strategy ETF) Start Date:2024-07-11
FIAX (Tidal ETF Trust Ii Nicholas Fixed Income Alternative ETF) Start Date:2022-11-30
FIBR (iShares Edge Us Fixed Income Bal Risk) Start Date:2016-05-12
FICS (First Trust International Developed Capital Strength ETF) Start Date:2020-12-16
FID (First Trust S&P International Dividend Aristocrats ETF) Start Date:2013-08-23
FIDI (Fidelity International High Dividend ETF) Start Date:2018-01-18
FIDU (Fidelity MSCI Industrials Index ETF) Start Date:2013-10-24
FIGB (Fidelity Investment Grade Bond ETF) Start Date:2021-03-04
FIHD (Ubs Ag Fi Enhanced Global High Yield ETN) Start Date:2016-02-22
FIIG (First Trust Exchange-Traded Fund Iv First Trust Intermediate D) Start Date:2023-08-03
FILL (iShares MSCI Global Energy Producers) Start Date:2012-02-02
FINE (Themes European Luxury ETF) Start Date:2023-12-15
FINT (The Advisors' Inner Circle Fund Ii Frontier Asset Total Intern) Start Date:2024-12-20
FINX (Global X Fintech Thematic ETF) Start Date:2016-09-13
FIRI (Tidal ETF Trust Fire Funds Income Target ETF) Start Date:2024-11-19
FIRS (Tidal ETF Trust Fire Funds Wealth Builder ETF) Start Date:2024-11-19
FISR (SPDR Ssga Fixed Income Sector Rotation ETF) Start Date:2019-04-03
FITE (SPDR S&P Kensho Future Security ETF) Start Date:2017-12-27
FIVA (Fidelity International Value Factor ETF) Start Date:2018-01-18
FIVG (Defiance Next Gen Connectivity ETF) Start Date:2019-03-05
FIVY (Yieldmax Dorsey Wright Hybrid 5 Income ETF) Start Date:2024-12-17
FIW (First Trust Ise Water Index Fund) Start Date:2007-05-11
FIXD (First Trust TCWOpportunistic Fixed Income ETF) Start Date:2017-02-15
FIXP (Tidal ETF Trust Foliobeyond Enhanced Fixed Income Premium ETF) Start Date:2025-01-23
FIXT (Procure Disaster Recovery Strategy ETF) Start Date:2022-06-01
FJAN (FTCboe Vest U.S. Equity Buffer ETF - January) Start Date:2021-01-19
FJP (First Trust Japan AlphaDEX ETF) Start Date:2011-04-26
FJUL (FTCboe Vest U.S. Equity Buffer ETF - July Series) Start Date:2020-07-20
FJUN (FTCboe Vest U.S. Equity Buffer ETF - June) Start Date:2020-06-22
FKU (First Trust United Kingdom AlphaDEX ETF) Start Date:2012-02-27
FLAG (Weatherstorm Forensic Accntg Lg-Shrt ETF) Start Date:2021-11-01
FLAO (Aim ETF Products Trust Allianzim Us Equity 6 Month Floor5 Ap) Start Date:2024-04-01
FLAU (Franklin FTSE Australia ETF) Start Date:2017-11-06
FLAX (Franklin FTSE Asia Ex Japan ETF) Start Date:2018-02-08
FLBL (Franklin Templeton ETF Trust) Start Date:2018-06-01
FLBR (Franklin FTSE Brazil ETF) Start Date:2017-11-06
FLCA (Franklin FTSE Canada ETF) Start Date:2017-11-06
FLCB (Franklin Liberty U.S. Core Bond ETF) Start Date:2019-09-19
FLCC (Federated Hermes ETF Trust Federated Hermes Mdt Large Cap Core) Start Date:2024-07-31
FLCE (The Advisors' Inner Circle Fund Ii Frontier Asset U.S. Large C) Start Date:2024-12-20
FLCG (Federated Hermes ETF Trust Federated Hermes Mdt Large Cap Growth) Start Date:2024-07-31
FLCH (Franklin FTSE China ETF) Start Date:2017-11-06
FLCO (Franklin Liberty Investment Grd ETF) Start Date:2016-10-05
FLCV (Federated Hermes ETF Trust Federated Hermes Mdt Large Cap Value) Start Date:2024-07-31
FLDB (Fidelity Low Duration Bond ETF) Start Date:2024-02-26
FLDR (Fidelity Merrimack Street Trust) Start Date:2018-06-14
FLDZ (Rivernorth Volition America Patriot ETF) Start Date:2022-01-03
FLEE (Franklin FTSE Europe ETF) Start Date:2017-11-06
FLEH (Franklin FTSE Europe Hedged ETF) Start Date:2017-11-06
FLEU (Franklin FTSE Eurozone ETF) Start Date:2016-11-08
FLFR (Franklin FTSE France ETF) Start Date:2017-11-06
FLGB (Franklin FTSE United Kingdom ETF) Start Date:2017-11-06
FLGR (Franklin FTSE Germany ETF) Start Date:2017-11-06
FLGV (Franklin Liberty U.S. Treasury Bond ETF) Start Date:2020-06-11
FLHK (Franklin FTSE Hong Kong ETF) Start Date:2017-11-06
FLHY (Franklin Templeton ETF Trust) Start Date:2018-06-01
FLIA (Franklin Templeton ETF Trust) Start Date:2018-06-01
FLIN (Franklin FTSE India ETF) Start Date:2018-02-08
FLIY (Franklin FTSE Italy ETF) Start Date:2017-11-06
FLJH (Franklin FTSE Japan Hedged ETF) Start Date:2017-11-06
FLJJ (Aim ETF Products Trust Allianzim Us Equity 6 Month Floor5 Ja) Start Date:2024-02-01
FLJP (Franklin FTSE Japan ETF) Start Date:2017-11-06
FLKR (Franklin FTSE South Korea ETF) Start Date:2017-11-06
FLLA (Franklin FTSE Latin America ETF) Start Date:2018-10-11
FLLV (Franklin Liberty U.S. Low Volatility ETF) Start Date:2016-09-22
FLMB (Franklin Templeton ETF Trust Franklin Liberty Federal Tax-Free) Start Date:2017-09-05
FLMI (Franklin Templeton ETF Trust Franklin Liberty Federal Intermed) Start Date:2017-09-05
FLMX (Franklin FTSE Mexico ETF) Start Date:2017-11-06
FLN (First Trust Latin America AlphaDEX ETF) Start Date:2011-04-20
FLOT (iShares Floating Rate Bond ETF) Start Date:2011-06-17
FLOW (Global X Funds Global X Us Cash Flow Kings 100 ETF) Start Date:2023-07-13
FLQL (Franklin Libertyq U.S. Equity ETF) Start Date:2017-04-28
FLQM (Franklin Templeton ETF Trust) Start Date:2017-04-28
FLQS (Franklin Templeton ETF Trust) Start Date:2017-04-28
FLRG (Fidelity U.S. Multifactor ETF) Start Date:2020-09-17
FLRN (SPDR Bloomberg Investment Grade Floating Rate ETF) Start Date:2011-12-01
FLRT (AdvisorShares Pacific Asst Enh Fl Rt ETF) Start Date:2015-02-19
FLSA (Franklin FTSE Saudi Arabia ETF) Start Date:2018-10-11
FLSP (Franklin Liberty Systematic Style Premia ETF) Start Date:2019-12-26
FLSW (Franklin FTSE Switzerland ETF) Start Date:2018-02-08
FLTB (Fidelity Term Bond ETF) Start Date:2014-10-09
FLTR (Market Vectors Investment Grade) Start Date:2011-04-26
FLTW (Franklin FTSE Taiwan ETF) Start Date:2017-11-06
FLUD (Franklin Liberty Ultra Short Bond ETF) Start Date:2020-07-16
FLV (American Century Focused Large Cap Value ETF) Start Date:2020-04-02
FLXR (Engine No. 1 ETF Trust TCWFlexible Income ETF) Start Date:2024-06-24
FLYD (Bank Of Montreal Microsectors Travel -3X Inverse Leveraged ETN) Start Date:2022-06-22
FLYU (Bank Of Montreal Microsectors Travel 3X Leveraged ETN) Start Date:2022-06-22
FLZA (Franklin FTSE South Africa ETF) Start Date:2018-10-11
FM (iShares MSCI Frontier 100 ETF) Start Date:2012-09-13
FMAG (Fidelity Magellan ETF) Start Date:2021-02-04
FMAR (FTCboe Vest U.S. Equity Buffer ETF - March) Start Date:2021-03-22
FMAT (Fidelity MSCI Materials ETF) Start Date:2013-10-24
FMAY (FTCboe Vest U.S. Equity Buffer ETF - May) Start Date:2020-05-18
FMB (First Trust Managed Municipal ETF) Start Date:2014-05-15
FMCE (Northern Lights Fund Trust Iv Fm Compounders Equity ETF) Start Date:2024-11-15
FMCX (Northern Lights Fund Trust Iv Fmc Excelsior Focus Equity ETF) Start Date:2022-04-25
FMDE (Fidelity Covington Trust Fidelity Enhanced Mid Cap ETF) Start Date:2023-11-20
FMED (Fidelity Disruptive Medicine ETF) Start Date:2023-06-12
FMET (Fidelity Metaverse ETF) Start Date:2022-04-21
FMF (First Trust Morningstar Managed Futures Strategy Fund) Start Date:2013-08-02
FMHI (First Trust Municipal High Income ETF) Start Date:2017-11-03
FMIL (Fidelity New Millennium ETF) Start Date:2020-06-04
FMNY (First Trust New York Municipal High Income ETF) Start Date:2021-05-13
FMQQ (Fmqq The Next Frontier Internet & Ecommerce ETF) Start Date:2021-09-28
FNCL (Fidelity MSCI Financials Index ETF) Start Date:2013-10-24
FNDA (Schwab Fundamental U.S. Small Company Index ETF) Start Date:2013-08-15
FNDB (Schwab Fundamental Us Broad Market ETF) Start Date:2013-08-15
FNDC (Schwab Fundamental International Small Company Index ETF) Start Date:2013-08-15
FNDE (Schwab Fundamental Emerging Markets Large Company Index ETF) Start Date:2013-08-15
FNDF (Schwab Fundamental International Large Company Index ETF) Start Date:2013-08-15
FNDX (Schwab Fundamental U.S. Large Company Index ETF) Start Date:2013-08-15
FNGD (Bank Of Montreal Microsectors Fang Index 3X Inverse Leveraged ETN Exp 8 Jan 2038) Start Date:2018-01-23
FNGG (Direxion Daily Select Large Caps & Fangs Bull 2X Shares) Start Date:2021-09-30
FNGO (Bank Of Montreal Microsectors Fang Index 2X Leveraged ETN Exp 8 Jan 2038) Start Date:2018-09-04
FNGS (Microsectors Fang ETNs Due January 8) Start Date:2019-11-13
FNGU (Microsectors Fang+â„¢ Index 3X Leveraged ETN) Start Date:2018-01-23
FNK (First Trust Mid Cap Value AlphaDEX ETF) Start Date:2011-04-20
FNOV (FTCboe Vest U.S. Equity Buffer ETF - November) Start Date:2019-11-18
FNX (First Trust Mid Cap Core AlphaDEX Fund) Start Date:2007-05-10
FNY (First Trust Mid Cap Growth AlphaDEX ETF) Start Date:2011-04-20
FOCT (FTCboe Vest U.S. Equity Buffer ETF - October) Start Date:2020-10-19
FOPC (The Advisors' Inner Circle Fund Ii Frontier Asset Opportunistic) Start Date:2024-12-20
FORH (Formidable ETF) Start Date:2021-04-30
FOVL (iShares Focused Value Factor ETF) Start Date:2019-03-21
FOXY (Simplify Exchange Traded Funds Simplify Currency Strategy ETF) Start Date:2025-02-05
FPA (First Trust Asiapac Ex-Jpn AlphaDEX ETF) Start Date:2011-04-20
FPE (First Trust Preferred Securities And Income ETF) Start Date:2013-02-12
FPEI (First Trust Institutional Preferred Securities And Income ETF) Start Date:2017-08-23
FPFD (Fidelity Preferred Securities & Income ETF) Start Date:2021-06-17
FPRO (Fidelity Real Estate Investment ETF) Start Date:2021-02-04
FPX (First Trust Us Equity Opportunities ETF) Start Date:2006-05-24
FPXE (First Trust Ipox Europe Equity Opportunities ETF) Start Date:2018-10-05
FPXI (First Trust International Ipo ETF) Start Date:2014-11-07
FQAL (Fidelity Quality Factor ETF) Start Date:2016-09-15
FRDM (Alpha Architect ETF Trust) Start Date:2019-05-23
FREL (Fidelity MSCI Real Estate Index ETF) Start Date:2015-02-05
FRI (First Trust S&P Reit ETF) Start Date:2007-05-10
FRNW (Fidelity Clean Energy ETF) Start Date:2021-10-07
FRTY (Alger Mid Cap 40 ETF) Start Date:2021-03-01
FSBD (Fidelity Merrimack Street Trust Fidelity Sustainable Core Plus) Start Date:2022-04-21
FSCC (Federated Hermes ETF Trust Federated Hermes Mdt Small Cap Core) Start Date:2024-07-31
FSCS (First Trust Smid Capital Strength ETF) Start Date:2017-06-22
FSEC (Fidelity Investment Grade Securitized ETF) Start Date:2021-03-04
FSEP (FTCboe Vest U.S. Equity Buffer ETF - September Series) Start Date:2020-09-21
FSGS (First Trust Smid Growth Strength ETF) Start Date:2017-06-26
FSIG (First Trust Duration Investment Grade Corporate ETF) Start Date:2021-11-18
FSLD (Fidelity Merrimack Street Trust Fidelity Sustainable Low Durat) Start Date:2022-04-21
FSMB (First Trust Short Duration Managed Municipal ETF) Start Date:2018-11-27
FSMD (Fidelity Small-Mid Multifactor ETF) Start Date:2019-02-28
FSMO (Fidelity Small-Mid Cap Opportunities ETF) Start Date:2021-02-04
FSST (Fidelity Sustainable U.S. Equity ETF) Start Date:2021-06-17
FSTA (Fidelity MSCI Consumer Staples Index ETF) Start Date:2013-10-24
FSYD (Fidelity Covington Trust Fidelity Sustainable High Yield ETF) Start Date:2022-02-17
FSZ (First Trust Switzerland AlphaDEX ETF) Start Date:2012-02-16
FTA (First Trust Large Cap Val AlphaDEX ETF) Start Date:2007-05-17
FTAG (First Trust Indxx Global Agriculture ETF) Start Date:2010-03-31
FTBD (Fidelity Merrimack Street Trust Fidelity Tactical Bond ETF) Start Date:2023-01-26
FTC (First Trust Large Cap Gr AlphaDEX ETF) Start Date:2007-05-23
FTCB (First Trust Exchange-Traded Fund Iv First Trust Core Investmen) Start Date:2023-11-08
FTCE (First Trust Exchange-Traded Fund Vi First Trust New Constructs) Start Date:2024-10-03
FTCS (First Trust Capital Strength ETF) Start Date:2007-05-16
FTDS (First Trust Dividend Strength ETF) Start Date:2007-05-16
FTEC (Fidelity MSCI Information Technology Index ETF) Start Date:2013-10-24
FTGC (First Trust Global Tactical Commodity Strategy Fund) Start Date:2013-10-23
FTGS (First Trust Growth Strength ETF) Start Date:2022-10-26
FTHF (First Trust Exchange-Traded Fund Ii First Trust Emerging Marke) Start Date:2023-11-07
FTHI (First Trust High Income ETF) Start Date:2014-01-07
FTIF (First Trust Exchange-Traded Fund First Trust Bloomberg Inflati) Start Date:2023-03-14
FTKI (First Trust Exchange-Traded Fund Vi First Trust Small Cap Buyw) Start Date:2025-02-28
FTLS (First Trust Long/Short Equity Fund) Start Date:2014-09-09
FTQI (First Trust Nasdaq Buywrite Income ETF) Start Date:2014-01-07
FTRB (Federated Hermes ETF Trust Federated Hermes Total Return Bond) Start Date:2024-01-04
FTRI (First Trust Indxx Glbl Natrl Res Inc ETF) Start Date:2010-03-12
FTSD (Franklin Liberty Short Dur Us Govt ETF) Start Date:2013-11-05
FTSL (First Trust Senior Loan Exchange-Traded Fund) Start Date:2013-05-02
FTSM (First Trust Enhanced Short Maturity ETF) Start Date:2014-08-06
FTWO (Ea Series Trust Strive Faang 2.0 ETF) Start Date:2023-08-31
FTXG (First Trust Nasdaq Food & Beverage ETF) Start Date:2016-10-10
FTXH (First Trust Nasdaq Pharmaceuticals ETF) Start Date:2016-09-22
FTXL (First Trust Nasdaq Semiconductor ETF) Start Date:2016-09-21
FTXN (First Trust Nasdaq Oil & Gas ETF) Start Date:2016-09-23
FTXO (First Trust Nasdaq Bank ETF) Start Date:2016-10-07
FTXR (First Trust Nasdaq Transportation ETF) Start Date:2016-09-22
FUE (Elements Mlcx Biofuels Exch Ser Tr ETN) Start Date:2008-02-15
FUMB (First Trust Ultra Short Duration Municipal ETF) Start Date:2018-11-05
FUNL (Cornercap Fundametrics Large-Cap ETF) Start Date:2020-08-20
FUSI (American Century ETF Trust American Century Multisector Floati) Start Date:2023-03-16
FUTS () Start Date:2014-10-06
FUTY (Fidelity MSCI Utilities ETF) Start Date:2013-10-24
FV (First Trust Dorsey Wright Focus 5 ETF) Start Date:2014-03-06
FVAL (Fidelity Value Factor ETF) Start Date:2016-09-15
FVC (First Trust Dorsey Wright Dynamic Foc 5) Start Date:2016-03-18
FVD (First Trust Value Line Dividend Index) Start Date:2003-10-09
FWD (Ab Active ETFs Ab Disruptors ETF) Start Date:2023-03-22
FXA (Rydex Currency Shares Australian) Start Date:2006-06-26
FXB (Currencyshares British Pound Ster ETF) Start Date:2006-06-26
FXC (Rydex Currencyshares Canadian D) Start Date:2006-06-26
FXD (First Trust Consumer Discretionary AlphaDEX Fund) Start Date:2007-05-22
FXE (Currencyshares Euro Trust) Start Date:2005-12-12
FXED (Sound Enhanced Fixed Income ETF) Start Date:2020-12-31
FXF (Currencyshares Swiss Franc ETF) Start Date:2006-06-26
FXG (First Trust Consumer Staples AlphaDEX Fund) Start Date:2007-05-10
FXH (First Trust Health Care AlphaDEX Fund) Start Date:2007-05-21
FXI (iShares FTSE China 25 Index Fund) Start Date:2004-10-08
FXL (First Trust Technology AlphaDEX Fund) Start Date:2007-05-29
FXN (First Trust Energy AlphaDEX Fund) Start Date:2007-05-10
FXO (First Trust Financials AlphaDEX Fund) Start Date:2007-05-10
FXP (ProShares Ultrashort FTSE China 50) Start Date:2007-11-08
FXR (First Trust Industrials/Producer Durables AlphaDEX Fund) Start Date:2007-05-24
FXU (First Trust Utilities AlphaDEX ETF) Start Date:2007-05-10
FXY (Rydex Currencyshares Japanese) Start Date:2007-02-13
FXZ (First Trust Materials AlphaDEX Fund) Start Date:2007-05-11
FYC (First Trust Small Cap Growth AlphaDEX Fund) Start Date:2011-04-20
FYEE (Fidelity Dynamic Buffered Equity ETF Fidelity Yield Enhanced E) Start Date:2024-04-11
FYLD (Cambria Foreign Shareholder Yield ETF) Start Date:2013-12-03
FYLG (Global X Funds Global X Financials Covered Call & Growth ETF) Start Date:2022-11-23
FYT (First Trust Small Cap Value AlphaDEX Fund) Start Date:2011-04-20
FYX (First Trust Small Cap Core AlphaDEX Fund) Start Date:2007-05-10
GAA (Cambria Global Asset Allocation ETF) Start Date:2014-12-10
GABF (Gabelli ETFs Trust Gabelli Financial Services Opportunities Et) Start Date:2022-05-10
GAEM (Simplify Exchange Traded Funds Simplify Gamma Emerging Market) Start Date:2024-08-13
GAL (SPDR Ssga Global Allocation ETF) Start Date:2012-04-26
GAMR (Purefunds Video Game Tech ETF) Start Date:2016-03-10
GAPR (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-04-24
GARP (iShares MSCI Usa Quality Garp ETF) Start Date:2024-06-03
GAST (Gabelli Automation ETF) Start Date:2022-01-05
GAUG (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-08-21
GAZ (iPath Bloomberg Natural Gas Subtr ETN) Start Date:2017-05-11
GBF (iShares Government/Credit Bond) Start Date:2007-01-11
GBIL (Goldman Sachs Treasury Access 0-1 Year ETF) Start Date:2016-09-08
GBLD (Invesco MSCI Green Building ETF) Start Date:2021-04-22
GBTC (Grayscale Bitcoin Trust) Start Date:2015-05-04
GBUY (Goldman Sachs Future Consumer Equity ETF) Start Date:2021-11-11
GCAD (Gabelli Commercial Aerospace And Defense ETF) Start Date:2023-01-04
GCAL (Goldman Sachs ETF Trust Goldman Sachs Dynamic California Muni) Start Date:2024-07-31
GCC (WisdomTree Continuous Commodity ETF) Start Date:2008-01-24
GCLN (Goldman Sachs ETF Trust Goldman Sachs Bloomberg Clean Energy E) Start Date:2022-02-10
GCOR (Goldman Sachs ETF Trust Goldman Sachs Access U.S. Aggregate Bo) Start Date:2020-09-10
GCOW (Pacer Global Cash Cows Dividend ETF) Start Date:2017-01-13
GDEC (FTVest Us Equity Moderate Buffer ETF - December) Start Date:2023-12-18
GDIV (Harbor ETF Trust Harbor Dividend Growth Leaders ETF) Start Date:2022-05-23
GDMA (Gadsdena Dynamica Multi-Asseta ETF) Start Date:2018-11-15
GDOC (Goldman Sachs Future Health Care Equity ETF) Start Date:2021-11-11
GDVD (Principal Exchange-Traded Funds) Start Date:2022-03-31
GDX (Market Vectors Gold Miners ETF) Start Date:2006-05-22
GDXD (Microsectors Gold Miners -3X Inverse Leveraged ETNs) Start Date:2020-12-03
GDXJ (Market Vectors Junior Gold Mine) Start Date:2009-11-11
GDXU (Microsectors Gold Miners 3X Leveraged ETN) Start Date:2020-12-03
GDXY (Tidal Trust Ii Yieldmax Gold Miners Option Income Strategy ETF) Start Date:2024-05-21
GEM (Goldman Sachs Activebeta Emerging Markets Equity ETF) Start Date:2015-09-29
GEMD (Goldman Sachs ETF Trust Goldman Sachs Access Emerging Markets) Start Date:2022-02-17
GEME (Pacific North Of South Em Equity Active ETF) Start Date:2025-01-23
GEND (Spinnaker ETF Series Genter Capital Dividend Income ETF) Start Date:2025-04-15
GENM (Spinnaker ETF Series Genter Capital Municipal Quality Intermed) Start Date:2024-05-22
GENT (Spinnaker ETF Series Genter Capital Taxable Quality Intermedia) Start Date:2024-05-22
GENW (Spinnaker ETF Series Genter Capital International Dividend ETF) Start Date:2025-01-14
GENY (Principal Millennials ETF) Start Date:2016-08-22
GERM (ETFmg Treatments Testing And Advancements ETF) Start Date:2020-06-18
GFEB (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-02-21
GFGF (Guru Favorite Stocks ETF) Start Date:2021-12-16
GFLW (Victoryshares Free Cash Flow Growth ETF) Start Date:2024-12-05
GFOF (ETF Series Solutions Grayscale Future Of Finance ETF) Start Date:2022-02-02
GGLL (Direxion Daily Googl Bull 1.5X Shares) Start Date:2022-09-07
GGLS (Direxion Daily Googl Bear 1X Shares) Start Date:2022-09-07
GGM (Northern Lights Fund Trust Ii Ggm Macro Alignment ETF) Start Date:2023-09-26
GGME (Invesco Next Gen Media And Gaming ETF) Start Date:2007-05-16
GGRW (Gabelli Growth Innovators ETF) Start Date:2021-02-16
GGUS (Goldman Sachs ETF Trust Goldman Sachs Marketbeta Russell 1000) Start Date:2023-12-22
GHEE (Collaborative Investment Series Trust Goose Hollow Enhanced Eq) Start Date:2023-11-20
GHMS (Collaborative Investment Series Trust Goose Hollow Multi-Strat) Start Date:2023-11-15
GHTA (Goose Hollow Tactical Allocation ETF) Start Date:2021-11-17
GHYB (Goldman Sachs Access High Yield Corporate Bond ETF) Start Date:2017-09-07
GHYG (iShares Global High Yield Corporate Bond) Start Date:2012-04-05
GIAX (Tidal Trust Ii Nicholas Global Equity And Income ETF) Start Date:2024-07-30
GIGB (Goldman Sachs Access Investment Grade Corporate Bond ETF) Start Date:2017-06-08
GII (SPDR S&P Global Infrastructure ETF) Start Date:2007-01-31
GINN (Goldman Sachs Innovate Equity ETF) Start Date:2020-11-09
GINX (Sgi Enhanced Global Income ETF) Start Date:2024-02-29
GJAN (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-01-23
GJUL (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-07-24
GJUN (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-06-20
GK (AdvisorShares Gerber Kawasaki ETF) Start Date:2021-07-02
GLCN (Vaneck Vectors China Growth Leaders ETF) Start Date:2010-10-14
GLD (SPDR Gold Shares) Start Date:2004-11-18
GLDB (Strategy Shares Gold-Hedged Bond ETF) Start Date:2021-05-18
GLDI (Credit Suisse Ag) Start Date:2007-05-25
GLDM (SPDR Gold Minishares Trust) Start Date:2018-06-26
GLDX (Global X Gold Explorers ETF) Start Date:2021-11-03
GLIF (Agfiq Global Infrastructure ETF) Start Date:2019-05-23
GLIN (Vaneck Vectors India Growth Leaders ETF) Start Date:2010-08-25
GLL (ProShares Ultrashort Gold) Start Date:2008-12-03
GLOF (iShares Global Equity Factor ETF) Start Date:2023-03-01
GLOV (Goldman Sachs ETF Trust Goldman Sachs Activebeta World Low Vol) Start Date:2007-05-16
GLRY (Northern Lights Fund Trust Iv Inspire Faithward Mid Cap Moment) Start Date:2020-12-08
GLTR (Aberdeen Standard Physical Precious Metals Basket Shares ETF) Start Date:2010-10-22
GMAR (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-03-20
GMAY (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-05-22
GMF (SPDR S&P Emerging Asia Pacific ETF) Start Date:2007-03-23
GMMA (Tidal Trust Iii Gammaroad Market Navigation ETF) Start Date:2024-09-17
GMMF (Blackrock ETF Trust iShares Government Money Market ETF) Start Date:2025-02-06
GMNY (Goldman Sachs ETF Trust Goldman Sachs Dynamic New York Municip) Start Date:2024-09-13
GMOI (The 2023 ETF Series Trust Ii Gmo International Value ETF) Start Date:2024-10-29
GMOM (Cambria Global Momentum ETF) Start Date:2014-11-04
GMOV (The 2023 ETF Series Trust Ii Gmo Us Value ETF) Start Date:2024-10-29
GMUB (Goldman Sachs ETF Trust Goldman Sachs Municipal Income ETF) Start Date:2024-07-25
GMUN (Goldman Sachs ETF Trust Goldman Sachs Community Municipal Bond) Start Date:2023-03-09
GNMA (iShares Gnma Bond) Start Date:2012-02-17
GNOM (Global X Genomics & Biotechnology ETF) Start Date:2019-04-10
GNOV (FTVest Us Equity Moderate Buffer ETF - November) Start Date:2023-11-20
GNR (SPDR S&P Global Natural Resources ETF) Start Date:2010-09-14
GOAU (Us Global Go Gold And Precious Metal Miners ETF) Start Date:2017-06-28
GOCT (FTVest Us Equity Moderate Buffer ETF - October) Start Date:2023-10-23
GOEX (Global X Gold Explorers ETF) Start Date:2010-11-04
GOLY (Strategy Shares Gold-Hedged Bond ETF) Start Date:2024-02-01
GOOP (Neos ETF Trust Kurv Yield Premium Strategy Google) Start Date:2023-10-31
GOOX (ETF Opportunities Trust T-Rex 2X Long Alphabet Daily Target Et) Start Date:2024-01-11
GOOY (Tidal ETF Trust Ii Yieldmax Googl Option Income Strategy ETF) Start Date:2023-07-28
GOP (Unusual Whales Subversive Republican Trading ETF) Start Date:2017-10-17
GOVI (Invesco Equal Weight 0-30 Year Treasury ETF) Start Date:2007-10-11
GOVT (iShares Us Treasury Bond) Start Date:2012-02-24
GOVZ (iShares 25 Year Treasury Strips Bond ETF) Start Date:2020-09-24
GPIQ (Goldman Sachs Nasdaq-100 Core Premium Income ETF) Start Date:2023-10-26
GPIX (Goldman Sachs S&P 500 Core Premium Income ETF) Start Date:2023-10-26
GPOW (Goldman Sachs ETF Trust Goldman Sachs North American Pipelines) Start Date:2023-07-14
GPRF (Goldman Sachs Access U.S. Preferred Stock And Hybrid Securities) Start Date:2024-08-01
GPTY (Tidal Trust Ii Yieldmax AI & Tech Portfolio Option Income ETF) Start Date:2025-01-23
GQI (Natixis ETF Trust Natixis Gateway Quality Income ETF) Start Date:2023-12-13
GQQQ (Astoria Us Quality Growth Kings ETF) Start Date:2024-10-01
GQRE (Flexshares Global Quality Real Estate Index Fund) Start Date:2013-11-06
GREI (Goldman Sachs Future Real Estate And Infrastructure Equity ETF) Start Date:2021-11-11
GREK (Global X MSCI Greece ETF) Start Date:2011-12-08
GRES (IQ Global Resources ETF) Start Date:2009-10-27
GRID (First Trust Nasdaq Cln Edgestgidifsetf) Start Date:2009-11-17
GRN (iPath Global Carbon ETN) Start Date:2021-05-25
GRNB (Vaneck Vectors Green Bond ETF) Start Date:2017-03-06
GRNY (Tidal ETF Trust Fundstrat Granny Shots Us Large Cap ETF) Start Date:2024-11-07
GRPM (Invesco S&P Midcap 400 Garp ETF) Start Date:2010-12-08
GRPZ (Invesco Exchange-Traded Fund Trust Ii Invesco S&P Smallcap 600) Start Date:2024-04-01
GRU (Elements Mlcx Grains Tr ETN) Start Date:2008-02-15
GRW (Engine No. 1 ETF Trust TCWCompounders ETF) Start Date:2024-05-07
GSC (Gs Connect S&P Gsci Enh Commodity Tr ETN) Start Date:2023-10-05
GSEE (Goldman Sachs Marketbeta Emerging Markets Equity ETF) Start Date:2020-05-15
GSEP (FTVest Us Equity Moderate Buffer ETF - September) Start Date:2023-09-18
GSEU (Goldman Sachs Activebeta Europe Eq ETF) Start Date:2016-03-02
GSEW (Goldman Sachs ETF Trust) Start Date:2017-09-14
GSFP (Goldman Sachs Future Planet Equity ETF) Start Date:2021-07-15
GSG (iShares S&P Gsci Commodity-Indexed Trust) Start Date:2006-07-21
GSIB (Themes Global Systemically Important Banks ETF) Start Date:2023-12-15
GSID (Goldman Sachs Marketbeta International Equity ETF) Start Date:2020-05-15
GSIE (Goldman Sachs Activebeta International Equity ETF) Start Date:2015-11-10
GSIG (Golden Sachs ETF Trust Goldman Sachs Access Investment Grade C) Start Date:2020-07-09
GSJY (Goldman Sachs Activebeta Japan Eq ETF) Start Date:2016-03-04
GSLC (Goldman Sachs Activebeta U.S. Large Cap Equity ETF) Start Date:2015-09-21
GSP (iPath S&P Gsci Total Return ETN) Start Date:2006-06-07
GSPY (Gotham Enhanced 500 ETF) Start Date:2020-12-29
GSSC (Goldman Sachs Activebeta Us Small Cap Equity ETF) Start Date:2017-06-29
GSST (Goldman Sachs ETF Trust) Start Date:2019-04-17
GSUS (Goldman Sachs Marketbeta U.S. Equity ETF) Start Date:2020-05-15
GSY (Invesco Ultra Short Duration ETF) Start Date:2008-02-12
GTEK (Goldman Sachs Future Tech Leaders Equity ETF) Start Date:2021-09-16
GTIP (iShares Global Inflation Linked) Start Date:2018-10-04
GTO (Invesco Total Return Bond ETF) Start Date:2016-02-10
GTOS (Invesco Short Duration Total Return Bond ETF) Start Date:2025-02-24
GTR (WisdomTree Target Range Fund) Start Date:2021-10-07
GUMI (Goldman Sachs ETF Trust Goldman Sachs Ultra Short Municipa) Start Date:2024-08-19
GUNR (Flexshares Global Upstream) Start Date:2011-09-22
GURU (Global X Guru ETF) Start Date:2012-06-05
GUSA (Goldman Sachs ETF Trust Ii Goldman Sachs Marketbeta Us 1000) Start Date:2022-04-18
GUSH (Direxion Daily S&P Oil & Gas Exploration & Production Bull 2X Shares) Start Date:2015-05-29
GVAL (Cambria Global Value ETF) Start Date:2014-03-12
GVI (iShares Intermediate Government/Credit Bond ETF) Start Date:2007-01-11
GVIP (Goldman Sachs Hedge Industry Vip ETF) Start Date:2016-11-03
GVLU (Tidal ETF Trust Gotham 1000 Value ETF) Start Date:2022-06-08
GVUS (Goldman Sachs ETF Trust Goldman Sachs Marketbeta Russell 1000) Start Date:2023-12-22
GWX (SPDR S&P International Small Cap ETF) Start Date:2007-04-26
GXC (SPDR S&P China ETF) Start Date:2007-03-23
GXDW (Global X Dorsey Wright Thematic ETF) Start Date:2019-11-04
GXG (Global X MSCI Colombia ETF) Start Date:2009-02-09
GXPC (Global X Purecap MSCI Communication Services ETF) Start Date:2025-07-24
GXPD (Global X Purecap MSCI Consumer Discretionary ETF) Start Date:2025-07-24
GXPE (Global X Purecap MSCI Energy ETF) Start Date:2025-07-24
GXPT (Global X Purecap MSCI Information Technology ETF) Start Date:2025-07-24
GXTG (Global X Thematic Growth ETF) Start Date:2019-11-04
GXUS (Goldman Sachs ETF Trust Ii Goldman Sachs Marketbeta Total) Start Date:2023-11-13
GYLD (Arrow Dow Jones Global Yield ETF) Start Date:2012-05-08
HACK (ETFmg Prime Cyber Security ETF) Start Date:2014-11-12
HAIL (SPDR S&P Smart Mobility ETF) Start Date:2017-12-27
HAP (Vaneck Vectors Natural Resources ETF) Start Date:2008-09-03
HAPI (Harbor Human Capital Factor Us Large Cap ETF) Start Date:2022-10-13
HAPR (Shl Telemedicine Innovator Premium Income 9 Buffer ETF - A) Start Date:2024-04-01
HAPS (Harbor Human Capital Factor Us Small Cap ETF) Start Date:2023-04-13
HAPY (Harbor Human Capital Factor Unconstrained ETF) Start Date:2022-02-24
HARD (Simplify Exchange Traded Funds Simplify Commodities Strategy N) Start Date:2023-03-28
HART (IQ Healthy Hearts ETF) Start Date:2021-01-14
HAUS (Tidal ETF Trust Residential Reit ETF) Start Date:2022-03-01
HAUZ (Xtrackers International Real Estate ETF) Start Date:2013-10-01
HAWX (iShares Currency Hedged MSCI Acwi Ex Us) Start Date:2015-07-01
HBTA (Horizon Funds Horizon Expedition Plus ETF) Start Date:2011-05-27
HCMT (Direxion Shares ETF Trust Direxion Hcm Tactical Enhanced Us Et) Start Date:2023-06-22
HCOM (Hartford Schroders Commodity Strategy ETF) Start Date:2021-09-15
HCOW (Amplify Cash Flow High Income ETF) Start Date:2023-09-20
HCRB (Hartford Funds Exchange-Traded Trust) Start Date:2020-02-20
HDAW (Deutsche X-Trackers MSCIawdexushdvydhgeq) Start Date:2015-08-14
HDEF (Xtrackers MSCI Eafe High Dividend Yield Equity ETF) Start Date:2015-08-18
HDG (ProShares Hedge Replication) Start Date:2011-07-14
HDGE (AdvisorShares Ranger Equity Bear ETF) Start Date:2011-01-27
HDLB (Etracs Monthly Pay 2Xleveraged Us High Dividend Low Volatility) Start Date:2019-10-25
HDMV (First Trust Hrzn Mgdvolatil Dev Intl ETF) Start Date:2016-08-26
HDRO (ETF Series Solutions Defiance Next Gen H2 ETF) Start Date:2021-03-10
HDUS (Lattice Strategies Trust Hartford Disciplined Us Equity ETF) Start Date:2022-11-17
HDV (iShares Core High Dividend ETF) Start Date:2011-03-31
HEAL (Global X Healthtech ETF) Start Date:2020-07-30
HEAT (Touchstone ETF Trust Touchstone Climate Transition ETF) Start Date:2023-05-02
HECO (Strategy Shs Ecological Strategy ETF) Start Date:2024-09-10
HEDJ (WisdomTree Europe Hedged Equity ETF) Start Date:2009-12-31
HEEM (iShares Currency Hedged MSCI Emerging Markets ETF) Start Date:2014-09-25
HEFA (iShares Currency Hedged MSCI Eafe ETF) Start Date:2014-02-14
HEGD (Swan Hedged Equity Us Large Cap ETF) Start Date:2020-12-23
HEJD (Victoryshares Hedged Equity Income ETF) Start Date:2024-07-11
HELO (JP Morgan Exchange-Traded Fund Trust JP Morgan Hedged Equity) Start Date:2023-09-29
HELX (Franklin Genomic Advancements ETF) Start Date:2020-02-27
HEQT (Simplify Hedged Equity ETF) Start Date:2021-11-02
HERD (Pacer Cash Cows Fund Of Funds ETF) Start Date:2019-05-07
HERO (Global X Video Games & Esports ETF) Start Date:2019-10-31
HEWC (iShares Currency Hedged MSCI Canada) Start Date:2015-07-01
HEWG (iShares Currency Hedged MSCI Germany) Start Date:2014-02-18
HEWJ (iShares Currency Hedged MSCI Japan ETF) Start Date:2014-02-05
HEWU (iShares Currency Hedged MSCI Uk) Start Date:2015-07-09
HEZU (iShares Currency Hedged MSCI Eurozone ETF Of iShares Trust) Start Date:2014-08-22
HF (Return Stacked Bonds & Managed Futures ETF Dga Absolute Return) Start Date:2023-08-03
HFND (Tidal ETF Trust Unlimited Hfnd Multi-Strategy Return Tracker E) Start Date:2022-10-11
HFSI (Hartford Strategic Income ETF) Start Date:2025-04-15
HFSP (Tradersai Large Cap Equity & Cash ETF) Start Date:2024-10-24
HFXI (IQ 50 Percent Hedged FTSE Intl ETF) Start Date:2015-07-22
HGER (Harbor Commodity All-Weather Strategy ETF) Start Date:2022-02-10
HIBL (Direxion Daily S&P 500 High Beta Bull 3X Shares) Start Date:2019-11-07
HIBS (Direxion Daily S&P 500 High Beta Bear 3X Shares) Start Date:2019-11-07
HIDE (Ea Series Trust Alpha Architect High Inflation And Deflation E) Start Date:2022-11-17
HIDV (Ab Active ETFs Ab Us High Dividend ETF) Start Date:2023-03-22
HIGH (Simplify Exchange Traded Funds Simplify Enhanced Income ETF) Start Date:2022-10-28
HIPS (Graniteshares Hips Us High Income ETF) Start Date:2015-01-07
HISF (First Trust High Income Strategic Focus ETF) Start Date:2014-08-14
HIYS (Invesco Actively Managed Exchange-Traded Fund Trus Invesco Hig) Start Date:2023-01-23
HJAN (Innovator ETFs Trust Innovator Premium Income 9 Buffer ETF - J) Start Date:2024-01-02
HJEN (Direxion Hydrogen ETF) Start Date:2021-03-25
HJUL (Shl Telemedicine Innovator Premium Income 9 Buffer) Start Date:2024-07-01
HKND (Humankind Us Stock ETF) Start Date:2021-02-24
HLAL (Wahed FTSE Usa Shariah ETF) Start Date:2019-07-16
HLGE (Hartford Longevity Economy ETF) Start Date:2021-03-17
HMOP (Hartford Municipal Opportunities ETF) Start Date:2017-12-14
HNDL (Nasdaq 7Handl Index ETF) Start Date:2018-01-17
HOCT (Innovator ETFs Trust Innovator Premium Income 9 Buffer ETF - O) Start Date:2023-10-02
HODL (Vaneck Bitcoin Trust) Start Date:2024-01-11
HOLD (AdvisorShares Sage Core Reserves ETF) Start Date:2014-01-15
HOM (Lifegoal Home Down Payment Investment ETF) Start Date:2021-09-09
HOMZ (Hoya Capital Housing ETF) Start Date:2019-03-20
HQGO (Hartford Us Quality Growth ETF) Start Date:2023-12-06
HRTS (Tema Cardiovascular And Metabolic ETF) Start Date:2023-11-21
HSCZ (iShares Currency Hedged MSCI Eafe Sm-Cp) Start Date:2015-07-14
HSMV (First Trust Horizon Managed Volatility Small/Mid ETF) Start Date:2020-04-07
HSRT (Hartford Funds Exchange-Traded Trust) Start Date:2018-05-31
HSUN (Hartford Sustainable Income ETF) Start Date:2021-09-22
HTAB (Hartford Schroders Tax-Aware Bond ETF) Start Date:2018-04-19
HTAX (Macquarie ETF Trust Macquarie National High-Yield Municipal) Start Date:2025-03-06
HTEC (Robo Global Healthcare Technology And Innovation ETF) Start Date:2019-06-25
HTRB (Hartford Total Return Bond ETF) Start Date:2017-09-28
HTUS (Hull Tactical Us ETF) Start Date:2015-06-25
HUSV (First Trust Hrzn Mgdvolatil Domestic ETF) Start Date:2016-08-25
HVAC (AdvisorShares Trust AdvisorShares Hvac And Industrials ETF) Start Date:2025-02-04
HVAL (Alps Hillman Active Value ETF) Start Date:2021-07-16
HWAY (Themes Us Infrastructure ETF) Start Date:2006-02-01
HYBB (iShares Bb Rated Corporate Bond ETF) Start Date:2020-10-08
HYBI (Neos Enhanced Income Credit Select ETF) Start Date:2024-09-30
HYD (Market Vectors High Yield) Start Date:2009-02-05
HYDB (iShares High Yield Bond Factor ETF) Start Date:2017-07-13
HYDR (Global X Hydrogen ETF) Start Date:2021-07-14
HYDW (Xtrackers Low Beta High Yield Bond ETF) Start Date:2018-01-11
HYEM (Vaneck Vectors Emerging Markets High Yield Bond ETF) Start Date:2012-05-09
HYFI (Ab Active ETFs Ab High Yield ETF) Start Date:2023-05-15
HYG (iShares Iboxx $ High Yield Corporate Bd) Start Date:2007-04-11
HYGH (iShares Interest Rate Hedged High Yld Bd) Start Date:2014-05-29
HYGI (iShares Us ETF Trust iShares Inflation Hedged High Yield Bon) Start Date:2022-07-11
HYGV (Flexshares High Yield Value-Scored Bond Index Fund) Start Date:2018-07-18
HYGW (iShares Trust iShares High Yield Corporate Bond Buywrite Strat) Start Date:2022-08-22
HYHG (ProShares High Yield Interest Rate Hdgd) Start Date:2013-05-23
HYLB (Xtrackers Usd High Yield Corporate Bond) Start Date:2016-12-07
HYLD (Peritus High Yield ETF) Start Date:2010-12-01
HYLG (Global X Funds Global X Health Care Covered Call & Growth ETF) Start Date:2022-11-23
HYLS (First Trust Tactical High Yield ETF) Start Date:2013-02-27
HYMB (SPDR Nuveen S&P High Yield Municipal Bond ETF) Start Date:2011-04-14
HYMU (Blackrock High Yield Muni Income Bond ETF) Start Date:2021-03-18
HYRM (DBx ETF Trust Xtrackers Risk Managed Usd High Yield Strategy E) Start Date:2022-02-10
HYS (Pimco 0-5 Year High Yield Corp) Start Date:2011-06-17
HYSA (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Sector Rotat) Start Date:2023-09-18
HYSD (Columbia ETF Trust I Columbia Short Duration High Yield ETF) Start Date:2024-09-05
HYTI (First Trust Exchange-Traded Fund Iv FTVest High Yield & Targe) Start Date:2025-02-18
HYTR (Cp High Yield Trend ETF) Start Date:2020-01-22
HYUP (Xtrackers High Beta High Yield Bond ETF) Start Date:2018-01-11
HYXF (iShares ESG Advanced High Yield Corporate Bond ETF) Start Date:2020-09-15
HYXU (iShares International High Yield Bond) Start Date:2012-04-03
HYZD (WisdomTree Interest Rt Hdg Hi Yld Bd ETF) Start Date:2013-12-18
IAGG (iShares Core International Aggregate Bond Fund) Start Date:2015-11-12
IAI (iShares Us Broker-Dealers ETF) Start Date:2006-05-05
IAK (iShares Us Insurance) Start Date:2006-05-05
IAPR (Innovator International Developed Power Buffer ETF April) Start Date:2021-04-01
IAT (iShares U.S. Regional Banks ETF) Start Date:2006-05-05
IAU (iShares Gold Trust) Start Date:2005-01-28
IAUF (iShares U.S. ETF Trust) Start Date:2018-06-08
IAUG (Innovator ETFs Trust Innovator International Developed Power B) Start Date:2024-08-01
IAUM (iShares Gold Trust Micro iShares Gold Trust Micro Etv Shares R) Start Date:2021-06-29
IBAT (iShares Energy Storage & Materials ETF) Start Date:2024-03-21
IBB (iShares Nasdaq Biotechnology In) Start Date:2001-02-12
IBBQ (Invesco Nasdaq Biotechnology ETF) Start Date:2021-06-11
IBCE (iShares Ibonds Mar 2023 Term Exfncl) Start Date:2013-04-19
IBD (Inspire Corporate Bond Impact ETF) Start Date:2017-07-11
IBDD (iShares Ibonds Mar 2023 Term Corporate) Start Date:2013-07-10
IBDO (iShares Ibonds Dec 2023 Corporate ETF) Start Date:2015-03-12
IBDP (iShares Ibonds Dec 2024 Corporate ETF) Start Date:2015-03-12
IBDQ (iShares Ibonds Dec 2025 Term Corporate) Start Date:2015-03-12
IBDR (iShares Ibonds Dec 2026 Term Corporate ETF) Start Date:2016-09-19
IBDS (iShares Ibonds Dec 2027 Term Corporate ETF) Start Date:2017-09-14
IBDT (iShares Ibonds Dec 2028 Term Corporate ETF) Start Date:2018-09-20
IBDU (iShares Ibonds Dec 2029 Term Corporate ETF) Start Date:2019-09-19
IBDV (iShares Ibonds Dec 2030 Term Corporate ETF) Start Date:2020-06-25
IBDW (iShares Ibonds Dec 2031 Term Corporate ETF) Start Date:2021-06-24
IBDX (iShares Trust iShares Ibonds Dec 2032 Term Corporate ETF) Start Date:2022-06-30
IBDY (iShares Trust iShares Ibonds Dec 2033 Term Corporate ETF) Start Date:2023-06-23
IBDZ (iShares Trust iShares Ibonds Dec 2034 Term Corporate ETF) Start Date:2024-05-24
IBET (Ibet Sports Betting And Gaming ETF) Start Date:2021-11-16
IBGA (iShares Ibonds Dec 2044 Term Treasury ETF) Start Date:2024-06-12
IBGK (iShares Ibonds Dec 2054 Term Treasury ETF) Start Date:2024-06-12
IBHC (iShares Ibonds 2023 Term High Yield And Income ETF) Start Date:2019-05-09
IBHD (iShares Ibonds 2024 Term High Yield And Income ETF) Start Date:2019-05-09
IBHE (iShares Ibonds 2025 Term High Yield And Income ETF) Start Date:2019-05-09
IBHF (iShares Ibonds 2026 Term High Yield And Income ETF) Start Date:2020-11-12
IBHG (iShares Ibonds 2027 Term High Yield And Income ETF) Start Date:2021-07-09
IBHK (iShares Trust iShares Ibonds 2031 Term High Yield And Income E) Start Date:2024-05-28
IBIA (iShares Trust iShares Ibonds Oct 2024 Term Tips ETF) Start Date:2023-09-25
IBIB (iShares Trust iShares Ibonds Oct 2025 Term Tips ETF) Start Date:2023-09-21
IBIC (iShares Trust iShares Ibonds Oct 2026 Term Tips ETF) Start Date:2023-09-28
IBID (iShares Trust iShares Ibonds Oct 2027 Term Tips ETF) Start Date:2023-10-05
IBIE (iShares Trust iShares Ibonds Oct 2028 Term Tips ETF) Start Date:2023-09-20
IBIF (iShares Trust iShares Ibonds Oct 2029 Term Tips ETF) Start Date:2023-09-28
IBIG (iShares Trust iShares Ibonds Oct 2030 Term Tips ETF) Start Date:2023-09-22
IBIH (iShares Trust iShares Ibonds Oct 2031 Term Tips ETF) Start Date:2023-09-22
IBII (iShares Trust iShares Ibonds Oct 2032 Term Tips ETF) Start Date:2023-09-22
IBIJ (iShares Trust iShares Ibonds Oct 2033 Term Tips ETF) Start Date:2023-09-22
IBIK (iShares Trust iShares Ibonds Oct 2034 Term Tips ETF) Start Date:2024-05-24
IBIT (iShares Bitcoin Trust) Start Date:2024-01-11
IBLC (iShares Trust iShares Blockchain And Tech ETF) Start Date:2022-04-27
IBML (iShares Ibonds Dec 2023 Term Muni Bond ETF) Start Date:2017-04-13
IBMM (iShares Ibonds Dec 2024 Term Muni Bond ETF) Start Date:2018-03-22
IBMN (iShares Ibonds Dec 2025 Term Muni Bond ETF) Start Date:2018-11-15
IBMO (iShares Ibonds Dec 2026 Term Muni Bond ETF) Start Date:2019-04-04
IBMP (iShares Ibonds Dec 2027 Term Muni Bond ETF) Start Date:2019-04-11
IBMQ (iShares Ibonds Dec 2028 Term Muni Bond ETF) Start Date:2019-04-18
IBMR (iShares Trust iShares Ibonds Dec 2029 Term Muni Bond ETF) Start Date:2023-05-15
IBMS (iShares Trust iShares Ibonds Dec 2030 Term Muni Bond ETF) Start Date:2024-05-29
IBND (SPDR Bloomberg International Corporate Bond ETF) Start Date:2010-05-20
IBOT (Vaneck Robotics ETF) Start Date:2023-04-06
IBRN (iShares Trust iShares Neuroscience And Healthcare ETF) Start Date:2022-08-26
IBTD (iShares Ibonds Dec 2023 Term Treasury ETF) Start Date:2020-03-03
IBTE (iShares Ibonds Dec 2024 Term Treasury ETF) Start Date:2020-02-28
IBTG (iShares Ibonds Dec 2026 Term Treasury ETF) Start Date:2020-02-28
IBTH (iShares Ibonds Dec 2027 Term Treasury ETF) Start Date:2020-02-28
IBTI (iShares Ibonds Dec 2028 Term Treasury ETF) Start Date:2020-02-28
IBTJ (iShares Ibonds Dec 2029 Term Treasury ETF) Start Date:2020-02-28
IBTK (iShares Ibonds Dec 2030 Term Treasury ETF) Start Date:2020-07-20
IBTM (iShares Ibonds Dec 2032 Term Treasury ETF) Start Date:2022-07-08
IBTO (iShares Ibonds Dec 2033 Term Treasury ETF) Start Date:2023-06-29
IBTP (iShares Ibonds Dec 2034 Term Treasury ETF) Start Date:2024-06-12
IBUF (Shl Telemedicine Innovator International Developed 10 Buff) Start Date:2024-07-01
IBUY (Amplify Online Retail ETF) Start Date:2016-04-20
ICAP (Series Portfolios Trust Infracap Equity Income Fund ETF) Start Date:2021-12-29
ICF (iShares Cohen & Steers Realty M) Start Date:2001-02-02
ICLN (iShares Global Clean Energy ETF) Start Date:2008-06-25
ICLO (Invesco Actively Managed Exchange-Traded Fund Trus Invesco Aaa) Start Date:2022-12-12
ICOP (iShares Copper And Metals Mining ETF) Start Date:2023-06-23
ICOW (Pacer Developed Markets International Cash Cws 100) Start Date:2017-06-19
ICSH (iShares Ultra Short-Term Bond ETF) Start Date:2013-12-13
ICVT (iShares Convertible Bond ETF) Start Date:2015-06-04
IDAT (iShares Cloud 5G And Tech ETF) Start Date:2021-06-10
IDEC (Innovator ETFs Trust Innovator International Developed Power B) Start Date:2023-12-01
IDEV (iShares Core MSCI International Developed Markets ETF) Start Date:2017-03-23
IDGT (iShares Us Digital Infrastructure And Real Estate ETF) Start Date:2007-04-25
IDHD (PowerShares S&P Intl Dev Hi Div Low Vltl) Start Date:2016-12-01
IDHQ (PowerShares S&P Intl Dev Quality ETF) Start Date:2007-06-13
IDLB (PowerShares FTSE Intl Lw Bt Eq Wgt) Start Date:2015-11-05
IDLV (PowerShares S&P Intl Dev Low Volatil ETF) Start Date:2012-01-17
IDME (ETF Series Solutions International Drawdown Managed Equity ETF) Start Date:2021-07-23
IDMO (PowerShares S&P Intl Dev Momentum ETF) Start Date:2012-02-24
IDNA (iShares Genomics Immunology And Healthcare ETF) Start Date:2019-06-13
IDOG (Alps International Sector Div Dogs ETF) Start Date:2013-06-28
IDRV (iShares Self-Driving Ev And Tech ETF) Start Date:2019-04-18
IDU (iShares Dow Jones U.S. Utilitie) Start Date:2004-01-02
IDUB (Aptus International Enhanced Yield ETF) Start Date:2023-05-01
IDV (iShares Dow Jones Epac Select D) Start Date:2007-06-15
IDVO (Amplify ETF Trust Amplify International Enhanced Dividend Inco) Start Date:2022-09-08
IDX (Vaneck Vectors Indonesia ETF) Start Date:2009-01-20
IEDI (iShares Evolved Us Discretionary Spending ETF) Start Date:2018-03-23
IEF (iShares Lehman 7-10 Year Treasu) Start Date:2002-07-30
IEFA (iShares Core MSCI Eafe) Start Date:2012-10-22
IEI (iShares Lehman 3-7 Year Treasur) Start Date:2007-01-11
IEMG (iShares Core MSCI Emerging Markets) Start Date:2012-10-22
IEO (iShares U.S. Oil & Gas Exploration & Production ETF) Start Date:2006-05-05
IETC (iShares Evolved U.S. Technology ETF) Start Date:2018-03-23
IEUR (iShares Core MSCI Europe ETF) Start Date:2014-06-12
IEUS (iShares MSCI Europe Small-Cap ETF) Start Date:2007-11-19
IEV (iShares Europe ETF) Start Date:2005-11-30
IEZ (iShares U.S. Oil Equipment & Services ETF) Start Date:2006-05-05
IFEB (Innovator ETFs Trust Innovator International Developed Power B) Start Date:2024-02-01
IFED (Etracs Ifed Invest With The Fed Tr Index ETN) Start Date:2021-09-15
IFGL (iShares International Developed Real Estate ETF) Start Date:2007-11-19
IFRA (iShares Us Infrastructure ETF) Start Date:2018-04-05
IFV (First Trust Dorsey Wright Intl Foc 5) Start Date:2014-07-23
IG (Principal Investment Grade Corporate Active ETF) Start Date:2018-04-19
IGBH (iShares Interest Rate Hedged Long-Term Corporate Bond ETF) Start Date:2015-09-11
IGE (iShares North American Natural Resources ETF) Start Date:2001-11-26
IGEB (iShares Investment Grade Bond Factor ETF) Start Date:2017-07-13
IGF (iShares Global Infrastructure ETF) Start Date:2007-12-12
IGHG (ProShares Investment Grade Intr Rt Hdgd) Start Date:2013-11-07
IGIB (iShares Lehman Intermediate) Start Date:2007-05-16
IGLB (iShares Long-Term Corporate Bond ETF) Start Date:2009-12-09
IGLD (FTCboe Vest Gold Strategy Target Income ETF) Start Date:2021-03-03
IGM (iShares Expanded Tech Sector ETF) Start Date:2001-03-19
IGN (iShares North American Tech-Multimd Ntwk) Start Date:2001-08-27
IGOV (iShares International Treasury Bond) Start Date:2009-01-29
IGPT (Invesco AI And Next Gen Software ETF) Start Date:2007-05-16
IGRO (iShares International Dividend Growth ETF) Start Date:2016-05-19
IGSB (iShares Short-Term Corporate Bond ETF) Start Date:2007-05-16
IGTR (Innovator ETFs Trust Innovator Gradient Tactical Rotation Stra) Start Date:2022-11-17
IGV (iShares Expanded Tech-Software Sector Et) Start Date:2002-09-03
IHAK (iShares Cybersecurity And Tech ETF) Start Date:2019-06-13
IHDG (WisdomTree International Hedged Dividend Growth Fund) Start Date:2014-05-07
IHE (iShares U.S. Pharmaceuticals ETF) Start Date:2006-05-05
IHF (iShares U.S. Healthcare Providers ETF) Start Date:2006-05-05
IHI (iShares U.S. Medical Devices ETF) Start Date:2006-05-05
IHY (Vaneck Vectors Intl Hi Yld Bd ETF) Start Date:2012-04-03
IIGD (Invesco Investment Grade Defensive ETF) Start Date:2018-09-07
IIGV (Invesco Investment Grade Value ETF) Start Date:2018-09-07
IJAN (Innovator ETFs Trust Innovator MSCI Eafe Power Buffer ETF - Ja) Start Date:2020-01-02
IJH (iShares S&P Midcap 400 Index Fu) Start Date:2004-01-02
IJJ (iShares S&P Midcap 400 Value Index) Start Date:2004-01-02
IJK (iShares S&P Midcap 400 Growth) Start Date:2004-01-02
IJR (iShares S&P Smallcap 600 Index) Start Date:2004-01-02
IJS (iShares S&P Smallcap 600 Value ETF) Start Date:2005-11-30
IJT (iShares S&P Smallcap 600 Growth ETF) Start Date:2005-11-30
IJUL (Innovator MSCI Eafe Power Buffer ETF - July) Start Date:2019-07-01
IJUN (Shl Telemedicine Innovator International Developed Power B) Start Date:2024-06-03
ILCB (iShares Morningstar Large-Cap ETF) Start Date:2021-03-22
ILCG (iShares Morningstar Large-Cap Growth ETF) Start Date:2007-05-16
ILCV (iShares Morningstar Large-Cap Value ETF) Start Date:2007-05-16
ILDR (First Trust Innovation Leaders ETF) Start Date:2021-05-26
ILF (iShares Latin America 40 Index) Start Date:2002-02-05
ILIT (iShares Lithium Miners And Producers ETF) Start Date:2023-06-23
ILOW (Ab Active ETFs Ab International Low Volatility Equity Et) Start Date:2024-07-15
ILTB (iShares Core 10+ Year Usd Bond) Start Date:2009-12-09
IMAR (Innovator ETFs Trust Innovator International Developed Power B) Start Date:2024-03-01
IMAY (Shl Telemedicine Innovator International Developed Power B) Start Date:2024-05-01
IMCB (iShares Morningstar Mid-Cap ETF) Start Date:2007-05-16
IMCG (iShares Morningstar Mid-Cap Growth ETF) Start Date:2021-03-22
IMCV (iShares Morningstar Mid-Cap Value ETF) Start Date:2007-05-16
IMOM (Momentumshares Intl Quant Mom ETF) Start Date:2015-12-23
IMTB (iShares 5-10 Year Usd Bond) Start Date:2016-11-07
IMTM (iShares Edge MSCI Intl Momentum Factor) Start Date:2015-01-26
INAV (Collaborative Investment Series Trust Mohr Industry Nav ETF) Start Date:2024-01-31
INC (Vaneck ETF Trust Vaneck Dynamic High Income ETF) Start Date:2022-11-03
INCE (Franklin Income Equity Focus ETF) Start Date:2024-05-31
INCM (Franklin Templeton ETF Trust Franklin Income Focus ETF) Start Date:2023-06-08
INCO (Columbia India Consumer ETF) Start Date:2011-08-10
INDA (iShares MSCI India) Start Date:2012-02-03
INDE (Matthews International Funds Matthews India Active ETF) Start Date:2023-09-22
INDF (iShares Edge MSCI Multifactor Indtls) Start Date:2020-11-02
INDH (WisdomTree India Hedged Equity Fund) Start Date:2024-05-09
INDL (Direxion Daily MSCI India Bull 3X ETF) Start Date:2010-03-11
INDS (Pacer Benchmark Industrial Real Estate Sctr ETF) Start Date:2018-05-15
INDY (iShares India 50 ETF) Start Date:2009-11-20
INEQ (Columbia International Equity Income ETF) Start Date:2016-06-13
INFL (Horizon Kinetics Inflation Beneficiaries ETF) Start Date:2021-01-12
INFO (Harbor ETF Trust Harbor Panagora Dynamic Large Cap Core ETF) Start Date:2024-10-10
INFR (Legg Mason Global Infrastructure ETF) Start Date:2022-12-16
INKM (SPDR Ssga Income Allocation ETF) Start Date:2012-04-26
INMU (Blackrock Intermediate Muni Income Bond ETF) Start Date:2021-03-18
INNO (Harbor ETF Trust Harbor Disruptive Innovation ETF) Start Date:2021-12-02
INQQ (Exchange Traded Concepts Trust India Internet & Ecommerce ETF) Start Date:2022-04-06
INRO (Blackrock Us Industry Rotation ETF) Start Date:2024-03-28
INTF (iShares Edge MSCI Multifactor Intl) Start Date:2015-05-04
INTW (Graniteshares 2X Long Intc Daily ETF) Start Date:2025-02-13
INVN (The Alger ETF Trust Alger Russell Innovation ETF) Start Date:2011-11-16
IOCT (Innovator International Developed Power Buffer ETF - October) Start Date:2021-10-01
ION (ProShares Trust ProShares S&P Global Core Battery Metals ETF) Start Date:2022-12-01
IOO (iShares Global 100 ETF) Start Date:2000-12-08
IOPP (Simplify Exchange Traded Funds Simplify Tara India Opportuniti) Start Date:2024-03-05
IPAC (iShares Core MSCI Pacific ETF) Start Date:2014-06-12
IPAY (ETFmg Prime Mobile Payments ETF) Start Date:2015-07-16
IPDP (Listed Funds Trust Dividend Performers ETF) Start Date:2022-03-07
IPKW (PowerShares Intl Buyback Achiev ETF) Start Date:2014-03-06
IPOS (Renaissance International Ipo ETF) Start Date:2014-10-07
IPPP (Listed Funds Trust Preferred-Plus ETF) Start Date:2022-03-07
IQDE (Flexshares International Quality Dividend Defensive Index Fund) Start Date:2013-04-16
IQDF (Flexshares International Quality Dividend Index Fund) Start Date:2013-04-16
IQDG (WisdomTree International Quality Dividend Growth Fund) Start Date:2016-04-07
IQDY (Flexshares Intl Qual Div Dynamic ETF) Start Date:2013-04-16
IQHI (IQ Mackay Municipal Insured ETF IQ Mackay ESG High Income ETF) Start Date:2022-10-25
IQIN (IQ 500 International ETF) Start Date:2018-12-13
IQLT (iShares MSCI Intl Quality Factor ETF) Start Date:2015-01-15
IQM (Franklin Templeton ETF Trust) Start Date:2020-02-27
IQQQ (ProShares Nasdaq-100 High Income ETF) Start Date:2024-03-20
IQRA (IQ Mackay Municipal Insured ETF IQ Cbre Real Assets ETF) Start Date:2023-05-10
IQSI (IQ Candriam ESG International Equity ETF) Start Date:2019-12-17
IQSM (IQ Candriam Us Mid Cap Equity ETF) Start Date:2022-10-25
IQSU (IQ Candriam ESG Us Equity ETF) Start Date:2019-12-17
IRBO (iShares Robotics And Artificial Intelligence ETF) Start Date:2018-06-28
IRET (Tidal Trust Ii Ireit - Marketvector Quality Reit Index ETF) Start Date:2024-03-06
IROC (Invesco Rochester High Yield Municipal ETF) Start Date:2025-02-25
IRTR (iShares Trust iShares Lifepath Retirement ETF) Start Date:2023-10-19
IRVH (Global X Funds Global X Interest Rate Volatility & Inflation H) Start Date:2022-07-08
ISCB (iShares Morningstar Small-Cap ETF) Start Date:2021-03-22
ISCF (iShares Edge MSCI Multifactor Intl Sm-Cp) Start Date:2015-05-01
ISCG (iShares Morningstar Small-Cap Growth ETF) Start Date:2007-05-16
ISCV (iShares Morningstar Small-Cap Value ETF) Start Date:2007-05-16
ISDB (Invesco Actively Managed Exchange-Traded Fund Trus Invesco Sho) Start Date:2022-12-13
ISDX (Invesco Rafi Strategic Developed Ex-Us ETF) Start Date:2018-09-14
ISEM (Invesco Rafi Strategic Emerging Markets ETF) Start Date:2018-09-13
ISEP (Innovator ETFs Trust Innovator International Developed Power B) Start Date:2023-09-01
ISHG (iShares 1-3 Year International Trs Bd) Start Date:2009-01-28
ISHP (First Trust S-Network E-Commerce ETF) Start Date:2016-10-11
ISMD (Inspire Small/Mid Cap Impact ETF) Start Date:2017-03-10
ISPY (ProShares Trust ProShares S&P 500 High Income ETF) Start Date:2023-12-20
ISRA (Vaneck Vectors Israel ETF) Start Date:2013-06-26
ISTB (iShares Core 1-5 Year Usd Bond ETF) Start Date:2012-10-22
ISVL (iShares Trust iShares International Developed Small Cap Value) Start Date:2021-03-25
ISWN (Amplify Blackswan Iswn ETF) Start Date:2021-01-26
ISZE (iShares Edge MSCI Intl Size Factor) Start Date:2015-07-07
ITA (iShares U.S. Aerospace & Defense ETF) Start Date:2006-05-05
ITAN (Sparkline Intangible Value ETF) Start Date:2021-06-29
ITB (iShares Dow Jones U.S. Home) Start Date:2006-05-05
ITDA (iShares Trust iShares Lifepath Target Date 2025 ETF) Start Date:2023-10-25
ITDB (iShares Trust iShares Lifepath Target Date 2030 ETF) Start Date:2023-10-20
ITDC (iShares Trust iShares Lifepath Target Date 2035 ETF) Start Date:2023-10-23
ITDD (iShares Trust iShares Lifepath Target Date 2040 ETF) Start Date:2023-10-23
ITDE (iShares Trust iShares Lifepath Target Date 2045 ETF) Start Date:2023-10-23
ITDF (iShares Trust iShares Lifepath Target Date 2050 ETF) Start Date:2023-10-20
ITDG (iShares Trust iShares Lifepath Target Date 2055 ETF) Start Date:2023-10-19
ITDH (iShares Trust iShares Lifepath Target Date 2060 ETF) Start Date:2023-10-25
ITDI (iShares Trust iShares Lifepath Target Date 2065 ETF) Start Date:2023-10-19
ITDJ (iShares Trust iShares Lifepath Target Date 2070 ETF) Start Date:2024-11-25
ITEQ (Bluestar Israel Technology ETF) Start Date:2015-11-03
ITM (Vaneck Vectors Amt-Free Intermediate Municipal Index ETF) Start Date:2007-12-06
ITOT (iShares Core S&P Total U.S. Stock Market ETF) Start Date:2007-05-16
IUS (Invesco Rafi Strategic Us ETF) Start Date:2018-09-12
IUSB (iShares Core Total Usd Bond Market ETF) Start Date:2014-06-12
IUSG (iShares Core S&P U.S. Growth ETF) Start Date:2014-06-12
IUSS (Invesco Rafi Strategic Us Small Company ETF) Start Date:2018-09-13
IUSV (iShares Core S&P U.S. Value ETF) Start Date:2014-06-12
IVAL (Valueshares International Quant Val ETF) Start Date:2014-12-17
IVDG (Invesco Focused Discovery Growth ETF) Start Date:2020-12-22
IVE (iShares S&P 500 Value Index Fun) Start Date:2004-01-02
IVEG (iShares Emergent Food And Agtech Multisector ETF) Start Date:2022-04-27
IVES (ETFmg Drone Economy Strategy ETF) Start Date:2020-04-08
IVLC (Invesco Us Large Cap Core ESG ETF) Start Date:2020-12-22
IVLU (iShares Edge MSCI Intl Value Factor ETF) Start Date:2015-07-15
IVOG (Vanguard S&P Mid-Cap 400 Growth ETF) Start Date:2010-09-09
IVOL (Quadratic Interest Rate Volatility And Inflation Hedge ETF) Start Date:2019-05-14
IVOO (Vanguard S&P Mid-Cap 400 ETF) Start Date:2010-09-09
IVOV (Vanguard S&P Mid-Cap 400 Value ETF) Start Date:2010-09-09
IVRA (Invesco Real Assets ESG ETF) Start Date:2020-12-22
IVRS (iShares Trust iShares Future Metaverse Tech And Communications) Start Date:2023-02-17
IVSG (Invesco Select Growth ETF) Start Date:2020-12-22
IVV (iShares S&P 500 Index) Start Date:2005-01-03
IVVB (Blackrock ETF Trust Ii iShares Large Cap Deep Buffer ETF) Start Date:2023-06-30
IVVM (Blackrock ETF Trust Ii iShares Large Cap Moderate Buffer ETF) Start Date:2023-07-03
IVVW (iShares Trust iShares S&P 500 Buywrite ETF) Start Date:2024-03-15
IVW (iShares S&P 500 Growth Index Fund) Start Date:2005-01-03
IWB (iShares Russell 1000) Start Date:2000-05-19
IWC (iShares Microcap ETF) Start Date:2005-08-16
IWD (iShares Russell 1000 Value) Start Date:2000-05-26
IWDL (Etracs 2X Leveraged Us Value Factor Tr ETN) Start Date:2021-02-09
IWF (iShares Russell 1000 Growth Index) Start Date:2000-05-26
IWFG (IQ Mackay Municipal Insured ETF IQ Winslow Focused Large Cap G) Start Date:2022-06-23
IWFH (iShares Virtual Work And Life Multisector ETF) Start Date:2020-10-01
IWFL (Etracs 2X Leveraged Us Growth Factor Tr ETN) Start Date:2021-02-08
IWIN (Amplify ETF Trust Amplify Inflation Fighter ETF) Start Date:2022-02-02
IWL (iShares Russell Top 200 ETF) Start Date:2009-09-28
IWLG (IQ Mackay Municipal Insured ETF IQ Winslow Large Cap Growth Et) Start Date:2022-06-23
IWM (iShares Russell 2000 Index) Start Date:2000-05-26
IWMI (Neos ETF Trust Neos Russell 2000 High Income ETF) Start Date:2024-06-25
IWML (Etracs 2X Leveraged Us Size Factor Tr ETN) Start Date:2021-02-05
IWMW (iShares Trust iShares Russell 2000 Buywrite ETF) Start Date:2024-03-15
IWMY (Tidal Trust Ii Defiance R2000 Enhanced Options Income ETF) Start Date:2023-10-31
IWN (iShares Russell 2000 Value) Start Date:2000-07-28
IWO (iShares Russell 2000 Growth Index) Start Date:2000-07-28
IWP (iShares Russell Midcap Growth) Start Date:2001-08-03
IWR (iShares Russell Midcap Index Fund) Start Date:2002-02-04
IWS (iShares Russell Midcap Value Index) Start Date:2001-08-03
IWTR (iShares MSCI Water Management Multisector ETF) Start Date:2022-09-22
IWV (iShares Russell 3000) Start Date:2000-05-26
IWX (iShares Russell Top 200 Value ETF) Start Date:2009-09-28
IWY (iShares Russell Top 200 Growth ETF) Start Date:2009-09-28
IXC (iShares Global Energy ETF) Start Date:2001-11-26
IXG (iShares Global Financials ETF) Start Date:2002-10-28
IXJ (iShares Global Healthcare ETF) Start Date:2002-06-24
IXN (iShares Global Tech ETF) Start Date:2002-07-25
IXP (iShares Global Telecom ETF) Start Date:2002-08-14
IXSE (WisdomTree India Ex-State-Owned Enterprises Fund) Start Date:2019-04-04
IXUS (iShares Core MSCI Total International Stock ETF) Start Date:2012-10-22
IYC (iShares Us Consumer Services ETF) Start Date:2005-11-30
IYE (iShares Dow Jones U.S. Energy) Start Date:2004-01-02
IYF (iShares Dow Jones U.S. Financia) Start Date:2004-01-02
IYG (iShares U.S. Financial Services ETF) Start Date:2005-11-30
IYH (iShares U.S. Healthcare ETF) Start Date:2005-11-30
IYJ (iShares Dow Jones U.S. Industrial) Start Date:2004-01-02
IYK (iShares U.S. Consumer Goods ETF) Start Date:2005-11-30
IYLD (iShares Morningstar Multi-Asset Income Index ETF) Start Date:2012-04-05
IYM (iShares U.S. Basic Materials ETF) Start Date:2005-11-30
IYR (iShares Dow Jones Us Real Estate) Start Date:2005-01-03
IYT (iShares Dow Jones Transportation) Start Date:2005-01-03
IYW (iShares Dow Jones U.S. Tech) Start Date:2004-01-02
IYY (iShares Dow Jones U.S. ETF) Start Date:2005-11-30
IYZ (iShares U.S. Telecommunications ETF) Start Date:2005-11-30
IZRL (ARKIsrael Innovative Technology ETF) Start Date:2017-12-05
JAAA (Janus Henderson Aaa Clo ETF) Start Date:2020-10-19
JADE (JP Morgan Exchange-Traded Fund Trust JP Morgan Active Develop) Start Date:2024-05-17
JAJL (Shl Telemedicine Innovator Equity Defined Protection ETF -) Start Date:2024-07-01
JAND (Innovator ETFs Trust Innovator Premium Income 10 Barrier ETF -) Start Date:2024-01-02
JANH (Innovator ETFs Trust Innovator Premium Income 20 Barrier ETF -) Start Date:2024-01-02
JANJ (Innovator ETFs Trust Innovator Premium Income 30 Barrier ETF -) Start Date:2024-01-02
JANP (Pgim Us Large-Cap Buffer 12 ETF - January Pgim Us Large-Cap Bu) Start Date:2024-01-03
JANQ (Innovator ETFs Trust Innovator Premium Income 40 Barrier ETF -) Start Date:2024-01-02
JANT (Allianzim Us Large Cap Buffer10 Jan ETF) Start Date:2021-01-04
JANU (Aim ETF Products Trust Allianzim U.S. Equity Buffer15 Uncapped) Start Date:2025-01-02
JANW (Allianzim Us Large Cap Buffer20 Jan ETF) Start Date:2021-01-04
JANZ (Trueshares Structured Outcome) Start Date:2021-01-04
JBBB (Janus Detroit Street Trust Janus Henderson B-Bbb Clo ETF) Start Date:2022-01-12
JBND (JP Morgan Exchange-Traded Fund Trust JP Morgan Active Bond Et) Start Date:2023-10-12
JCHI (JP Morgan Exchange-Traded Fund Trust JP Morgan Active China E) Start Date:2023-03-16
JCPB (J.P. Morgan Exchange-Traded Fund Trust) Start Date:2019-01-30
JCTR (JP Morgan Carbon Transition U.S. Equity ETF) Start Date:2020-12-10
JDOC (JP Morgan Healthcare Leaders ETF) Start Date:2023-11-02
JDST (Direxion Daily Junior Gold Miners Index Bear 2X) Start Date:2013-10-03
JDVI (John Hancock Exchange-Traded Fund Trust John Hancock Disciplin) Start Date:2023-12-20
JEMA (JP Morgan Activebuilders Emerging Markets Equity ETF) Start Date:2021-03-11
JEMB (Janus Detroit Street Trust Janus Henderson Emerging Markets) Start Date:2024-08-14
JEPI (JP Morgan Equity Premium Income ETF) Start Date:2020-05-21
JEPQ (JP Morgan Nasdaq Equity Premium Income ETF) Start Date:2022-05-04
JETD (Bank Of Montreal Max Airlines -3X Inverse Leveraged ETNs) Start Date:2023-06-21
JETS (Us Global Jets) Start Date:2015-04-30
JETU (Bank Of Montreal Max Airlines 3X Leveraged ETNs) Start Date:2023-06-21
JFLI (J.P. Morgan Exchange-Traded Fund Trust JP Morgan Flexible Income) Start Date:2025-02-14
JFWD (Jacob Funds Jacob Forward ETF) Start Date:2021-07-14
JGLO (JP Morgan Global Select Equity ETF) Start Date:2023-09-14
JGRO (JP Morgan Exchange-Traded Fund Trust JP Morgan Active Growth) Start Date:2022-08-09
JGRW (Trust For Professional Managers Jensen Quality Growth ETF) Start Date:2024-08-13
JHAC (John Hancock Exchange-Traded Fund Trust John Hancock Fundament) Start Date:2023-11-02
JHCB (John Hancock Corporate Bond ETF) Start Date:2021-03-31
JHCP (John Hancock Exchange-Traded Fund Trust John Hancock Core Plus) Start Date:2024-12-18
JHCR (John Hancock Exchange-Traded Fund Trust John Hancock Core Bond) Start Date:2024-12-18
JHDV (John Hancock Exchange-Traded Fund Trust John Hancock Us High) Start Date:2022-09-30
JHEM (John Hancock Multifactor Emerging Markets ETF) Start Date:2018-09-28
JHHY (John Hancock Exchange-Traded Fund Trust John Hancock High Yiel) Start Date:2024-05-02
JHID (John Hancock Exchange-Traded Fund Trust John Hancock Internati) Start Date:2022-12-21
JHMB (John Hancock Mortgage-Backed Securities ETF) Start Date:2021-08-19
JHMD (John Hancock Multifactor Developed International ETF) Start Date:2016-12-16
JHML (Jhancock Multifactor Large Cap ETF) Start Date:2015-09-30
JHMM (John Hancock Multi-Factor Mid Cap ETF) Start Date:2015-09-29
JHPI (John Hancock Exchange-Traded Fund Trust John Hancock Preferred) Start Date:2021-12-15
JHSC (John Hancock Multifactor Small Cap ETF) Start Date:2017-11-09
JIDA (JP Morgan Activebuilders International Equity ETF) Start Date:2021-07-08
JIG (JP Morgan International Growth ETF) Start Date:2020-05-21
JIII (Janus Detroit Street Trust Janus Henderson Income ETF) Start Date:2024-12-11
JIRE (JP Morgan Exchange-Traded Fund Trust JP Morgan International) Start Date:2022-06-13
JIVE (JP Morgan International Value ETF) Start Date:2023-09-14
JJA (iPath Bloomberg Agriculture Subtr ETN) Start Date:2018-01-31
JJC (iPath Dow Jones Ubs Copper Tota) Start Date:2018-01-29
JJE (iPath Bloomberg Energy Subtr ETN) Start Date:2018-01-23
JJG (iPath Bloomberg Grains Subtr ETN) Start Date:2018-01-30
JJM (iPath Dow Jones Ubs Industrial) Start Date:2018-01-29
JJN (iPath Bloomberg Nickel Subtr ETN) Start Date:2018-01-18
JJP (iPath Dj-Ubs Precious Metals Su) Start Date:2018-01-18
JJS (iPath Bloomberg Softs Subtr ETN) Start Date:2018-01-18
JJT (iPath Bloomberg Tin Subtr ETN) Start Date:2018-02-16
JJU (iPath Dj-Ubs Aluminum Subindex) Start Date:2018-01-18
JLQD (Janus Henderson Corporate Bond ETF) Start Date:2021-09-09
JMBS (Janus Henderson Mortgage-Backed Securities ETF) Start Date:2018-09-13
JMEE (JP Morgan Exchange-Traded Fund Trust JP Morgan Market Expansi) Start Date:2022-05-09
JMHI (JP Morgan Exchange-Traded Fund Trust JP Morgan High Yield Mun) Start Date:2023-07-17
JMID (Janus Henderson Mid Cap Growth Alpha ETF) Start Date:2024-09-18
JMOM (JP Morgan U.S. Momentum Factor ETF) Start Date:2017-11-09
JMSI (JP Morgan Exchange-Traded Fund Trust JP Morgan Sustainable Mu) Start Date:2023-07-17
JMST (JP Morgan Ultra-Short Municipal Ome ETF) Start Date:2018-10-18
JMUB (J.P. Morgan Exchange-Traded Fund Trust) Start Date:2018-10-31
JNEU (Shl Telemedicine Allianzim Us Equity Buffer15 Uncapped J) Start Date:2024-06-03
JNK (SPDR Barclays Capital High Yield Bond) Start Date:2007-12-04
JNUG (Direxion Daily Junior Gold Miners Index Bull 2X Shares) Start Date:2013-10-03
JO (iPath Bloomberg Coffee Subtr ETN) Start Date:2018-02-01
JOET (Virtus Terranova U.S. Quality Momentum ETF) Start Date:2020-11-18
JOJO (Atac Credit Rotation ETF) Start Date:2021-07-16
JPAN (Matthews International Funds Matthews Japan Active ETF) Start Date:2023-09-22
JPEF (JP Morgan Equity Focus ETF) Start Date:2023-07-31
JPEM (JP Morgan Diversified Return Emkts Eq ETF) Start Date:2015-01-09
JPIB (J.P. Morgan Exchange-Traded Fund Trust) Start Date:2020-09-14
JPIE (JP Morgan Income ETF) Start Date:2021-11-02
JPIN (JP Morgan Diversified Return International Equity ETF) Start Date:2014-11-07
JPLD (JP Morgan Exchange-Traded Fund Trust JP Morgan Durati) Start Date:2023-07-31
JPMB (JP Morgan Usd Emerging Markets Sovereign Bond ETF) Start Date:2018-01-31
JPME (JP Morgan Divers Ret Us Mid Cp Eq ETF) Start Date:2016-05-18
JPMO (Tidal Trust Ii Yieldmax Jpm Option Income Strategy ETF) Start Date:2023-09-12
JPRE (JP Morgan Exchange-Traded Fund Trust JP Morgan Realty Income) Start Date:2022-05-23
JPSE (JP Morgan Diversified Return U.S. Small Cap Equity ETF) Start Date:2016-11-17
JPST (JP Morgan Ultra-Short Income ETF) Start Date:2017-05-19
JPSV (JP Morgan Exchange-Traded Fund Trust JP Morgan Active Small C) Start Date:2023-03-08
JPUS (JP Morgan Diversified Return Us Eq ETF) Start Date:2015-09-30
JPXN (iShares Jpx-Nikkei 400) Start Date:2007-05-16
JQUA (JP Morgan U.S. Quality Factor ETF) Start Date:2017-11-09
JRE (Janus Henderson U.S. Real Estate ETF) Start Date:2021-06-23
JRNY (Alps Global Travel Beneficiaries ETF) Start Date:2021-09-09
JSCP (JP Morgan Short Duration Core Plus ETF) Start Date:2021-03-02
JSI (Janus Detroit Street Trust Janus Henderson Securitized Income) Start Date:2023-11-09
JSMD (Janus Small/Mid Cap Growth Alpha ETF) Start Date:2016-02-25
JSML (Janus Henderson Small Cap Growth Alpha ETF) Start Date:2016-02-25
JSTC (Adasina Social Justice All Cap Global ETF) Start Date:2020-12-10
JTEK (JP Morgan Us Tech Leaders ETF) Start Date:2023-10-05
JUCY (ETF Series Solutions Aptus Enhanced Yield ETF) Start Date:2022-11-01
JULD (Innovator ETFs Trust Innovator Premium Income 10 Barrier ETF -) Start Date:2023-07-03
JULH (Innovator ETFs Trust Innovator Premium Income 20 Barrier ETF -) Start Date:2023-07-03
JULJ (Innovator ETFs Trust Innovator Premium Income 30 Barrier ETF -) Start Date:2023-07-03
JULP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - July) Start Date:2024-06-11
JULQ (Innovator ETFs Trust Innovator Premium Income 40 Barrier ETF -) Start Date:2023-07-03
JULT (Allianzim Us Large Cap Buffer10 Jul ETF) Start Date:2020-07-01
JULU (Shl Telemedicine Allianzim U.S. Equity Buffer15 Uncapped) Start Date:2024-07-01
JULW (Allianzim Us Large Cap Buffer20 Jul ETF) Start Date:2020-07-01
JULZ (Trueshares Structured Outcome) Start Date:2020-07-01
JUNE (Dhandho Junoon ETF) Start Date:2024-04-17
JUNM (Shl Telemedicine FTVest U.S. Equity Max Buffer ETF - June) Start Date:2024-06-24
JUNP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - June) Start Date:2024-06-03
JUNT (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 Jun E) Start Date:2023-06-01
JUNW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 Jun E) Start Date:2023-06-01
JUNZ (Trueshares Structured Outcome) Start Date:2021-06-01
JUSA (JP Morgan Activebuilders U.S. Large Cap Equity ETF) Start Date:2021-07-08
JUST (Goldman Sachs Just U.S. Large Cap Equity ETF) Start Date:2018-06-13
JVAL (JP Morgan U.S. Value Factor ETF) Start Date:2017-11-09
JXI (iShares Global Utilities) Start Date:2006-09-22
JZRO (Janus Henderson Net Zero Transition Resources ETF) Start Date:2021-09-10
KALL (Kraneshares MSCI All China Index ETF) Start Date:2015-02-13
KAPR (Innovator ETFs Trust) Start Date:2020-04-01
KARS (Kraneshares Electric Vehicles And Future Mobility Index ETF) Start Date:2018-01-19
KAUG (Innovator ETFs Trust Innovator Us Small Cap Power Buffer ETF -) Start Date:2024-08-01
KBA (Kraneshares Bosera MSCI China A Share ETF) Start Date:2014-03-05
KBE (SPDR S&P Bank ETF) Start Date:2005-11-15
KBND (Kraneshares Bloomberg China Bond Inclusion Index ETF) Start Date:2014-12-03
KBUF (Kraneshares Trust Kraneshares 90% Kweb Defined Outcome January) Start Date:2024-02-08
KBUY (Kraneshares Cicc China Consumer Leaders Index ETF) Start Date:2020-12-09
KBWB (Invesco Kbw Bank ETF) Start Date:2011-11-01
KBWD (Invesco Kbw High Dividend Yield Financial ETF) Start Date:2010-12-02
KBWP (Invesco Kbw Property & Casualty Insurance ETF) Start Date:2010-12-02
KBWR (PowerShares Kbw Regional Banking ETF) Start Date:2011-11-01
KBWY (Invesco Kbw Premium Yield Equity Reit ETF) Start Date:2010-12-02
KCAI (Kraneshares Trust Kraneshares China Alpha Index ETF) Start Date:2024-08-28
KCCA (Kraneshares California Carbon Allowance Strategy ETF) Start Date:2021-10-05
KCE (SPDR S&P Capital Markets ETF) Start Date:2005-11-15
KCSH (Kraneshares Trust Kraneshares Sustainable Ultra Short Duration) Start Date:2024-07-26
KDEC (Innovator ETFs Trust Innovator U.S. Small Cap Power Buffer ETF) Start Date:2024-12-02
KDEF (Exchange Listed Funds Trust Plus Korea Defense Industry Index) Start Date:2025-02-05
KDIV (Kraneshares Trust Kraneshares S&P Pan Asia Dividend Aristocrat) Start Date:2022-09-15
KDRN (ETF Opportunities Trust Kingsbarn Tactical Bond ETF) Start Date:2021-12-21
KEAT (Keating Active ETF) Start Date:2024-03-27
KEJI (Global X China Innovation ETF) Start Date:2021-02-24
KEM (Kraneshares Trust Kraneshares Dynamic Emerging Markets Strateg) Start Date:2023-08-25
KEMQ (Kraneshares Emerging Markets Consumer Technology ETF) Start Date:2017-10-12
KEMX (Kraneshares MSCI Emerging Markets Ex China Index ETF) Start Date:2019-04-12
KESG (Kraneshares MSCI China ESG Leaders Index ETF) Start Date:2020-07-29
KEUA (Kraneshares European Carbon Allowance Strategy ETF) Start Date:2021-10-05
KFEB (Innovator ETFs Trust Innovator U.S. Small Cap Power Buffer ETF) Start Date:2025-02-03
KFVG (Kraneshares Trust Kraneshares Cicc China 5G And Semiconductor) Start Date:2020-11-24
KFYP (Kraneshares Zacks New China ETF) Start Date:2013-07-23
KGRN (Kraneshares MSCI China Environment Index ETF) Start Date:2017-10-13
KGRO (Kraneshares China Innovation ETF) Start Date:2021-10-07
KHYB (Kraneshares Asia Pacific High Income Bond ETF) Start Date:2018-06-28
KIE (SPDR S&P Insurance ETF) Start Date:2005-11-15
KJAN (Innovator Us Small Cap Power Buffer ETF - January) Start Date:2020-01-02
KJUL (Innovator U.S. Small Cap Power Buffer ETF - July) Start Date:2020-07-02
KJUN (Shl Telemedicine Innovator Us Small Cap Power Buffer ETF) Start Date:2024-06-03
KLCD (Kfa Large Cap Quality Dividend Index ETF) Start Date:2019-06-12
KLDW (Gavekal Knowledge Leaders Dev Wld ETF) Start Date:2015-07-09
KLIP (Kraneshares Trust Kraneshares China Internet And Covered Call) Start Date:2023-01-12
KLMN (Invesco Exchange-Traded Fund Trust Ii Invesco MSCI North America) Start Date:2024-12-13
KLMT (Invesco Exchange-Traded Fund Trust Ii Invesco MSCI Global Climate) Start Date:2024-06-27
KLNE (Direxion Daily Global Clean Energy Bull 2X Shares) Start Date:2021-07-29
KLXY (Kraneshares Trust Kraneshares Global Luxury Index ETF) Start Date:2023-09-07
KMAR (Innovator ETFs Trust Innovator U.S. Small Cap Power Buffer ETF) Start Date:2025-03-03
KMED (Kraneshares Trust Kraneshares Emerging Markets Healthcare Inde) Start Date:2018-08-30
KMET (Kraneshares Trust Kraneshares Electrification Metals Strategy) Start Date:2022-10-13
KMID (Virtus ETF Trust Ii Virtus Kar Mid-Cap ETF) Start Date:2024-10-16
KMLM (Kfa Mount Lucas Index Strategy ETF) Start Date:2020-12-02
KNCT (Invesco Next Gen Connectivity ETF) Start Date:2007-05-16
KNG (ETF Series Solutions) Start Date:2018-03-27
KNGS (Upholdings Compound Kings ETF) Start Date:2020-12-30
KNGZ (First Trust S&P 500 Diversified Dividend Aristocrats ETF) Start Date:2017-06-22
KNOV (Innovator ETFs Trust Innovator U.S. Small Cap Power Buffer ETF) Start Date:2024-11-01
KNOW (Direxion All Cap Insider Sentiment ETF) Start Date:2011-12-08
KOCG (Fis Knights Of Columbus Global Belief ETF) Start Date:2021-07-14
KOCT (Innovator Us Small Cap Power Buffer ETF - October) Start Date:2019-10-01
KOIN (Innovation Shares Nextgen Protocol ETF) Start Date:2018-01-30
KOKU (Xtrackers MSCI Kokusai Equity ETF) Start Date:2020-04-08
KOLD (ProShares Ultrashort Bloomberg Natural Gas) Start Date:2011-10-06
KOMP (SPDR S&P Kensho New Economies Composite ETF) Start Date:2018-10-23
KONG (ETF Opportunities Trust Formidable Fortress ETF) Start Date:2021-07-22
KOOL (Spinnaker ETF Series North Shore Equity Rotation ETF) Start Date:2024-04-02
KORP (American Century Diversified Corporate Bond ETF) Start Date:2018-01-16
KORU (Direxion Daily South Korea Bull 3X ETF) Start Date:2013-04-11
KPOP (Exchange Traded Concepts Trust Kpop And Korean Entertainment E) Start Date:2022-09-01
KPRO (Kraneshares Trust Kraneshares 100% Kweb Defined Outcome Januar) Start Date:2024-02-08
KQQQ (Kurv Technology Titans Select ETF) Start Date:2024-07-23
KRBN (Kraneshares Global Carbon ETF) Start Date:2020-07-30
KRE (SPDR S&P Regional Banking ETF) Start Date:2006-06-22
KRMA (Global X Conscious Companies ETF) Start Date:2016-07-12
KROP (Global X Agtech & Food Innovation ETF) Start Date:2021-07-14
KRUZ (Series Portfolios Trust Unusual Whales Subversive Republican T) Start Date:2023-02-07
KSA (iShares MSCI Saudi Arabia ETF) Start Date:2015-09-17
KSEA (Kraneshares Trust Kraneshares Rockefeller Ocean Engagement ETF) Start Date:2023-09-12
KSEP (Innovator U.S. Small Cap Power Buffer ETF - September Innovato) Start Date:2024-09-03
KSPY (Kraneshares Trust Kraneshares Hedgeye Hedged Equity Index ETF) Start Date:2024-07-16
KSTR (Kraneshares Sse Star Market 50 Index ETF) Start Date:2021-01-27
KTEC (Kraneshares Hang Seng Tech Index ETF) Start Date:2021-06-09
KURE (Kraneshares MSCI All China Health Care Index ETF) Start Date:2018-02-01
KVLE (Kraneshares Trust Kfa Value Line Dynamic Core Equity Index ETF) Start Date:2020-11-24
KWEB (Kraneshares CSI China Internet ETF) Start Date:2013-08-01
KWT (Vaneck Vectors Solar Energy ETF) Start Date:2020-09-03
KXI (iShares Global Consumer Staples ETF) Start Date:2006-09-22
LABD (Direxion Daily S&P Biotech Bear 3X Shares) Start Date:2015-05-28
LABU (Direxion Daily S&P Biotech Bull 3X Shares) Start Date:2015-05-28
LALT (PowerShares Multi-Strategy Alt ETF) Start Date:2023-02-07
LAPR (Innovator ETFs Trust Innovator Premium Income 15 Buffer ETF -) Start Date:2024-04-01
LAYS (Stkd 100% Nvda & 100% Amd ETF) Start Date:2025-03-06
LBAY (Leatherback Long/Short Alternative Yield ETF) Start Date:2020-11-17
LBO (Ea Series Trust Whitewolf Publicly Listed Private Equity ETF) Start Date:2023-11-30
LCDS (JP Morgan Fundamental Data Science Large Core ETF) Start Date:2024-08-13
LCF (Touchstone ETF Trust Touchstone Us Large Cap Focused ETF) Start Date:2022-07-29
LCG (Sterling Capital Focus Equity ETF) Start Date:2020-08-27
LCLG (Advisors Series Trust Logan Capital Broad Innovative Growth Et) Start Date:2022-08-08
LCR (Leuthold Core ETF) Start Date:2020-01-06
LCTD (Blackrock World Ex U.S. Carbon Transition Readiness ETF) Start Date:2021-04-08
LCTU (Blackrock U.S. Carbon Transition Readiness ETF) Start Date:2021-04-08
LD (iPath Dj-Ubs Lead Subindex Tota) Start Date:2008-06-25
LDEM (iShares ESG MSCI Em Leaders ETF) Start Date:2020-02-12
LDRC (iShares Trust iShares Ibonds 1-5 Year Corporate Ladder ETF) Start Date:2024-11-14
LDRH (iShares Trust iShares Ibonds 1-5 Year High Yield And Income) Start Date:2024-11-26
LDRI (Invesco Ladderrite 0-5 Year Corporate Bond ETF) Start Date:2025-01-02
LDRT (iShares Trust iShares Ibonds 1-5 Year Treasury Ladder ETF) Start Date:2024-11-14
LDSF (First Trust Low Duration Strategic Focus ETF) Start Date:2019-01-07
LDUR (Pimco Enhanced Low Duration Active Exchange-Traded Fund) Start Date:2014-01-23
LEAD (Reality Shares ETF Trust) Start Date:2016-01-06
LEGR (First Trust Indxx Innovative Transaction & Process ETF) Start Date:2018-01-25
LEMB (iShares Emerg Mkts Local Currency Bond) Start Date:2011-10-20
LEXI (Alexis Practical Tactical ETF) Start Date:2021-07-01
LFEQ (Vaneck Vectors Long/Flat Trend ETF) Start Date:2017-10-05
LFGY (Tidal Trust Ii Yieldmax Crypto Industry & Tech Portfolio Options) Start Date:2025-01-15
LFSC (F/M Emerald Life Sciences Innovation ETF) Start Date:2024-10-31
LGCF (Themes Us Cash Flow Champions ETF) Start Date:2023-12-13
LGDX (Tidal Trust Iii Intech S&P Large Cap Diversified Alpha ETF) Start Date:2025-02-28
LGH (Hcm Defender 500 Index ETF) Start Date:2019-10-10
LGHT (Spinnaker ETF Series Langar Global Healthtech ETF) Start Date:2024-01-10
LGLV (SPDR Ssga Us Large Cap Low Volatility Index ETF) Start Date:2013-02-21
LGOV (First Trust Long Duration Opportunities ETF) Start Date:2019-01-23
LGRO (Level Four Large Cap Growth Active ETF) Start Date:2023-08-23
LIMI (Themes ETF Trust Themes Lithium & Battery Metal Miners ETF) Start Date:2024-09-24
LIT (Global X Lithium ETF) Start Date:2010-07-23
LITP (Sprott Lithium Miners ETF) Start Date:2023-02-02
LIVR (Intelligent Livermore ETF) Start Date:2024-09-18
LJAN (Innovator ETFs Trust Innovator Premium Income 15 Buffer ETF -) Start Date:2024-01-02
LJUL (Shl Telemedicine Innovator Premium Income 15 Buffer ETF) Start Date:2024-07-01
LKOR (Flexshares Credit-Scored Us Long Corporate Bond Index Fund) Start Date:2015-09-24
LLDR (Global X Funds Global X Long-Term Treasury Ladder ETF) Start Date:2024-09-25
LLYX (Tidal Trust Ii Defiance Daily Target 2X Long Lly ETF) Start Date:2024-08-08
LMBO (Direxion Shares ETF Trust Direxion Daily Crypto Industry Bull) Start Date:2024-07-17
LMBS (First Trust Low Duration Mortgage Opportunities ETF) Start Date:2014-11-05
LNGG (Listed Funds Trust Roundhill Alerian Lng ETF) Start Date:2023-09-22
LNGZ (Exchange Traded Concepts Trust Range Global Lng Ecosystem Inde) Start Date:2024-01-24
LOCT (Innovator ETFs Trust Innovator Premium Income 15 Buffer ETF -) Start Date:2023-10-02
LODI (ETF Series Solutions Aam Slc Low Duration Income ETF) Start Date:2024-12-04
LOGO () Start Date:2017-10-18
LONZ (Pimco Us Treasury Index Fund Pimco Senior Loan Active Exchan) Start Date:2022-06-09
LOPP (Gabelli Love Our Planet & People ETF Gabelli Love Our Planet &) Start Date:2021-02-01
LOUP (Innovator Loup Frontier Tech ETF) Start Date:2018-07-25
LOWV (Ab Active ETFs Ab Us Low Volatility Equity ETF) Start Date:2023-03-22
LQAI (Exchange Listed Funds Trust Lg Qraft Ai-Powered Us Large Cap) Start Date:2023-11-07
LQD (iShares Iboxx $ Invest Grade Bond) Start Date:2002-07-30
LQDB (iShares Trust iShares Bbb Rated Corporate Bond ETF) Start Date:2021-05-20
LQDH (iShares Interest Rate Hedged Corporate Bond ETF) Start Date:2014-06-17
LQDI (iShares U.S. ETF Trust) Start Date:2018-05-10
LQIG (SPDR Marketaxess Investment Grade 400 Corporate Bond ETF) Start Date:2022-05-12
LQTI (First Trust Exchange-Traded Fund Iv FTVest Investment Grade &) Start Date:2025-02-13
LRGC (Ab Active ETFs Ab Us Large Cap Strategic Equities ETF) Start Date:2023-09-20
LRGE (Clearbridge Large Cap Growth ESG ETF) Start Date:2017-05-25
LRGF (iShares MSCI Usa Multifactor ETF) Start Date:2015-04-30
LRGG (Macquarie ETF Trust Macquarie Focused Large Growth ETF) Start Date:2024-05-15
LRND (IQ Us Large Cap R&D Leaders ETF) Start Date:2022-02-08
LRNZ (Truemark AI & Deep Learning ETF) Start Date:2020-03-02
LSAF (Leadershares Alphafactor Us Core Equity ETF) Start Date:2018-10-02
LSAT (Leadershares Alphafactor Tactical Focused ETF) Start Date:2020-11-02
LSEQ (Harbor ETF Trust Harbor Long-Short Equity ETF) Start Date:2023-12-07
LSGR (Natixis ETF Trust Ii Natixis Loomis Sayles Focused Growth ETF) Start Date:2023-06-29
LSST (Natixis ETF Trust Natixis Loomis Sayles Short Duration Income) Start Date:2017-12-28
LST (Managed Portfolio Series Leuthold Select Industries ETF) Start Date:2025-01-21
LSVD (The Advisors Inner Circle Fund Lsv Disciplined Value ETF) Start Date:2024-12-18
LTL (Ultra Telecommunications ProShares) Start Date:2008-04-09
LTPZ (Pimco 15+ Year U.S. Tips Index Exchange-Traded Fund) Start Date:2009-09-08
LTTI (First Trust Exchange-Traded Fund Iv FTVest 20+ Year Treasury) Start Date:2025-02-13
LUX (Tema ETF Trust Tema Luxury ETF) Start Date:2023-05-11
LUXX (Listed Funds Trust Roundhill S&P Global Luxury ETF) Start Date:2023-08-23
LVHD (Legg Mason Low Volatility High Div ETF) Start Date:2015-12-29
LVHI (Legg Mason Intl Low Volatil Hi Div ETF) Start Date:2016-07-28
LVOL (American Century Low Volatility ETF) Start Date:2021-01-14
LYFE (2Ndvote Life Neutral Plus ETF) Start Date:2020-11-18
LYLD (Cambria ETF Trust Cambria Large Cap Shareholder Yield ETF) Start Date:2024-07-12
MAAX (Vaneck Vectors ETF Trust) Start Date:2019-05-16
MADE (iShares Trust iShares U.S. Manufacturing ETF) Start Date:2024-07-18
MAGA (ETF Series Solutions) Start Date:2017-09-07
MAGG (Madison ETFs Trust Madison Aggregate Bond ETF) Start Date:2023-08-29
MAGQ (Roundhill Daily Inverse Magnificent Seven ETF) Start Date:2024-02-29
MAGS (Roundhill Magnificent Seven ETF) Start Date:2023-04-11
MAGX (Roundhill Daily 2X Long Magnificent Seven ETF) Start Date:2024-02-29
MAMB (Monarch Ambassador Income ETF) Start Date:2021-03-24
MARB (First Trust Merger Arbitrage ETF) Start Date:2020-02-05
MARM (Shl Telemedicine FTVest Us Equity Max Buffer ETF - Marc) Start Date:2024-03-27
MARO (Tidal Trust Ii Yieldmax Mara Option Income Strategy ETF) Start Date:2024-12-10
MART (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 Mar E) Start Date:2023-03-01
MARW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 Mar E) Start Date:2023-03-01
MARZ (Trueshares Structured Outcome) Start Date:2021-03-01
MAVF (Ea Series Trust Matrix Advisors Value ETF) Start Date:2025-02-24
MAXI (Simplify Bitcoin Strategy Plus Income ETF) Start Date:2022-09-30
MAYP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - May) Start Date:2024-05-01
MAYT (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 May E) Start Date:2023-05-01
MAYU (Shl Telemedicine Allianzim Us Equity Buffer15 Uncapped M) Start Date:2024-05-01
MAYW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 May E) Start Date:2023-05-01
MBB (iShares Barclays Mbs Bond Fund) Start Date:2007-03-16
MBBB (Vaneck Moody's Analytics Bbb Corporate Bond ETF) Start Date:2020-12-02
MBCC (Monarch Blue Chips Core ETF) Start Date:2021-03-24
MBND (SPDR Nuveen Municipal Bond ETF) Start Date:2021-02-04
MBNE (SPDR Nuveen Municipal Bond ESG ETF) Start Date:2022-04-05
MBOX (Freedom Day Dividend ETF) Start Date:2021-05-05
MBS (Angel Oak Funds Trust Angel Oak Mortgage-Backed Securities ETF) Start Date:2024-02-20
MBSD (Flexshares Disciplined Duration Mbs ETF) Start Date:2014-09-04
MBSF (Valued Advisers Trust Regan Floating Rate Mbs ETF) Start Date:2024-02-28
MCDS (JP Morgan Fundamental Data Science Mid Core ETF) Start Date:2024-08-13
MCH (Matthews China Active ETF) Start Date:2022-07-14
MCHI (iShares MSCI China) Start Date:2011-03-31
MCHS (Matthews China Discovery Active ETF) Start Date:2024-01-11
MCSE (Martin Currie Sustainable International Equity ETF) Start Date:2022-10-31
MDCP (Victoryshares Thb Mid Cap ESG ETF) Start Date:2021-10-06
MDEV (First Trust Indxx Medical Devices ETF) Start Date:2021-06-23
MDIV (First Trust Multi-Asset Diversified Income Index Fund) Start Date:2012-08-14
MDPL (Northern Lights Fund Trust Iv Monarch Dividend Plus Index ETF) Start Date:2024-03-07
MDST (Ultimus Managers Trust Westwood Salient Enhanced Midstream Inc) Start Date:2024-04-09
MDY (SPDR S&P Midcap 400) Start Date:2000-01-03
MDYG (SPDR S&P 400 Mid Cap Growth ETF) Start Date:2007-05-16
MDYV (SPDR S&P 400 Mid Cap Value ETF) Start Date:2007-05-16
MEAR (Blackrock Short Maturity Municipal Bond ETF) Start Date:2015-03-05
MEDI (Harbor ETF Trust Harbor Health Care ETF) Start Date:2022-11-17
MEDX (Horizon Kinetics Medical ETF) Start Date:2023-01-31
MEM (Matthews Emerging Markets Equity Active ETF) Start Date:2022-07-14
MEMS (Matthews Emerging Markets Discovery Active ETF) Start Date:2024-01-11
MEMX (Matthews International Funds Matthews Emerging Markets Ex Chin) Start Date:2023-01-11
METD (Direxion Daily Meta Bear 1X Shares) Start Date:2024-06-05
METU (Direxion Daily Meta Bull 2X Shares) Start Date:2024-06-05
METV (Roundhill Ball Metaverse ETF) Start Date:2021-06-30
MEXX (Direxion Daily MSCI Mexico Bull 3X Shares) Start Date:2017-05-03
MFDX (Pimco Equitiy Series Pimco Rafi Dynamic Multi-Factor Internati) Start Date:2017-09-06
MFEM (Pimco Rafi Dynamic Multi-Factor Emerging Market Equity ETF) Start Date:2017-09-06
MFLX (First Trust Flexible Municipal High Income ETF) Start Date:2016-09-29
MFUL (Mindful Conservative ETF) Start Date:2021-11-03
MFUS (Pimco Equitiy Series Pimco Rafi Dynamic Multi-Factor U.S. Equi) Start Date:2017-09-06
MFUT (Tidal Trust Ii Cambria Chesapeake Pure Trend ETF) Start Date:2024-05-29
MGC (Vanguard Mega Cap ETF) Start Date:2007-12-26
MGK (Vanguard Mega Cap Growth ETF) Start Date:2007-12-21
MGMT (Ballast Small/Mid Cap ETF) Start Date:2020-12-03
MGNR (American Beacon Select Funds American Beacon Glg Natural Resou) Start Date:2024-02-06
MGOV (First Trust Exchange-Traded Fund Iv First Trust Intermediate G) Start Date:2023-08-04
MGRO (Vaneck ETF Trust Vaneck Morningstar Wide Moat Growth ETF) Start Date:2024-04-01
MGV (Vanguard Mega Cap Value ETF) Start Date:2007-12-21
MID (American Century Mid Cap Growth Impact ETF) Start Date:2020-07-15
MIDE (Xtrackers S&P Midcap 400 ESG ETF) Start Date:2021-02-24
MIDU (Direxion Daily Mid Cap Bull 3X ETF) Start Date:2009-01-08
MIG (Vaneck Moody's Analytics Ig Corporate Bond ETF) Start Date:2020-12-02
MILN (Global X Millennials Thematic ETF) Start Date:2016-05-06
MINC (AdvisorShares Newfleet Multi-Sector Income ETF) Start Date:2013-03-20
MINT (Pimco Enh Shrt Maturity) Start Date:2009-11-17
MINV (Matthews International Funds Matthews Asia Innovators Active E) Start Date:2022-07-14
MISL (First Trust Exchange-Traded Fund First Trust Indxx Aerospace &) Start Date:2022-10-28
MJ (ETFmg Alternative Harvest ETF) Start Date:2015-12-03
MJUS (ETFmg U.S. Alternative Harvest ETF) Start Date:2021-05-13
MKAM (Mkam ETF) Start Date:2023-04-12
MKOR (Matthews International Funds Matthews Korea Active ETF) Start Date:2023-07-17
MLDR (Global X Funds Global X Intermediate-Term Treasury Ladder ETF) Start Date:2025-06-02
MLN (Vaneck Vectors Amt-Free Long Muni ETF) Start Date:2008-01-08
MLPA (Global X Mlp ETF) Start Date:2012-04-19
MLPB (Ubs Etracs Alerian Mlpinfrs ETN Serb) Start Date:2015-10-09
MLPD (Global X Funds Global X Mlp & Energy Infrastructure Covered Ca) Start Date:2024-05-17
MLPO (Credit Suisse Ag) Start Date:2014-12-04
MLPR (Etracs Quarterly Pay 1.5X Leveraged Alerian Mlp Index ETN) Start Date:2020-06-03
MLPX (Global X Mlp & Energy Infrastructure ETF) Start Date:2013-08-07
MMCA (IQ Mackay California Municipal Intermediate ETF) Start Date:2021-12-21
MMIN (IQ Mackay Municipal Insured ETF) Start Date:2017-10-18
MMIT (IQ Mackay Municipal Intermediate ETF) Start Date:2017-10-18
MMLG (First Trust Multi-Manager Large Growth ETF) Start Date:2020-07-22
MMTM (SPDR S&P 1500 Momentum Tilt ETF) Start Date:2012-10-25
MNA (IQ Merger Arbitrage ETF) Start Date:2009-11-17
MNBD (Alps ETF Trust Alps Intermediate Municipal Bond ETF) Start Date:2022-05-20
MNRS (Grayscale Funds Trust Grayscale Bitcoin Miners ETF) Start Date:2025-01-30
MNTL (Tema Neuroscience And Mental Health ETF) Start Date:2024-01-23
MOAT (Vaneck Vectors Morningstar Wide Moat ETF) Start Date:2012-04-25
MODL (Victoryshares Westend Us Sector ETF) Start Date:2022-10-12
MOHR (Mohr Growth ETF) Start Date:2021-11-03
MOO (Market Vectors Agribusiness ETF) Start Date:2007-09-05
MOOD (Alpha Architect ETF Trust Relative Sentiment Tactical Allocati) Start Date:2022-05-19
MOON (Direxion Moonshot Innovators ETF) Start Date:2020-11-12
MORT (Vaneck Vectors Mortgage Reit Income ETF) Start Date:2011-08-17
MOTG (Vaneck Morningstar Global Wide Moat ETF) Start Date:2021-12-10
MOTI (Vaneck Vectors Morningstar Intl Moat ETF) Start Date:2015-07-14
MOTO (Smartetfs Smart Transportation & Technology ETF) Start Date:2019-11-15
MPAY (Exchange Listed Funds Trust Akros Monthly Payout ETF) Start Date:2022-05-06
MPRO (Northern Lights Fund Trust Iv Monarch Procap ETF) Start Date:2021-03-24
MQQQ (Tradr 2X Long Triple Q Monthly ETF) Start Date:2024-09-03
MRAD (Smartetfs Advertising & Marketing Technology ETF) Start Date:2020-12-31
MRAL (Graniteshares 2X Long Mara Daily ETF) Start Date:2025-03-07
MRCP (Pgim Us Large-Cap Buffer 12 ETF - January Pgim Us Large-Cap Bu) Start Date:2024-03-01
MRGR (ProShares Merger ETF) Start Date:2012-12-13
MRNY (Tidal Trust Ii Yieldmax Mrna Option Income Strategy ETF) Start Date:2023-10-24
MRSK (Toews Agility Shares Managed Risk ETF) Start Date:2020-06-25
MSFD (Direxion Daily Msft Bear 1X Shares) Start Date:2022-09-07
MSFL (Graniteshares 2X Long Msft Daily ETF) Start Date:2024-03-18
MSFO (Tidal ETF Trust Ii Yieldmax Msft Option Income Strategy ETF) Start Date:2023-08-25
MSFU (Direxion Daily Msft Bull 1.5X Shares) Start Date:2022-09-07
MSFX (ETF Opportunities Trust T-Rex 2X Long Microsoft Daily Target E) Start Date:2024-01-11
MSFY (Neos ETF Trust Kurv Yield Premium Strategy Microsoft) Start Date:2023-10-31
MSLC (Morgan Stanley Pathway Funds Morgan Stanley Pathway Large Cap) Start Date:2024-12-10
MSMR (ETF Series Solutions Mcelhenny Sheffield Managed Risk ETF) Start Date:2021-11-17
MSOS (AdvisorShares Pure Us Cannabis ETF) Start Date:2020-09-02
MSOX (AdvisorShares Trust AdvisorShares Msos 2X Daily ETF) Start Date:2022-08-24
MSSM (Morgan Stanley Pathway Funds Morgan Stanley Pathway Small-Mid) Start Date:2024-12-09
MSSS (Northern Lights Fund Trust Iv Monarch Select Subsector Index E) Start Date:2024-03-07
MSTB (Lha Market State Tactical Beta ETF) Start Date:2020-09-30
MSTI (Madison ETFs Trust Madison Short Term Strategic Income ETF) Start Date:2023-09-06
MSTQ (ETF Series Solutions Lha Market State Tactical Q ETF) Start Date:2022-03-15
MSTU (ETF Opportunities Trust T-Rex 2X Long Mstr Daily Target ETF) Start Date:2024-09-18
MSTX (Defiance Daily Target 1.75X Long Mstr ETF) Start Date:2007-05-01
MSTY (Tidal Trust Ii Yieldmax Mstr Option Income Strategy ETF) Start Date:2024-02-22
MSTZ (ETF Opportunities Trust T-Rex 2X Inverse Mstr Daily Target ETF) Start Date:2024-09-18
MSVX (Lha Market State Alpha Seeker ETF) Start Date:2020-05-14
MTBA (Simplify Exchange Traded Funds Simplify Mbs ETF) Start Date:2023-11-07
MTGP (WisdomTree Mortgage Plus Bond Fund) Start Date:2019-11-14
MTUL (Etracs 2X Leveraged MSCI Us Momentum Factor Tr ETN) Start Date:2021-02-05
MTUM (iShares Edge MSCI Usa Momentum Factor ETF) Start Date:2013-04-18
MTVR (Fount Metaverse ETF) Start Date:2021-10-28
MUB (iShares S&P National Municipal) Start Date:2007-09-10
MUD (Direxion Daily Mu Bear 1X Shares) Start Date:2024-10-18
MULL (Graniteshares 2X Long Mu Daily ETF) Start Date:2024-11-12
MUNI (Pimco Intermediate Municipal Bond Active Exchange-Traded Fund) Start Date:2009-12-02
MUSI (American Century Multisector Income ETF) Start Date:2021-07-01
MUSQ (Exchange Traded Concepts Trust Musq Global Music Industry ETF) Start Date:2023-07-07
MUST (Columbia Multi-Sector Municipal Income ETF) Start Date:2018-10-10
MUU (Direxion Daily Mu Bull 2X Shares) Start Date:2024-10-10
MVAL (Vaneck ETF Trust Vaneck Morningstar Wide Moat Value ETF) Start Date:2024-03-28
MVFD (Northern Lights Fund Trust Iv Monarch Volume Factor Dividend T) Start Date:2024-03-07
MVFG (Northern Lights Fund Trust Iv Monarch Volume Factor Global Unc) Start Date:2024-03-07
MVLL (Graniteshares 2X Long Mrvl Daily ETF) Start Date:2025-03-07
MVPA (Advisor Managed Portfolios Miller Value Partners Appreciation) Start Date:2024-01-31
MVPL (Advisor Managed Portfolios Miller Value Partners Leverage ETF) Start Date:2024-02-28
MVPS (Amplify ETF Trust Amplify Thematic All-Stars ETF) Start Date:2021-07-21
MVRL (Etracs Monthly Pay 1.5X Leveraged Mortgage Reit ETN) Start Date:2020-06-03
MVV (ProShares Ultra Midcap400) Start Date:2006-06-21
MXI (iShares Global Materials ETF) Start Date:2006-09-22
MYCF (SPDR Ssga My2026 Corporate Bond ETF) Start Date:2024-09-24
MYCG (SPDR Ssga My2027 Corporate Bond ETF) Start Date:2024-09-24
MYCH (SPDR Ssga My2028 Corporate Bond ETF) Start Date:2024-09-24
MYCI (SPDR Ssga My2029 Corporate Bond ETF) Start Date:2024-09-24
MYCJ (SPDR Ssga My2030 Corporate Bond ETF) Start Date:2024-09-24
MYCK (SPDR Ssga My2031 Corporate Bond ETF) Start Date:2024-09-24
MYCL (SPDR Ssga My2032 Corporate Bond ETF) Start Date:2024-09-24
MYCM (SPDR Ssga My2033 Corporate Bond ETF) Start Date:2024-09-24
MYCN (SPDR Ssga My2034 Corporate Bond ETF) Start Date:2024-09-24
MYLD (Cambria ETF Trust Cambria Micro And Smallcap Shareholder Yield) Start Date:2024-01-04
MYMF (SPDR Ssga My2026 Municipal Bond ETF) Start Date:2024-09-24
MYMG (SPDR Ssga My2027 Municipal Bond ETF) Start Date:2024-09-24
MYMH (SPDR Ssga My2028 Municipal Bond ETF) Start Date:2024-09-24
MYMI (SPDR Ssga My2029 Municipal Bond ETF) Start Date:2024-09-24
MYMJ (SPDR Ssga My2030 Municipal Bond ETF) Start Date:2024-09-24
MYY (ProShares Short Midcap400) Start Date:2006-06-21
MZZ (ProShares Ultrashort Midcap400) Start Date:2006-07-13
NACP (Impact Shares Trust I Impact Shares Naacp Minority Empowerment) Start Date:2018-07-19
NAIL (Direxion Daily Homebuilders & Supplies Bull 3X Shares) Start Date:2015-08-19
NANC (Series Portfolios Trust Unusual Whales Subversive Democratic T) Start Date:2023-02-07
NANR (SPDR S&P North American Natural Resources ETF) Start Date:2015-12-16
NAPR (Innovator Growth-100 Power Buffer ETF - April) Start Date:2020-04-01
NATO (Themes Transatlantic Defense ETF) Start Date:2024-10-11
NAUG (Innovator ETFs Trust Innovator Growth-100 Power Buffer ETF - A) Start Date:2024-08-01
NBCC (Neuberger Berman ETF Trust Neuberger Berman Next Generation Co) Start Date:2022-04-07
NBCE (Neuberger Berman ETF Trust Neuberger Berman China Equity ETF) Start Date:2023-10-26
NBCM (Neuberger Berman ETF Trust Neuberger Berman Commodity Strategy) Start Date:2022-10-24
NBCR (Neuberger Berman ETF Trust Neuberger Berman Core Equity ETF) Start Date:2024-08-01
NBCT (Neuberger Berman ETF Trust Neuberger Berman Carbon Transition) Start Date:2022-04-07
NBDS (Neuberger Berman ETF Trust Neuberger Berman Disrupters ETF) Start Date:2022-04-07
NBET (Neuberger Berman Energy Transition & Infrastructure ETF) Start Date:2022-08-19
NBFC (Neuberger Berman ETF Trust Neuberger Berman Flexible Credit In) Start Date:2024-06-25
NBGR (Neuberger Berman ETF Trust Neuberger Berman Global Real Estate) Start Date:2023-10-25
NBGX (Neuberger Berman ETF Trust Neuberger Berman Growth ETF) Start Date:2024-12-19
NBJP (Neuberger Berman ETF Trust Neuberger Berman Japan Equity ETF) Start Date:2024-09-12
NBOS (Neuberger Berman ETF Trust Neuberger Berman Option Strategy Et) Start Date:2024-01-29
NBSD (Neuberger Berman ETF Trust Neuberger Berman Short Duration Inc) Start Date:2024-06-24
NBSM (Neuberger Berman ETF Trust Neuberger Berman Small-Mid Cap ETF) Start Date:2024-03-21
NBTR (Neuberger Berman ETF Trust Neuberger Berman Total Return Bond) Start Date:2024-12-18
NCIQ (Hashdex Nasdaq Crypto Index Us ETF) Start Date:2025-02-14
NCLO (Nushares ETF Trust Nuveen Aa-Bbb Clo ETF) Start Date:2025-01-02
NCPB (Nuveen Core Plus Bond ETF) Start Date:2024-03-06
NDAA (Ned Davis Research 360 Dynamic Allocation ETF) Start Date:2024-10-17
NDEC (Innovator ETFs Trust Innovator Growth-100 Power Buffer ETF - D) Start Date:2024-12-02
NDIA (Global X Funds Global X India Active ETF) Start Date:2023-08-18
NDIV (Amplify ETF Trust Amplify Natural Resources Dividend Income Et) Start Date:2022-08-24
NDOW (Collaborative Investment Series Trust Anydrus Advantage ETF) Start Date:2024-05-14
NDVG (Nuveen Dividend Growth ETF) Start Date:2021-08-05
NEAR (iShares Short Maturity Bond ETF) Start Date:2013-09-26
NERD (Roundhill Bitkraft Esports & Digital Entertainment ETF) Start Date:2019-06-04
NETL (Netlease Corporate Real Estate ETF) Start Date:2019-03-22
NETZ (Engine No. 1 ETF Trust Engine No. 1 Transform Climate ETF) Start Date:2022-02-03
NEWZ (Stocksnips Ai-Powered Sentiment Us All Cap ETF) Start Date:2024-04-12
NFEB (Innovator ETFs Trust Innovator Growth-100 Power Buffer ETF - F) Start Date:2025-02-03
NFLP (Neos ETF Trust Kurv Yield Premium Strategy Netflix) Start Date:2023-10-27
NFLT (Virtus Newfleet Multi-Sect Uncons Bd ETF) Start Date:2015-08-11
NFLU (ETF Opportunities Trust T-Rex 2X Long Nflx Daily Target ETF) Start Date:2024-09-27
NFLY (Tidal ETF Trust Ii Yieldmax Nflx Option Income Strategy ETF) Start Date:2023-08-08
NFRA (Flexshares STOXX Global Broad Infras ETF) Start Date:2013-10-09
NFTY (First Trust India Nifty 50 Equal Weight ETF) Start Date:2012-02-28
NFXL (Direxion Daily Nflx Bull 2X Shares) Start Date:2024-10-03
NFXS (Direxion Daily Nflx Bear 1X Shares) Start Date:2024-10-03
NGE (Global X MSCI Nigeria ETF) Start Date:2013-04-03
NHYM (Nushares ETF Trust Nuveen High Yield Municipal Income ETF) Start Date:2025-01-23
NIB (iPath Bloomberg Cocoa Subtr ETN) Start Date:2008-06-26
NIKL (Sprott Nickel Miners ETF) Start Date:2023-03-22
NIXT (Research Affiliates Deletions ETF) Start Date:2024-09-10
NJAN (Innovator ETFs Trust) Start Date:2020-01-02
NJNK (Columbia ETF Trust I Columbia U.S. High Yield ETF) Start Date:2024-09-05
NJUL (Innovator Growth-100 Power Buffer ETF - July) Start Date:2020-07-01
NJUN (Shl Telemedicine Innovator Growth-100 Power Buffer ETF - J) Start Date:2024-06-03
NLR (Vaneck Vectors Uranium+Nuclear Engy ETF) Start Date:2007-08-15
NMAR (Innovator ETFs Trust Innovator Growth-100 Power Buffer ETF - M) Start Date:2011-09-07
NMB (Simplify Exchange Traded Funds Simplify National Muni Bond ETF) Start Date:2024-09-11
NNOV (Innovator ETFs Trust Innovator Growth-100 Power Buffer ETF - N) Start Date:2024-11-01
NOBL (ProShares S&P 500 Aristocrats) Start Date:2013-10-10
NOCT (Innovator ETFs Trust) Start Date:2019-10-01
NORW (Global X MSCI Norway ETF) Start Date:2010-11-10
NOVP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - Novembe) Start Date:2024-06-11
NPFI (Nuveen Preferred And Income ETF) Start Date:2024-03-06
NRES (Xtrackers Rreef Global Natural Resources ETF) Start Date:2024-02-27
NRGD (Bank Of Montreal) Start Date:2019-04-10
NRGU (Microsectors Us Big Oil Index 3X Leveraged) Start Date:2019-04-24
NRSH (Tidal ETF Trust Aztlan North America Nearshoring Stock Selecti) Start Date:2023-11-30
NSCR (Nuveen Sustainable Core ETF) Start Date:2024-03-06
NSCS (Nuveen Small Cap Select ETF) Start Date:2021-08-05
NSEP (Innovator U.S. Small Cap Power Buffer ETF - September Innovato) Start Date:2024-09-03
NSI (National Security Emerging Markets Index ETF) Start Date:2023-12-07
NTSE (WisdomTree Trust WisdomTree Emerging Markets Efficient Core Fu) Start Date:2021-05-20
NTSI (WisdomTree Trust WisdomTree International Efficient Core Fund) Start Date:2021-05-20
NTSX (WisdomTree 90/60 U.S. Balanced Fund) Start Date:2018-08-02
NTZG (Nuveen Global Net Zero Transition ETF) Start Date:2022-06-24
NUAG (Nushares Enhanced Yield Us Aggt Bd ETF) Start Date:2016-09-15
NUBD (Nuveen ESG U.S. Aggregate Bond ETF) Start Date:2017-10-02
NUDM (Nuveen ESG International Developed Markets Eqty) Start Date:2017-06-07
NUEM (Nuveen ESG Emerging Markets Equity ETF) Start Date:2017-06-07
NUGO (Nuveen Growth Opportunities ETF) Start Date:2021-09-28
NUGT (Direxion Daily Gold Miners Bull) Start Date:2010-12-08
NUHY (Nuveen ESG High Yield Corporate Bond ETF) Start Date:2019-09-26
NUKZ (Exchange Traded Concepts Trust Range Nuclear Renaissance Index) Start Date:2024-01-24
NULC (Nuveen ESG Large-Cap ETF) Start Date:2019-06-04
NULG (Nuveen ESG Large-Cap Growth ETF) Start Date:2016-12-14
NULV (Nuveen ESG Large-Cap Value ETF) Start Date:2016-12-14
NUMG (Nuveen ESG Mid-Cap Growth ETF) Start Date:2016-12-14
NUMI (Nushares ETF Trust Nuveen Municipal Income ETF) Start Date:2025-01-23
NUMV (Nuveen ESG Mid-Cap Value ETF) Start Date:2016-12-14
NURE (Nushares Short-Term Reit ETF) Start Date:2016-12-20
NUSA (Nuveen Enhanced Yield 1-5 Year U.S. Aggregate Bond ETF) Start Date:2017-04-03
NUSB (Nuveen Ultra Short Income ETF) Start Date:2024-03-06
NUSC (Nuveen ESG Small-Cap ETF) Start Date:2016-12-14
NUSI (Nationwide Risk-Managed Income ETF) Start Date:2019-12-20
NVBT (Aim ETF Products Trust Allianzim Us Large Cap Buffer10 Nov E) Start Date:2022-11-01
NVBW (Aim ETF Products Trust Allianzim Us Large Cap Buffer20 Nov E) Start Date:2022-11-01
NVD (Graniteshares 1.5X Short Nvda Daily ETF) Start Date:2023-08-22
NVDD (Direxion Daily Nvda Bear 1X Shares) Start Date:2023-09-13
NVDG (Leverage Shares 2X Long Nvda Daily ETF) Start Date:2024-12-13
NVDL (Graniteshares 1.5X Long Nvda Daily ETF) Start Date:2022-12-13
NVDQ (ETF Opportunities Trust T-Rex 2X Inverse Nvidia Daily Target E) Start Date:2012-03-01
NVDS (Axs 1.25X Nvda Bear Daily ETF) Start Date:2022-07-14
NVDU (Direxion Daily Nvda Bull 1.5X Shares) Start Date:2023-09-13
NVDW (Tradr 1.75X Long Nvda Weekly ETF) Start Date:2024-09-03
NVDX (ETF Opportunities Trust T-Rex 2X Long Nvidia Daily Target ETF) Start Date:2023-10-19
NVDY (Tidal ETF Trust Ii Yieldmax Nvda Option Income Strategy ETF) Start Date:2023-05-11
NVIR (Listed Funds Trust Horizon Kinetics Energy And Remediation ETF) Start Date:2023-02-22
NVOX (Tidal Trust Ii Defiance Daily Target 2X Long Nvo ETF) Start Date:2024-12-03
NVQ (Qraft Ai-Enhanced Us Next Value ETF) Start Date:2020-12-03
NXTE (Investment Managers Series Trust Ii Axs Green Alpha ETF) Start Date:2022-09-29
NXTG (First Trust Indxx Nextg ETF) Start Date:2011-02-18
NXTI (Simplify Exchange Traded Funds Simplify Next Intangible Core I) Start Date:2006-03-07
NXTV (Simplify Exchange Traded Funds Simplify Next Intangible Value) Start Date:2024-04-22
NYF (iShares S&P Ny Muni) Start Date:2007-10-05
NZAC (SPDR MSCI Acwi Climate Paris Aligned ETF) Start Date:2014-11-26
NZUS (SPDR MSCI Usa Climate Paris Aligned ETF) Start Date:2022-04-22
OACP (Unified Series Trust Oneascent Core Plus Bond ETF) Start Date:2022-03-31
OAEM (Unified Series Trust Oneascent Emerging Markets ETF) Start Date:2022-09-15
OAIA (Listed Funds Trust Teucrium Aila Long-Short Agriculture Strate) Start Date:2022-12-20
OAIM (Unified Series Trust Oneascent International Equity ETF) Start Date:2022-09-15
OAKM (Harris Oakmark ETF Trust Oakmark U.S. Large Cap ETF) Start Date:2024-12-03
OARK (Yieldmax Innovation Option Income Strategy ETF) Start Date:2022-11-25
OASC (Unified Series Trust Oneascent Small Cap Core ETF) Start Date:2024-06-14
OBIL (Us Treasury 12 Month Bill ETF) Start Date:2022-11-15
OBOR (Kraneshares MSCI One Belt One Road Index ETF) Start Date:2017-09-08
OCFS (Professionally Managed Portfolios Otter Creek Focus Strategy E) Start Date:2024-05-20
OCIO (ETF Series Solutions Trust ETF) Start Date:2017-06-27
OCTD (Innovator ETFs Trust Innovator Premium Income 10 Barrier ETF -) Start Date:2023-10-02
OCTH (Innovator ETFs Trust Innovator Premium Income 20 Barrier ETF -) Start Date:2023-10-02
OCTJ (Innovator ETFs Trust Innovator Premium Income 30 Barrier ETF -) Start Date:2023-10-02
OCTP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - October) Start Date:2024-06-03
OCTQ (Innovator ETFs Trust Innovator Premium Income 40 Barrier ETF -) Start Date:2023-10-02
OCTT (Allianzim Us Large Cap Buffer10 Oct ETF) Start Date:2020-10-01
OCTW (Allianzim Us Large Cap Buffer20 Oct ETF) Start Date:2020-10-01
OCTZ (Trueshares Structured Outcome) Start Date:2020-10-01
ODDS (Pacer Bluestar Digital Entertainment ETF) Start Date:2022-04-11
OEF (iShares S&P 100 Index Fund) Start Date:2000-10-27
OEUR (O'shares FTSE Europe Quality Div ETF) Start Date:2015-08-19
OFOS (Exchange Traded Concepts Trust Range Global Offshore Oil Servi) Start Date:2024-01-24
OGIG (O'shares Global Internet Giants ETF) Start Date:2018-06-05
OGSP (Spinnaker ETF Series Obra High Grade Structured Products ETF) Start Date:2024-04-10
OIH (Market Vectors Oil Services ETF) Start Date:2001-02-26
OIL (iPath S&P Gsci Crude Oil Tr ETN) Start Date:2011-04-21
OILD (Microsectors Oil & Gas Exp. & Prod. -3X Inverse Leveraged ETN) Start Date:2021-11-16
OILK (ProShares K-1 Free Crude Oil Strategy) Start Date:2016-09-28
OILT (Texas Capital Funds Trust Texas Capital Texas Oil Index ETF) Start Date:2023-12-21
OILU (Microsectors Oil & Gas Exp. & Prod. 3X Leveraged ETN) Start Date:2021-11-09
OMAH (Tidal Trust Iii Vistashares Target 15 Berkshire Select Income) Start Date:2025-03-05
OMFL (Invesco Russell 1000 Dynamic Multifactor ETF) Start Date:2017-11-10
OMFS (Invesco Russell 2000 Dynamic Multifactor ETF) Start Date:2017-11-10
OND (ProShares On-Demand ETF) Start Date:2021-10-27
ONEO (SPDR Russell 1000 Momentum ETF) Start Date:2015-12-03
ONEQ (Fidelity Nasdaq Composite Index Track) Start Date:2003-10-01
ONEV (SPDR Russell 1000 Low Vol Foc ETF) Start Date:2015-12-03
ONEY (SPDR Russell 1000 Yield ETF) Start Date:2015-12-03
ONG (iPath Pure Beta Energy ETN) Start Date:2022-01-20
ONLN (ProShares Online Retail ETF) Start Date:2018-07-16
ONOF (Global X Adaptive U.S. Risk Management ETF) Start Date:2021-01-13
OOQB (One One Nasdaq-100 And Bitcoin ETF) Start Date:2025-02-19
OOSB (One One S&P 500 And Bitcoin ETF) Start Date:2025-02-19
OOSP (Spinnaker ETF Series Obra Opportunistic Structured Products Et) Start Date:2024-04-10
OOTO (Direxion Daily Travel & Vacation Bull 2X Shares) Start Date:2021-06-10
OPER (ETF Series Solutions ETF Clearshares Ultra-Short Maturity ETF) Start Date:2018-07-11
OPPE (WisdomTree European Opportunities Fund) Start Date:2015-03-04
OPPX (Corbett Road Tactical Opportunity ETF) Start Date:2021-02-25
OPTZ (Optimize Strategy Index ETF) Start Date:2024-04-23
ORCX (Defiance Daily Target 2X Long Orcl ETF) Start Date:2025-02-07
ORR (Militia Long/Short Equity ETF) Start Date:2025-01-15
OSCV (Opus Small Cap Value ETF) Start Date:2018-07-18
OSEA (Harbor ETF Trust Harbor International Compounders ETF) Start Date:2022-09-08
OUNZ (Van Eck Merk Gold Trust) Start Date:2014-05-16
OUSA (O'shares FTSE Us Quality Dividend ETF) Start Date:2015-07-14
OUSM (Oshares U.S. Small-Cap Quality Dividend ETF) Start Date:2016-12-30
OVB (Overlay Shares Core Bond ETF) Start Date:2019-10-01
OVF (Overlay Shares Foreign Equity ETF) Start Date:2019-10-01
OVL (Overlay Shares Large Cap Equity ETF) Start Date:2019-10-01
OVLH (Overlay Shares Hedged Large Cap Equity ETF) Start Date:2021-01-15
OVM (Overlay Shares Municipal Bond ETF) Start Date:2019-10-01
OVS (Overlay Shares Small Cap Equity ETF) Start Date:2019-10-01
OVT (Overlay Shares Short Term Bond ETF) Start Date:2021-01-15
OWNS (Impact Shares Affordable Housing Mbs ETF) Start Date:2021-07-27
OZEM (Roundhill Glp-1 & Weight Loss ETF) Start Date:2024-05-21
PAAA (Pgim ETF Trust Pgim Aaa Clo ETF) Start Date:2023-07-27
PABD (iShares Paris-Aligned Climate MSCI World Ex Usa ETF) Start Date:2024-01-19
PABU (iShares Paris-Aligned Climate MSCI Usa ETF) Start Date:2022-04-20
PAK (Global X MSCI Pakistan ETF) Start Date:2015-04-23
PALC (Pacer Lunt Large Cap Multi-Factor Alternator ETF) Start Date:2020-06-25
PALL (Aberdeen Standard Physical Palladium Shares ETF) Start Date:2010-01-08
PAMC (Pacer Lunt Midcap Multi-Factor Alternator ETF) Start Date:2020-06-25
PAPI (Morgan Stanley ETF Trust Parametric Equity Premium Income ETF) Start Date:2023-10-19
PAPR (Innovator S&P 500 Power Buffer ETF) Start Date:2019-04-01
PATN (Pacer Nasdaq International Patent Leaders ETF) Start Date:2024-09-17
PAUG (Innovator Us Equity Power Buffer ETF - August) Start Date:2019-08-01
PAVE (Global X Us Infrastructure Development ETF) Start Date:2017-03-08
PAWZ (ProShares Pet Care ETF) Start Date:2018-11-06
PBAP (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - April) Start Date:2024-04-01
PBAU (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - August) Start Date:2024-06-11
PBD (Invesco Global Clean Energy ETF) Start Date:2007-06-13
PBDC (Putnam ETF Trust Putnam Bdc Income ETF) Start Date:2022-09-30
PBDE (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - Decembe) Start Date:2024-06-07
PBDM (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-09-22
PBE (Invesco Dynamic Biotechnology & Genome ETF) Start Date:2005-06-23
PBEE (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-09-22
PBFB (Pgim Us Large-Cap Buffer 12 ETF - January Pgim Us Large-Cap Bu) Start Date:2024-02-01
PBFR (Shl Telemedicine Pgim Laddered Fund Of Buffer 20 ETF) Start Date:2024-06-14
PBJ (Invesco Dynamic Food & Beverage ETF) Start Date:2005-06-23
PBJA (Pgim Us Large-Cap Buffer 12 ETF - January Pgim Us Large-Cap Bu) Start Date:2024-01-02
PBJL (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - July) Start Date:2024-06-11
PBJN (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - June) Start Date:2024-06-03
PBL (Pgim ETF Trust Pgim Portfolio Ballast ETF) Start Date:2022-12-14
PBMR (Pgim Us Large-Cap Buffer 12 ETF - January Pgim Us Large-Cap Bu) Start Date:2024-03-01
PBMY (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - May) Start Date:2024-05-01
PBND (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-09-29
PBNV (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - November) Start Date:2024-05-29
PBOC (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - October) Start Date:2024-06-11
PBP (PowerShares S&P 500 Buywrite ETF) Start Date:2007-12-21
PBQQ (Pgim Laddered Nasdaq-100 Buffer 12 ETF) Start Date:2025-01-02
PBS (Invesco Dynamic Media ETF) Start Date:2005-06-23
PBSE (Shl Telemedicine Pgim Us Large-Cap Buffer 20 ETF - Septemb) Start Date:2024-06-11
PBSM (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-09-22
PBTP (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-09-22
PBUS (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-09-22
PBW (Invesco Wilderhill Clean Energy ETF) Start Date:2005-03-03
PCCE (Litman Gregory Funds Trust Polen Capital China Growth ETF) Start Date:2024-03-15
PCEF (Invesco Cef Income Composite ETF) Start Date:2010-02-19
PCEM (Litman Gregory Funds Trust Polen Capital Emerging Markets Ex C) Start Date:2024-09-12
PCGG (Litman Gregory Funds Trust Polen Capital Global Growth ETF) Start Date:2023-08-30
PCIG (Litman Gregory Funds Trust Polen Capital International Growth) Start Date:2024-03-15
PCLO (Virtus ETF Trust Ii Virtus Seix Aaa Private Credit Clo ETF) Start Date:2024-12-03
PCMM (Bondbloxx Private Credit Clo ETF) Start Date:2024-12-03
PCRB (Putnam ETF Trust Putnam ESG Core Bond ETF) Start Date:2023-01-20
PCY (PowerShares Emerging Markets So) Start Date:2007-10-11
PDBA (Invesco Agriculture Commodity Strategy No K-1 ETF) Start Date:2022-08-24
PDBC (Invesco Optimum Yield Diversified Commodity Strategy No K-1 ETF) Start Date:2014-11-07
PDEC (Innovator Us Equity Power Buffer ETF - December) Start Date:2019-12-02
PDN (Invesco FTSE Rafi Developed Markets Ex-U.S. Small-Mid ETF) Start Date:2007-09-27
PDP (Invesco DWA Momentum ETF) Start Date:2007-03-01
PEJ (Invesco Dynamic Leisure And Entertainment ETF) Start Date:2005-06-23
PEMX (Putnam ETF Trust Putnam Emerging Markets Ex-China ETF) Start Date:2023-05-18
PEPS (Parametric Equity Plus ETF) Start Date:2025-04-22
PEVC (Pacer Funds Trust Pacer Pe/Vc ETF) Start Date:2025-02-04
PEX (ProShares Global Listed Private Equity) Start Date:2013-02-28
PEXL (Pacer Us Export Leaders ETF) Start Date:2018-07-24
PEY (PowerShares High Yld Eq Div Achiev ETF) Start Date:2004-12-09
PEZ (Invesco DWA Consumer Cyclicals Momentum ETF) Start Date:2006-10-12
PFEB (Innovator S&P 500 Power Buffer ETF February Series) Start Date:2020-02-03
PFF (iShares S&P Us Preferred Stock) Start Date:2007-03-30
PFFA (Virtus Infracap U.S. Preferred Stock ETF) Start Date:2018-05-16
PFFD (Global X U.S. Preferred ETF) Start Date:2017-09-13
PFFL (Ubs Etracs 2Xmonthly Pay Leveraged Preferred Stock Index ETN Sept 25 2048) Start Date:2018-09-26
PFFR (Infracap Reit Preferred ETF) Start Date:2017-02-08
PFFV (Global X Variable Rate Preferred ETF) Start Date:2020-06-25
PFI (PowerShares DWA Financial Momentum ETF) Start Date:2006-10-12
PFIG (PowerShares Fundamental Investm) Start Date:2011-09-15
PFIX (Simplify Interest Rate Hedge ETF) Start Date:2021-05-11
PFLD (Aam Low Duration Preferred And Income Securities ETF) Start Date:2019-11-20
PFM (PowerShares Dividend Achievers ETF) Start Date:2005-09-15
PFRL (Pgim ETF Trust Pgim Floating Rate Income ETF) Start Date:2022-06-09
PFUT (Putnam Sustainable Future ETF) Start Date:2021-05-26
PFXF (Vaneck Vectors Preferred Securities Ex Financials ETF) Start Date:2012-07-17
PGAL (Global X MSCI Portugal ETF) Start Date:2013-11-13
PGF (Invesco Financial Preferred ETF) Start Date:2006-12-06
PGHY (Invesco Global Short Term High Yield Bond ETF) Start Date:2013-06-21
PGJ (PowerShares Golden Dragon China ETF) Start Date:2004-12-09
PGM (iPath Dj-Ubs Platinum Subindex) Start Date:2018-01-18
PGRO (Putnam Focused Large Cap Growth ETF) Start Date:2021-05-26
PGX (PowerShares Preferred Portfolio) Start Date:2008-01-31
PHB (PowerShares High Yield Corporat) Start Date:2007-11-15
PHDG (PowerShares S&P 500 Downside Hedged ETF) Start Date:2012-12-06
PHEQ (Parametric Hedged Equity ETF) Start Date:2023-10-19
PHO (Invesco Water Resources ETF) Start Date:2005-12-06
PHYD (Putnam ESG High Yield ETF) Start Date:2023-01-20
PHYL (Pgim Active High Yield Bond ETF) Start Date:2018-09-27
PHYS (Sprott Physical Gold Trust) Start Date:2010-02-26
PICB (PowerShares International Corpo) Start Date:2010-06-03
PICK (iShares MSCI Global Select Metals & Mining Producers ETF) Start Date:2012-02-02
PID (Invesco International Dividend Achieversâ„¢ ETF) Start Date:2005-09-15
PIE (PowerShares DWA Emerging Markets Mom ETF) Start Date:2007-12-28
PIFI (Clearshares Piton Intermediate Fixed Income ETF) Start Date:2020-10-02
PILL (Direxion Daily Pharmctcl&Medcl Bl 2X ETF) Start Date:2017-11-15
PIN (PowerShares India ETF) Start Date:2008-03-05
PINK (Simplify Health Care ETF) Start Date:2021-10-08
PIO (Invesco Global Water ETF) Start Date:2007-06-13
PIT (Vaneck Commodity Strategy ETF) Start Date:2022-12-22
PIZ (PowerShares DWA Developed Mkts Mom ETF) Start Date:2007-12-28
PJAN (Innovator S&P 500 Power Buffer ETF) Start Date:2019-01-02
PJBF (Pgim ETF Trust Pgim Jennison Better Future ETF) Start Date:2023-12-26
PJFG (Pgim Jennison Focused Growth ETF) Start Date:2022-12-14
PJFM (Pgim ETF Trust Pgim Jennison Focused Mid-Cap ETF) Start Date:2023-12-19
PJFV (Pgim Jennison Focused Value ETF) Start Date:2022-12-14
PJIO (Pgim ETF Trust Pgim Jennison International Opportunities ETF) Start Date:2023-12-19
PJP (Invesco Dynamic Pharmaceuticals ETF) Start Date:2005-06-23
PJUL (Innovator S&P 500 Power Buffer ETF) Start Date:2018-08-08
PJUN (Innovator Us Equity Power Buffer ETF - June) Start Date:2019-06-03
PKB (PowerShares Dynamic Building & Const ETF) Start Date:2005-10-26
PKW (PowerShares Buyback Achievers ETF) Start Date:2006-12-20
PLAT (WisdomTree Growth Leaders Fund) Start Date:2019-05-22
PLDR (Putnam Sustainable Leaders ETF) Start Date:2021-05-26
PLRG (Principal U.S. Large-Cap Adaptive Multi-Factor ETF) Start Date:2021-05-20
PLTD (Direxion Daily Pltr Bear 1X Shares) Start Date:2025-01-02
PLTL (Principal U.S. Small-Cap Adaptive Multi-Factor ETF) Start Date:2021-05-20
PLTM (First Trust Ise Global Platinum) Start Date:2018-02-05
PLTU (Direxion Daily Pltr Bull 2X Shares) Start Date:2024-12-11
PLTY (Tidal Trust Ii Yieldmax Pltr Option Income Strategy ETF) Start Date:2024-10-08
PLW (PowerShares 1-30 Treasury Ladde) Start Date:2007-10-11
PMAR (Innovator Us Equity Power Buffer ETF - March) Start Date:2020-03-02
PMAY (Innovator Us Equity Power Buffer ETF - May) Start Date:2020-05-01
PMBS (Pimco Mortgage-Backed Securities Active Exchange-Traded Fund) Start Date:2024-09-23
PMIO (Pgim ETF Trust Pgim Municipal Income Opportunities ETF) Start Date:2024-12-18
PMMF (Blackrock ETF Trust iShares Prime Money Market ETF) Start Date:2025-02-06
PNOV (Innovator Us Equity Power Buffer ETF - November) Start Date:2019-11-01
PNQI (PowerShares Nasdaq Internet ETF) Start Date:2008-06-13
POCT (Innovator S&P 500 Power Buffer ETF) Start Date:2018-10-01
POTX (Global X Cannabis ETF) Start Date:2019-09-20
POWA (Invesco Bloomberg Pricing Power ETF) Start Date:2007-05-16
PP (Meet Kevin Pricing Power ETF) Start Date:2022-11-29
PPA (Invesco Aerospace & Defense ETF) Start Date:2005-12-01
PPEM (Putnam Panagora ESG Emerging Markets Equity ETF) Start Date:2023-01-20
PPH (Vaneck Vectors Pharmaceutical ETF) Start Date:2011-12-22
PPI (Investment Managers Series Trust Ii Axs Astoria Inflation Sens) Start Date:2021-12-30
PPIE (Putnam Panagora ESG International Equity ETF) Start Date:2023-01-20
PPLT (Aberdeen Standard Platinum Shares ETF) Start Date:2010-01-08
PPTY (Ppty - U.S. Diversified Real Estate ETF) Start Date:2018-03-27
PQAP (Pgim Nasdaq-100 Buffer 12 ETF - April) Start Date:2025-01-02
PQDI (Principal Spectrum Tax-Advantaged Dividend Active ETF) Start Date:2020-06-17
PQJA (Pgim Nasdaq-100 Buffer 12 ETF - January) Start Date:2025-01-02
PQJL (Pgim Nasdaq-100 Buffer 12 ETF - July) Start Date:2025-01-02
PQOC (Pgim Nasdaq-100 Buffer 12 ETF - October) Start Date:2025-01-02
PRAE (Northern Lights Fund Trust Iii Planrock Alternative Growth ETF) Start Date:2023-12-19
PRAY (Neos ETF Trust Fis Christian Stock Fund) Start Date:2022-02-08
PREF (Principal Spectrum Preferred Securities Active ETF) Start Date:2017-07-11
PRF (Invesco FTSE Rafi Us 1000 ETF) Start Date:2005-12-20
PRFD (Pimco Preferred & Capital Securities Active ETF) Start Date:2023-01-19
PRFZ (Invesco FTSE Rafi Us 1500 Small-Mid ETF) Start Date:2006-09-20
PRIV (SPDR Ssga Ig Public & Private Credit ETF) Start Date:2025-02-27
PRMN (Northern Lights Fund Trust Iii Planrock Market Neutral Income) Start Date:2023-12-19
PRN (Invesco DWA Industrials Momentum ETF) Start Date:2007-05-16
PRNT (3D Printing ETF) Start Date:2016-07-19
PSC (Principal U.S. Small Cap Multi-Factor ETF) Start Date:2016-09-22
PSCC (Invesco S&P Smallcap Consumer Staples ETF) Start Date:2010-04-07
PSCD (PowerShares S&P Smcap Cnsmr Discret ETF) Start Date:2010-04-07
PSCE (PowerShares S&P Smallcap Energy ETF) Start Date:2010-04-07
PSCF (PowerShares S&P Smallcap Financ) Start Date:2010-04-07
PSCH (Invesco S&P Smallcap Health Care ETF) Start Date:2010-04-07
PSCI (Invesco S&P Smallcap Industrials ETF) Start Date:2010-04-07
PSCJ (Pacer Swan Sos Conservative) Start Date:2021-11-02
PSCM (PowerShares S&P Smallcap Materials ETF) Start Date:2010-04-07
PSCQ (Pacer Swan Sos Conservative) Start Date:2021-10-01
PSCT (Invesco S&P Smallcap Information Technology ETF) Start Date:2010-04-07
PSCU (PowerShares S&P Smallcap Utilities ETF) Start Date:2010-04-07
PSCW (Pacer Swan Sos Conservative) Start Date:2021-11-05
PSCX (Pacer Swan Sos Conservative) Start Date:2020-12-23
PSDM (Pgim ETF Trust Pgim Short Duration Multi-Sector Bond ETF) Start Date:2023-08-01
PSDN (AdvisorShares Poseidon Dynamic Cannabis ETF) Start Date:2021-11-17
PSEP (Innovator Us Equity Power Buffer ETF - September) Start Date:2019-09-03
PSET (Principal Price Setters Index ETF) Start Date:2016-03-22
PSFD (Pacer Swan Sos Flex) Start Date:2020-12-23
PSFF (Pacer Swan Sos Fund Of Funds ETF) Start Date:2020-12-30
PSFJ (Pacer Swan Sos Flex) Start Date:2021-11-05
PSFM (Pacer Swan Sos Flex) Start Date:2021-11-05
PSFO (Pacer Swan Sos Flex) Start Date:2021-10-01
PSH (Pgim ETF Trust Pgim Short Duration High Yield ETF) Start Date:2023-12-19
PSI (PowerShares Dynamic Semiconductors ETF) Start Date:2005-06-23
PSIL (AdvisorShares Psychedelics ETF) Start Date:2021-09-16
PSJ (PowerShares Dynamic Software ETF) Start Date:2005-06-23
PSK (SPDR Wells Fargo Preferred Stock ETF) Start Date:2009-09-17
PSL (Invesco DWA Consumer Staples Momentum ETF) Start Date:2006-10-12
PSLV (Sprott Physical Silver Trust) Start Date:2010-10-29
PSMB (PowerShares Bal Multi-Asst Allc) Start Date:2017-02-23
PSMC (PowerShares Cnsrv Multi-Asst Allc) Start Date:2017-02-23
PSMD (Pacer Swan Sos Moderate) Start Date:2020-12-23
PSMG (PowerShares Gr Multi-Asst Allc) Start Date:2017-02-23
PSMJ (Pacer Swan Sos Moderate) Start Date:2021-11-02
PSMM (Invesco Actively Managed Exchange-Traded Fund Trus) Start Date:2017-02-23
PSMO (Pacer Swan Sos Moderate) Start Date:2021-10-01
PSMR (Pacer Swan Sos Moderate) Start Date:2021-11-05
PSP (Invesco Global Listed Private Equity ETF) Start Date:2006-10-24
PSQ (ProShares Short Qqq) Start Date:2006-06-21
PSQA (Palmer Square Funds Trust Palmer Square Clo Senior Debt ETF) Start Date:2024-09-12
PSQO (Palmer Square Funds Trust Palmer Square Credit Opportunities E) Start Date:2024-09-13
PSR (PowerShares Active U.S. Real Es) Start Date:2008-11-21
PST (ProShares Ultrashort Lehman 7-1) Start Date:2008-05-01
PSTP (Innovator Power Buffer Step-Up Strategy ETF) Start Date:2022-03-08
PSTR (Peakshares Sector Rotation ETF) Start Date:2024-04-30
PSWD (Xtrackers Cybersecurity Select Equity ETF) Start Date:2023-07-13
PTBD (Pacer Trendpilot Us Bond ETF) Start Date:2019-10-23
PTEC (Global X Proptech ETF) Start Date:2023-04-13
PTEU (Pacer Trendpilot European Index ETF) Start Date:2015-12-15
PTF (Invesco DWA Technology Momentum ETF) Start Date:2006-10-12
PTH (Invesco DWA Healthcare Momentum ETF) Start Date:2006-10-12
PTIN (Pacer Trendpilot International ETF) Start Date:2019-05-03
PTIR (Graniteshares 2X Long Pltr Daily ETF) Start Date:2024-09-04
PTL (Northern Lights Fund Trust Iv Inspire 500 ETF) Start Date:2024-03-26
PTLC (Pacer Trendpilot Us Large Cap ETF) Start Date:2015-06-12
PTMC (Pacer Trendpilot Us Mid Cap ETF) Start Date:2015-06-12
PTNQ (Pacer Trendpilot 100 ETF) Start Date:2015-06-12
PTRB (Pgim Total Return Bond ETF) Start Date:2021-12-08
PUI (PowerShares DWA Utilities Momentum ETF) Start Date:2005-10-26
PULS (Pgim Ultra Short Bond ETF) Start Date:2018-04-10
PULT (Putnam Sustainable Future ETF) Start Date:2023-01-20
PUSH (Pgim ETF Trust Pgim Ultra Short Municipal Bond ETF) Start Date:2025-01-03
PUTD (Cboe Validus S&P 500 Dynamic Putwrite Index ETF) Start Date:2023-08-10
PUTW (WisdomTree Cboe S&P 500 Putwrite Strategy Fund) Start Date:2016-02-24
PVAL (Principal Contrarian Value Index ETF) Start Date:2021-05-26
PVI (PowerShares Vrdo Tax Free Weekl) Start Date:2007-11-15
PWB (PowerShares Dynamic Large Cap Growth ETF) Start Date:2005-03-03
PWC (PowerShares Dynamic Market ETF) Start Date:2003-11-14
PWER (Macquarie ETF Trust Macquarie Energy Transition ETF) Start Date:2023-11-29
PWRD (TCWTransform Systems ETF) Start Date:2022-02-03
PWS (Pacer Wealthshield ETF) Start Date:2017-12-12
PWV (PowerShares Dynamic Large Cap Value ETF) Start Date:2005-03-03
PWZ (Invesco California Amt-Free Municipal Bond ETF) Start Date:2007-10-11
PXE (PowerShares Dynamic Engy Explr&Prdtn ETF) Start Date:2005-11-01
PXF (Invesco FTSE Rafi Developed Markets Ex-U.S. ETF) Start Date:2007-06-25
PXH (Invesco FTSE Rafi Emerging Markets ETF) Start Date:2007-09-27
PXI (PowerShares DWA Energy Momentum ETF) Start Date:2006-10-12
PXJ (PowerShares Dynamic Oil & Gas Svcs ETF) Start Date:2005-10-26
PXQ (PowerShares Dynamic Networking ETF) Start Date:2005-06-23
PXUS (Principal International Multi-Factor Index ETF) Start Date:2021-05-27
PY (Principal Shareholder Yield Index ETF) Start Date:2016-03-22
PYLD (Pimco Multisector Bond Active ETF) Start Date:2023-06-22
PYPE (Ubs Etracs Nyse Pickens Core Midstream Index ETN Exp 20Th Aug 2048) Start Date:2018-08-21
PYPY (Yieldmax Pypl Option Income Strategy ETF) Start Date:2023-09-26
PYZ (PowerShares DWA Basic Materials Mom ETF) Start Date:2006-10-12
PZA (Invesco National Amt-Free Municipal Bond ETF) Start Date:2007-10-11
PZT (PowerShares Insured Ny Municipa) Start Date:2007-10-11
QABA (First Trust Nasdaq Aba Community Bank Index) Start Date:2009-07-01
QAI (IQ Hedge Multi-Strategy Tracker ETF) Start Date:2009-03-25
QARP (Xtrackers Russell 1000 Us Quality At A Reasonable Price ETF Et) Start Date:2018-04-05
QAT (iShares MSCI Qatar Capped) Start Date:2014-05-01
QBER (Elevation Series Trust Trueshares Quarterly Bear Hedge ETF) Start Date:2024-07-02
QBF (Innovator ETFs Trust Innovator Uncapped Bitcoin 20 Floor ETF) Start Date:2025-02-06
QBIG (Invesco Top Qqq ETF) Start Date:2024-12-04
QBUF (Innovator Nasdaq-100 10 Buffer ETF Quarterly) Start Date:2024-07-01
QBUL (Elevation Series Trust Trueshares Quarterly Bull Hedge ETF) Start Date:2024-07-02
QCAP (First Trust Exchange-Traded Fund Viii FTVest Nasdaq-100 Conse) Start Date:2024-04-22
QCJL (First Trust Exchange-Traded Fund Viii FTVest Nasdaq-100 Conse) Start Date:2024-07-22
QCLN (First Trust Nasdaq Clean Edge Green Energy Index Fund) Start Date:2007-02-14
QCLR (Global X Nasdaq 100 Collar 95-110 ETF) Start Date:2021-08-26
QCML (Graniteshares 2X Long Qcom Daily ETF) Start Date:2025-02-13
QCON (American Century ETF Trust American Century Quality Convertibl) Start Date:2021-02-18
QDCC (Global X Funds Global X S&P 500 Quality Dividend Covered Call) Start Date:2024-05-08
QDEC (FTCboe Vest Nasdaq-100 Buffer ETF December) Start Date:2020-12-21
QDEF (Flexshares Quality Dividend Defensv ETF) Start Date:2012-12-19
QDF (Flexshares Quality Dividend Index Fund) Start Date:2012-12-19
QDIV (Global X S&P 500 Quality Dividend ETF) Start Date:2018-07-17
QDPL (Pacer Metaurus Us Large Cap Dividend Multiplier 400 ETF) Start Date:2021-07-13
QDTE (Roundhill Innovation-100 0Dte Covered Call Strategy ETF) Start Date:2024-03-07
QDTY (Yieldmax Nasdaq 100 0Dte Covered Call Strategy ETF) Start Date:2025-02-13
QDVO (Amplify ETF Trust Amplify Cwp Growth & Income ETF) Start Date:2024-08-22
QDYN (Flexshares Quality Dividend Dynamic ETF) Start Date:2012-12-19
QEFA (SPDR MSCI Eafe Strategicfactors ETF) Start Date:2014-06-05
QEMM (SPDR MSCI Emerging Markets Strategicfactors ETF) Start Date:2014-06-05
QETH (Invesco Galaxy Ethereum ETF Invesco Galaxy Ethereum ETF) Start Date:2024-07-23
QFLR (Innovator ETFs Trust Innovator Nasdaq-100 Managed Floor ETF) Start Date:2024-01-25
QGRO (American Century STOXX U.S. Quality Growth ETF) Start Date:2018-09-12
QGRW (WisdomTree Us Quality Growth Fund) Start Date:2022-12-15
QHDG (Innovator Hedged Nasdaq-100 ETF) Start Date:2024-08-20
QHY (WisdomTree Us High Yield Corporate Bond Fund) Start Date:2024-07-08
QID (ProShares Ultrashort Qqq) Start Date:2006-07-13
QIDX (Spinnaker ETF Series Indexperts Quality Earnings Focused ETF) Start Date:2025-01-02
QIG (WisdomTree Us Corporate Bond Fund) Start Date:2024-07-09
QINT (American Century Quality Diversified International ETF) Start Date:2018-09-12
QIS (Simplify Multi-Qis Alternative ETF) Start Date:2023-07-11
QLC (Flexshares Us Quality Large Cap Index Fund) Start Date:2015-09-24
QLD (ProShares Ultra Qqq) Start Date:2006-06-21
QLTA (iShares Aaa â€“ A Rated Corporate Bond ETF) Start Date:2012-02-16
QLTI (The 2023 ETF Series Trust Ii Gmo International Quality ETF) Start Date:1999-02-26
QLTY (The 2023 ETF Series Trust Ii Gmo Us Quality ETF) Start Date:2023-11-15
QLV (Flexshares Us Quality Low Volatility Index Fund) Start Date:2019-07-16
QLVD (Flexshares Developed Markets Ex-Us Quality Low Volatility Inde) Start Date:2019-07-16
QLVE (Flexshares Emerging Markets Quality Low Volatility Index Fund) Start Date:2019-07-16
QMAR (FTCboe Vest Nasdaq-100 Buffer ETF - March) Start Date:2021-03-22
QMID (WisdomTree Us Midcap Quality Growth Fund) Start Date:2024-01-25
QMMY (First Trust Exchange-Traded Fund Viii FTVest Nasdaq-100 Moder) Start Date:2024-05-20
QMOM (Alpha Architect ETF Trust) Start Date:2015-12-02
QNXT (iShares Nasdaq-100 Ex Top 30 ETF) Start Date:2024-10-24
QOWZ (Invesco Nasdaq Free Cash Flow Achievers ETF) Start Date:2023-12-06
QPFF (American Century ETF Trust American Century Quality Preferred) Start Date:2021-02-18
QPX (AdvisorShares Q Dynamic Growth ETF) Start Date:2020-12-29
QQA (Invesco Qqq Income Advantage ETF) Start Date:2024-07-17
QQC (Simplify Nasdaq 100 Plus Convexity ETF) Start Date:2020-12-11
QQD (Simplify Nasdaq 100 Plus Downside Convexity ETF) Start Date:2020-12-11
QQEW (First Trust Nasdaq 100 Equal Weight) Start Date:2006-05-02
QQH (Hcm Defender 100 Index ETF) Start Date:2019-10-10
QQJG (Invesco ESG Nasdaq Next Gen 100 ETF) Start Date:2021-10-27
QQLV (Invesco Qqq Low Volatility ETF) Start Date:2024-12-04
QQMG (Invesco ESG Nasdaq 100 ETF) Start Date:2021-10-28
QQQ (PowerShares Qqq) Start Date:2000-01-03
QQQA (ProShares Nasdaq-100 Dorsey Wright Momentum ETF) Start Date:2021-05-20
QQQD (Direxion Daily Magnificent 7 Bear 1X Shares) Start Date:2024-03-07
QQQE (Direxion Nasdaq-100 Equal Wtd ETF) Start Date:2012-03-21
QQQG (Pacer Nasdaq 100 Top 50 Cash Cows Growth Leaders ETF) Start Date:2024-08-21
QQQH (Neos Nasdaq-100 Hedged Equity Income ETF) Start Date:2019-12-20
QQQI (Neos Nasdaq 100 High Income ETF) Start Date:2024-01-30
QQQJ (Invesco Nasdaq Next Gen 100 ETF) Start Date:2020-10-13
QQQM (Invesco Nasdaq 100 ETF) Start Date:2020-10-13
QQQN (Victoryshares Nasdaq Next 50 ETF) Start Date:2020-09-10
QQQP (Tradr 2X Long Triple Q Quarterly ETF) Start Date:2024-10-01
QQQS (Invesco Nasdaq Future Gen 200 ETF) Start Date:2022-10-13
QQQT (Defiance Nasdaq 100 Income Target ETF) Start Date:2024-06-21
QQQU (Direxion Daily Magnificent 7 Bull 2X Shares) Start Date:2024-03-07
QQQY (Defiance Nasdaq 100 Enhanced Options Income ETF) Start Date:2023-09-14
QQXT (First Trust Nasdaq-100 Ex-Tech Sect ETF) Start Date:2007-05-08
QRFT (Qraft Ai-Enhanced U.S. Large Cap ETF) Start Date:2019-05-21
QRMI (Global X Nasdaq 100 Risk Managed Income ETF) Start Date:2021-08-26
QSIG (WisdomTree Us Short Term Corporate Bond Fund) Start Date:2024-07-08
QSIX (Pacer Metaurus Nasdaq 100 Dividend Multiplier 600 ETF) Start Date:2024-09-24
QSML (WisdomTree Us Smallcap Quality Growth Fund) Start Date:2024-01-25
QSPT (FTCboe Vest Nasdaq-100 Buffer ETF - September) Start Date:2021-09-20
QSWN (Amplify ETF Trust Amplify Blackswan Tech & Treasury ETF) Start Date:2021-12-09
QTAP (Innovator Growth Accelerated Plus ETF - April) Start Date:2021-04-01
QTEC (First Trust Nasdaq 100 Technology) Start Date:2006-05-03
QTJA (Innovator ETFs Trust Innovator Growth Accelerated Plus ETF - J) Start Date:2022-01-03
QTJL (Innovator Growth Accelerated Plus ETF - July) Start Date:2021-07-01
QTOC (Innovator Growth Accelerated Plus ETF - October) Start Date:2021-10-01
QTOP (iShares Nasdaq Top 30 Stocks ETF) Start Date:2024-10-24
QTPI (Exchange Place Advisors Trust North Square Rcim Tax-Advantaged) Start Date:2024-12-19
QTR (Global X Nasdaq 100 Tail Risk ETF) Start Date:2021-08-26
QTUM (Defiance Quantum ETF) Start Date:2018-09-05
QUAL (iShares Edge MSCI Usa Quality Factor ETF) Start Date:2013-07-18
QULL (Etracs 2X Leveraged MSCI Us Quality Factor Tr ETN) Start Date:2021-02-09
QUS (SPDR MSCI Usa Strategicfactors ETF) Start Date:2015-04-16
QUVU (Hartford Funds Exchange-Traded Trust Hartford Quality Value Et) Start Date:2023-10-16
QVAL (Alpha Architect ETF Trust) Start Date:2014-10-22
QVML (Invesco S&P 500 Qvm Multi-Factor ETF) Start Date:2021-06-30
QVMM (Invesco S&P Midcap 400 Qvm Multi-Factor ETF) Start Date:2021-06-30
QVMS (Invesco S&P Smallcap 600 Qvm Multi-Factor ETF) Start Date:2021-06-30
QVOY (Q3 All-Season Active Rotation ETF Q3 All-Season Active Rotatio) Start Date:2022-12-07
QWLD (SPDR MSCI World Strategicfactors ETF) Start Date:2014-06-05
QXQ (Sgi Enhanced Nasdaq-100 ETF) Start Date:2024-06-14
QYLD (Global X Nasdaq 100 Covered Call ETF) Start Date:2013-12-12
QYLE (Global X Nasdaq 100 ESG Covered Call ETF) Start Date:2023-02-22
QYLG (Global X Nasdaq 100 Covered Call & Growth ETF) Start Date:2020-09-22
RAA (Smi 3Fourteen Real Asset Allocation ETF) Start Date:2025-02-26
RAAX (Vaneck Inflation Allocation ETF) Start Date:2018-04-10
RAFE (Pimco Rafi ESG U.S. ETF) Start Date:2019-12-19
RATE (Global X Funds Global X Interest Rate Hedge ETF) Start Date:2007-05-02
RAVI (Flexshares Ready Access Variable Inc ETF) Start Date:2012-10-11
RAYC (Rayliant Quantamental China Equity ETF) Start Date:2020-12-31
RAYD (The Advisors' Inner Circle Fund Iii Rayliant Quantitative Deve) Start Date:2021-12-16
RAYE (The Advisors' Inner Circle Fund Iii Rayliant Quantamental Emer) Start Date:2021-12-16
RAYJ (The Advisors' Inner Circle Fund Iii Rayliant Smdam Japan Equit) Start Date:2024-04-04
RAYS (Global X Solar ETF) Start Date:2021-09-09
RBIL (F/M Ultrashort Treasury Inflation-Protected Security) Start Date:2025-02-25
RBLD (First Trust Alerian Us Nextgen Infrastructure ETF) Start Date:2008-10-15
RBND (SPDR Bloomberg Sasb Corporate Bond ESG Select ETF) Start Date:2020-11-10
RBUF (Shl Telemedicine Innovator U.S. Small Cap 10 Buffer ETF -) Start Date:2024-07-01
RCGE (Rockcreek Global Equality ETF) Start Date:2025-02-27
RDFI (Rareview Dynamic Fixed Income ETF) Start Date:2020-11-02
RDIV (Oppenheimer Ultra Dividend Revenue ETF) Start Date:2013-10-01
RDOG (Alps ETF Trust Alps Reit Dividend Dogs ETF) Start Date:2020-01-02
RDTY (Yieldmax R2000 0Dte Covered Strategy ETF) Start Date:2025-03-06
RDVI (First Trust Exchange-Traded Fund Iv FTCboe Vest Rising Divide) Start Date:2022-10-20
RDVY (First Trust Nasdaq Rising Dividend Achievers ETF) Start Date:2014-01-07
REAI (Private Real Estate Strategy Via Liquid Reits ETF) Start Date:2023-06-13
RECS (Columbia Research Enhanced Core ETF) Start Date:2019-09-25
REET (iShares Global Reit ETF) Start Date:2014-07-10
REGL (ProShares Trust) Start Date:2015-12-15
REIT (Alps Active Reit ETF) Start Date:2021-02-26
REK (ProShares Short Real Estate) Start Date:2010-03-18
REKT (Direxion Shares ETF Trust Direxion Daily Crypto Industry Bear) Start Date:2024-07-17
REM (iShares Mortgage Real Estate ETF) Start Date:2007-05-04
REMG (Ssga Active Trust SPDR Bloomberg Sasb Emerging Markets ESG Sel) Start Date:2022-01-11
REMX (Vaneck Vectors Rare Earth/Strategic Metals ETF) Start Date:2010-10-28
RENW (Harbor ETF Trust Harbor Energy Transition Strategy ETF) Start Date:2022-07-14
RESD (WisdomTree Trust) Start Date:2020-03-16
RESE (WisdomTree Trust) Start Date:2020-03-16
RESP (WisdomTree U.S. ESG Fund) Start Date:2007-05-16
RETL (Direxion Daily Retail Bull 3X Shares) Start Date:2010-07-14
REVS (Columbia Research Enhanced Value ETF) Start Date:2019-09-25
REW (ProShares Ultra Short Technology) Start Date:2007-02-02
REZ (iShares Residential Real Estate ETF) Start Date:2007-05-04
RFCI (Riverfront Dynamic Core Income ETF) Start Date:2016-06-17
RFDA (Riverfront Dynamic Us Dividend Advtg ETF) Start Date:2016-06-07
RFDI (First Trust Riverfront Dyn Dev Intl ETF) Start Date:2016-04-14
RFEM (First Trust Riverfront Dyn Em Mkts ETF) Start Date:2016-06-15
RFEU (First Trust Riverfront Dynamic Eurp ETF) Start Date:2016-04-14
RFFC (Riverfront Dynamic Us Flex-Cap ETF) Start Date:2016-06-07
RFG (Guggenheim S&P Midcap 400 Pure Gr ETF) Start Date:2006-06-22
RFIX (Simplify Bond Bull ETF) Start Date:2024-12-10
RFLR (Innovator U.S. Small Cap Managed Floor ETF) Start Date:2024-09-17
RFV (Guggenheim S&P Midcap 400 Pure Val ETF) Start Date:2006-03-07
RGEF (Tidal Trust Iii Rockefeller Global Equity ETF) Start Date:2024-10-28
RGI (Invesco S&P 500Â® Equal Weight Industrials ETF) Start Date:2006-11-07
RHRX (Rh Tactical Rotation ETF) Start Date:2021-11-08
RHS (Invesco S&P 500Â® Equal Weight Consumer Staples ETF) Start Date:2007-01-04
RHTX (Rh Tactical Outlook ETF) Start Date:2021-11-08
RIET (Hoya Capital High Dividend Yield ETF) Start Date:2021-09-22
RIGS (Riverfront Strategic Income ETF) Start Date:2013-10-09
RILA (Spinnaker ETF Series Indexperts Gorilla Aggressive Growth ETF) Start Date:2025-01-02
RINC (Investment Managers Series Trust Ii Axs Real Estate Income ETF) Start Date:2023-08-28
RINF (ProShares Inflation Expectations) Start Date:2012-01-12
RING (iShares MSCI Global Gold Miners ETF) Start Date:2012-02-02
RIOX (Tidal Trust Ii Defiance Daily Target 2X Long Riot ETF) Start Date:2025-01-03
RISN (Inspire Tactical Balanced ESG ETF) Start Date:2020-07-16
RISR (Foliobeyond Rising Rates ETF) Start Date:2021-10-01
RITA (ETF Series Solutions ETFb Green Sri Reits ETF) Start Date:2021-12-09
RJMG (First Trust Exchange-Traded Fund Viii FTRaymond James Multica) Start Date:2024-01-18
RLY (SPDR Ssga Multi-Asset Real Return ETF) Start Date:2012-04-26
RMCA (Tidal Trust Iii Rockefeller California Municipal Bond ETF) Start Date:2024-08-13
RMIF (ETF Series Solutions Lha Risk-Managed Income ETF) Start Date:2023-06-09
RMNY (Tidal Trust Iii Rockefeller New York Municipal Bond ETF) Start Date:2025-02-28
RMOP (Tidal Trust Iii Rockefeller Opportunistic Municipal Bond ETF) Start Date:2024-08-14
RND (First Trust Exchange-Traded Fund Vi First Trust Bloomberg R&D) Start Date:2024-05-06
RNDM (First Trust Developed International Equity Select ETF) Start Date:2017-06-23
RNDV (First Trust Us Equity Dividend Select ETF) Start Date:2017-06-22
RNEM (First Trust Emerging Markets Equity Select ETF) Start Date:2017-06-23
RNEW (Vaneck Green Infrastructure ETF) Start Date:2022-10-20
RNLC (First Trust Large Cap Us Equity Select ETF) Start Date:2017-06-22
RNMC (First Trust Mid Cap Us Equity Select ETF) Start Date:2017-06-22
RNRG (Global X Renewable Energy Producers ETF) Start Date:2021-02-01
RNSC (First Trust Small Cap Us Equity Select ETF) Start Date:2017-06-22
RNWZ (Listed Funds Trust Trueshares Eagle Global Renewable Energy In) Start Date:2022-12-09
ROAM (Hartford Multifactor Emerging Mkts ETF) Start Date:2015-02-26
ROBO (Robo Global Robotics And Automation Index ETF) Start Date:2013-10-22
ROBT (First Trust Nasdaq Artificial Intelligence And Robotics ETF) Start Date:2018-02-22
RODE (Lattice Strategies Trust) Start Date:2019-11-06
RODM (Hartford Multifactor Dev Mkts) Start Date:2015-02-26
ROE (Astoria Us Quality Kings ETF) Start Date:2023-08-01
ROIS (Lattice Strategies Trust Hartford Multifactor International Sm) Start Date:2024-03-19
ROKT (SPDR S&P Kensho Final Frontiers ETF) Start Date:2018-10-23
ROM (ProShares Ultra Technology) Start Date:2007-02-01
ROMO (Strategy Shares Newfound/Resolve Robust Momentum ETF) Start Date:2019-11-04
ROOF (IQ Us Real Estate Small Cap ETF) Start Date:2011-06-14
ROPE (Ea Series Trust Coastal Compass 100 ETF) Start Date:2024-12-18
RORO (Atac Us Rotation ETF) Start Date:2020-11-18
ROSC (Hartford Multifactor Small Cap ETF) Start Date:2015-03-24
ROUS (Hartford Multifactor Us Equity ETF) Start Date:2015-02-26
RPAR (Rpar Risk Parity ETF) Start Date:2019-12-13
RPG (Invesco S&P 500Â® Pure Growth ETF) Start Date:2006-03-07
RPHS (Two Roads Shared Trust Regents Park Hedged Market Strategy ETF) Start Date:2022-03-31
RPV (Invesco S&P 500Â® Pure Value ETF) Start Date:2006-03-07
RRH (Advocate Rising Rate Hedge ETF) Start Date:2021-10-28
RSBA (Tidal Trust Ii Return Stacked Bonds & Merger Arbitrage ETF) Start Date:2024-12-18
RSBT (Return Stacked Bonds & Managed Futures ETF Return Stacked Bond) Start Date:2023-02-08
RSBY (Tidal Trust Ii Return Stacked Bonds & Futures Yield ETF) Start Date:2024-08-21
RSDE (First Trust Exchange-Traded Fund Viii FTVest U.S. Equity Equal) Start Date:2024-12-23
RSHO (Tema ETF Trust Tema American Reshoring ETF) Start Date:2023-05-11
RSJN (First Trust Exchange-Traded Fund Viii FTVest U.S. Equity Equal) Start Date:2024-06-24
RSMC (Tidal Trust Iii Rockefeller U.S. Small-Mid Cap ETF) Start Date:2024-10-11
RSMV (Listed Funds Trust Relative Strength Managed Volatility Strategy) Start Date:2025-01-14
RSP (Rydex S&P Equal Weight ETF) Start Date:2003-05-01
RSPA (Invesco Actively Managed Exchange-Traded Fund Trus Invesco S&P) Start Date:2024-07-17
RSPC (Invesco S&P 500 Equal Weight Communication Services ETF) Start Date:2018-11-07
RSPD (Invesco S&P 500 Equal Weight Consumer Discretionary ETF) Start Date:2007-05-16
RSPE (Invesco ESG S&P 500 Equal Weight ETF) Start Date:2021-11-17
RSPF (Invesco S&P 500 Equal Weight Financial ETF) Start Date:2007-05-16
RSPG (Invesco S&P 500 Equal Weight Energy ETF) Start Date:2007-05-16
RSPH (Invesco S&P 500 Equal Weight Health Care ETF) Start Date:2007-05-16
RSPM (Invesco S&P 500 Equal Weight Materials ETF) Start Date:2007-05-16
RSPN (Invesco S&P 500 Equal Weight Industrials Portfolio) Start Date:2007-05-16
RSPR (Invesco S&P 500 Equal Weight Real Estate ETF) Start Date:2015-08-14
RSPS (Invesco S&P 500 Equal Weight Consumer Staples ETF) Start Date:2007-05-16
RSPT (Invesco S&P 500 Equal Weight Technology ETF) Start Date:2007-05-16
RSPU (Invesco S&P 500 Equal Weight Utilities ETF) Start Date:2007-05-16
RSPY (Revere Sector Opportunity ETF) Start Date:2021-08-24
RSSB (Tidal Trust Ii Return Stacked Global Stocks & Bonds ETF) Start Date:2023-12-05
RSSE (First Trust Exchange-Traded Fund Viii FTVest U.S. Equity Equa) Start Date:2024-09-23
RSSL (Global X Funds Global X Russell 2000 ETF) Start Date:2024-06-05
RSST (Tidal Trust Ii Return Stacked Us Stocks & Managed Futures Et) Start Date:2023-09-06
RSSY (Tidal Trust Ii Return Stacked U.S. Stocks & Futures Yield ETF) Start Date:2024-05-29
RTAI (Rareview Tax Advantaged Income ETF) Start Date:2020-11-02
RTH (Vaneck Vectors Retail ETF) Start Date:2011-12-22
RTL (iShares FTSE Nareit Retail Inde) Start Date:2018-07-19
RTM (Invesco S&P 500Â® Equal Weight Materials ETF) Start Date:2006-11-07
RTRE (Collaborative Investment Series Trust Rareview Total Return) Start Date:2024-06-03
RUFF (Alpha Dog ETF) Start Date:2021-10-15
RULE (Adaptive Core ETF) Start Date:2021-11-03
RUNN (Running Oak Efficient Growth ETF) Start Date:2023-06-08
RVER (Advisor Managed Portfolios Trenchless Fund ETF) Start Date:2024-04-03
RVNU (Deutsche X-Trackers Muni Infras Revn Bd) Start Date:2013-06-04
RVRB (Advisors Series Trust Reverb ETF) Start Date:2022-11-04
RWJ (Invesco S&P Smallcap 600 Revenue ETF) Start Date:2008-02-22
RWK (Oppenheimer Mid Cap Revenue ETF) Start Date:2008-02-22
RWL (Invesco S&P 500 Revenue ETF) Start Date:2008-02-22
RWM (ProShares Short Russell2000) Start Date:2007-01-25
RWO (SPDR Dj Wilshire Global Real Estate ETF) Start Date:2008-05-14
RWR (SPDR Dj Wilshire Reit ETF) Start Date:2001-08-29
RWX (SPDR Dj Wilshire Intl Real Esta) Start Date:2006-12-19
RXD (ProShares Ultrashort Health Car) Start Date:2007-02-01
RXI (iShares Global Consumer Discretionary ETF) Start Date:2006-09-21
RXL (ProShares Ultra Health Care) Start Date:2007-02-01
RYE (Guggenheim S&P 500 Equal Wt Energy ETF) Start Date:2006-11-07
RYF (Invesco S&P 500Â® Equal Weight Financials ETF) Start Date:2006-11-07
RYH (Invesco S&P 500Â® Equal Weight Health Care ETF) Start Date:2006-11-07
RYJ (Guggenheim Raymond James Sb-1 Equity ETF) Start Date:2006-05-19
RYLD (Global X Russell 2000 Covered Call ETF) Start Date:2019-04-22
RYLG (Global X Funds Global X Russell 2000 Covered Call & Growth ETF) Start Date:2022-10-05
RYSE (ETF Series Solutions Cboe Vest 10 Year Interest Rate Hedge ETF) Start Date:2023-02-06
RYT (Invesco S&P 500Â® Equal Weight Technology ETF) Start Date:2006-11-07
RYU (Guggenheim S&P 500 Eq Wt Utilities ETF) Start Date:2006-11-07
RZG (Invesco S&P Smallcap 600Â® Pure Growth ETF) Start Date:2006-03-07
RZV (Invesco S&P Smallcap 600Â® Pure Value ETF) Start Date:2006-03-07
SAA (ProShares Ultra Smallcap600) Start Date:2007-01-25
SAEF (Schwab Strategic Trust Schwab Ariel ESG ETF) Start Date:2021-11-16
SAGP (The Advisors' Inner Circle Fund Iii Strategas Global Policy Op) Start Date:2022-01-25
SAMM (The Advisors' Inner Circle Fund Iii Strategas Macro Momentum E) Start Date:2024-04-04
SAMT (The Advisors' Inner Circle Fund Iii Strategas Macro Thematic O) Start Date:2022-01-25
SARK (Tuttle Capital Short Innovation ETF) Start Date:2021-11-09
SATO (Invesco Alerian Galaxy Crypto Economy ETF) Start Date:2021-10-07
SAUG (FTCboe Vest Us Small Cap Moderate Buffer ETF - August) Start Date:2023-08-21
SAVN (Lifegoal Conservative Wealth Builder ETF) Start Date:2021-09-09
SAWG (ETF Series Solutions Aam Sawgrass Us Large Cap Quality Growth) Start Date:2024-07-31
SAWS (ETF Series Solutions Aam Sawgrass Us Small Cap Quality Growth) Start Date:2024-07-31
SBB (ProShares Short Smallcap600) Start Date:2007-01-25
SBIO (Alps Medical Breakthroughs ETF) Start Date:2014-12-31
SBIT (ProShares Trust ProShares Ultrashort Bitcoin ETF) Start Date:2024-04-02
SBND (PowerShares DB 3X Short 25 Year) Start Date:2021-09-21
SCAP (Series Portfolios Trust Infracap Small Cap Income ETF) Start Date:2023-12-12
SCC (ProShares Ultrashort Consumer Services) Start Date:2007-02-05
SCCR (Schwab Strategic Trust Schwab Core Bond ETF) Start Date:2025-02-05
SCDL (Etracs 2X Leveraged Us Dividend Factor Tr ETN) Start Date:2021-02-05
SCDS (JP Morgan Fundamental Data Science Small Core ETF) Start Date:2024-08-13
SCDV (ETF Series Solutions Bahl & Gaynor Small Cap Dividend ETF) Start Date:2024-12-12
SCHA (Schwab U.S. Small-Cap ETF) Start Date:2009-11-03
SCHB (Schw Us Brd Mkt ETF) Start Date:2009-11-03
SCHC (Schwab International Small-Cap Equity ETF) Start Date:2010-01-14
SCHD (Schwab Us Dividend Equity) Start Date:2011-10-20
SCHE (Schwab Emerging Markets Equity ETF) Start Date:2010-01-14
SCHF (Schwab International Equity) Start Date:2009-11-03
SCHG (Schwab U.S. Large-Cap Growth ETF) Start Date:2009-12-11
SCHH (Schwab Us Reit ETF) Start Date:2011-01-13
SCHI (Schwab 5-10 Year Corporate Bond ETF) Start Date:2019-10-10
SCHJ (Schwab 1-5 Year Corporate Bond ETF) Start Date:2019-10-10
SCHK (Schwab 1000 Index ETF) Start Date:2017-10-11
SCHM (Schwab Us Mid-Cap ETF) Start Date:2011-01-13
SCHO (Schwab Short-Term U.S. Treasury ETF) Start Date:2010-08-05
SCHP (Schwab U.S. Tips ETF) Start Date:2010-08-05
SCHQ (Schwab Long-Term U.S. Treasury ETF) Start Date:2019-10-10
SCHR (Schwab Intermediate-Term U.S. Treasury ETF) Start Date:2010-08-05
SCHV (Schwab U.S. Large-Cap Value ETF) Start Date:2009-12-11
SCHY (Schwab International Dividend Equity ETF) Start Date:2021-04-29
SCHZ (Schwab U.S. Aggregate Bond ETF) Start Date:2011-07-14
SCIO (First Trust Exchange-Traded Fund Iv First Trust Structured Cre) Start Date:2024-02-29
SCJ (iShares MSCI Japan Small-Cap) Start Date:2007-12-21
SCLZ (Northern Lights Fund Trust Iii Swan Enhanced Dividend Income E) Start Date:2024-02-27
SCMB (Schwab Strategic Trust Schwab Municipal Bond ETF) Start Date:2022-10-12
SCO (ProShares Ultrashort Dj-Aig Cru) Start Date:2008-11-25
SCUS (Schwab Strategic Trust Schwab Ultra-Short Income ETF) Start Date:2024-08-13
SCYB (Schwab High Yield Bond ETF) Start Date:2023-07-11
SCZ (iShares MSCI Eafe Small-Cap ETF) Start Date:2007-12-12
SDCI (Uscf Summerhaven Dynamic Commodity Strategy No K-1 Fund) Start Date:2018-05-03
SDCP (Virtus ETF Trust Ii Virtus Newfleet Short Duration Core Plus B) Start Date:2023-11-16
SDD (ProShares Ultrashort Smallcap600) Start Date:2007-01-25
SDEF (Sound Enhanced Fixed Income ETF) Start Date:2020-12-31
SDEI (Sound Equity Income ETF) Start Date:2020-12-31
SDEM (Global X MSCI Superdividend Em Mkts ETF) Start Date:2015-03-17
SDFI (Ab Active ETFs Ab Short Duration Income ETF) Start Date:2024-06-10
SDG (iShares MSCI Global Impact ETF) Start Date:2016-04-22
SDGA (Impact Shares Sustainable Development Goals Global Equity ETF) Start Date:2018-09-24
SDIV (Global X Superdividend ETF) Start Date:2011-06-09
SDOG (Alps Sector Dividend Dogs ETF) Start Date:2012-06-29
SDOW (Ultrapro Short Dow30) Start Date:2010-02-11
SDP (ProShares Ultrashort Utilities) Start Date:2007-03-15
SDS (ProShares Ultrashort S&P500) Start Date:2007-05-07
SDSI (American Century Short Duration Strategic Income ETF) Start Date:2022-10-13
SDTY (Yieldmax S&P 500 0Dte Covered Call Strategy ETF) Start Date:2025-02-06
SDVD (FTCboe Vest Smid Rising Dividend Achievers Target Income ETF) Start Date:2023-08-10
SDVY (First Trust Smid Cap Rising Dividend Achievers ETF) Start Date:2017-11-03
SDY (SPDR S&P Dividend ETF) Start Date:2005-11-15
SEA (Guggenheim Shipping ETF) Start Date:2022-01-20
SECR (Nyli Mackay Securitized Income ETF) Start Date:2024-06-07
SECT (Northern Lights Fund Trust Iv) Start Date:2017-09-06
SEEM (Sei Select Emerging Markets Equity ETF) Start Date:2024-10-10
SEF (ProShares Short Financials) Start Date:2008-06-12
SEIE (Sei Select International Equity ETF) Start Date:2024-10-10
SEIM (Sei Exchange Traded Fds Sei Enhanced Us Large Cap Momentum F) Start Date:2022-05-18
SEIQ (Sei Exchange Traded Fds Sei Enhanced Us Large Cap Quality Fa) Start Date:2022-05-19
SEIS (Sei Select Small Cap ETF) Start Date:2024-10-10
SEIV (Sei Exchange Traded Fds Sei Enhanced Us Large Cap Value Fact) Start Date:2022-05-18
SEIX (Virtus Seix Senior Loan ETF) Start Date:2019-04-25
SELV (Sei Exchange Traded Fds Sei Enhanced Low Volatility Us Large) Start Date:2022-05-18
SEMI (Columbia ETF Trust I Columbia Seligman Semiconductor And Techn) Start Date:2014-05-22
SENT (AdvisorShares Alpha Dna Equity Sentiment ETF) Start Date:2021-02-03
SEPP (Shl Telemedicine Pgim Us Large-Cap Buffer 12 ETF - Septemb) Start Date:2024-06-11
SEPT (Allianzim Us Large Cap Buffer10 Sep ETF) Start Date:2023-09-01
SEPW (Allianzim Us Large Cap Buffer20 Sep ETF) Start Date:2023-09-01
SEPZ (Listed Funds Trust Trueshares Structured Outcome) Start Date:2020-09-01
SETH (ProShares Trust ProShares Short Ether Strategy ETF) Start Date:2023-11-02
SETM (Sprott Energy Transition Materials ETF) Start Date:2023-02-02
SFEB (First Trust Exchange-Traded Fund Viii FTVest Us Small Cap M) Start Date:2024-02-20
SFIG (WisdomTree Us Short-Term Corporate Bond Fund) Start Date:2016-04-27
SFLO (Victoryshares Small Cap Free Cash Flow ETF) Start Date:2023-12-21
SFLR (Innovator ETFs Trust Innovator Equity Managed Floor ETF) Start Date:2022-11-09
SFY (Sofi Select 500 ETF) Start Date:2019-04-11
SFYF (Sofi 50 ETF) Start Date:2019-05-08
SFYX (Sofi Next 500 ETF) Start Date:2019-04-11
SGDJ (Alps Sprott Junior Gold Miners ETF) Start Date:2015-03-31
SGDM (Sprott Gold Miners ETF) Start Date:2014-07-15
SGG (iPath Bloomberg Sugar Subtr ETN) Start Date:2018-01-25
SGLC (Sgi Us Large Cap Core ETF) Start Date:2023-03-31
SGOL (Aberdeen Standard Physical Gold Shares ETF) Start Date:2009-09-09
SGOV (iShares 0-3 Month Treasury Bond ETF) Start Date:2020-05-28
SH (ProShares Short S&P500) Start Date:2006-06-21
SHAG (WisdomTree Yield Enhanced Us Sh-Tr Aggregate Bond) Start Date:2017-05-18
SHDG (Soundwatch Hedged Equity ETF) Start Date:2022-10-25
SHE (SPDR Ssga Gender Diversity ETF) Start Date:2016-03-08
SHLD (Global X Defense Tech ETF) Start Date:2023-09-14
SHM (SPDR Lehman Short Term Municipa) Start Date:2007-10-16
SHNY (Direxion Daily Silver Mnrs Bull 2X ETF) Start Date:2023-02-22
SHOC (Ea Series Trust Strive Us Semiconductor ETF) Start Date:2022-10-06
SHPP (Pacer Funds Pacer Industrials And Logistics ETF) Start Date:2022-06-10
SHRT (Tidal ETF Trust Gotham Short Strategies ETF) Start Date:2023-11-06
SHRY (First Trust Bloomberg Shareholder Yield ETF) Start Date:2017-06-22
SHUS (Syntax Stratified U.S. Total Market Hedged ETF) Start Date:2021-06-16
SHV (iShares Lehman Short Treasury B) Start Date:2007-01-11
SHY (iShares 1-3 Year Treasury Bond) Start Date:2002-07-30
SHYD (Vaneck Vectors Short High-Yield Muni ETF) Start Date:2014-01-14
SHYG (iShares 0-5 Year High Yield Corporate Bond ETF) Start Date:2013-10-17
SHYL (Xtrackers Short Duration High Yield Bond ETF) Start Date:2018-01-10
SHYM (iShares High Yield Muni Income Active ETF) Start Date:2025-02-10
SIFI (Harbor Scientific Alpha Income ETF) Start Date:2021-09-16
SIHY (Harbor Scientific Alpha High-Yield ETF) Start Date:2021-09-16
SIJ (ProShares Ultrashort Industrial) Start Date:2007-02-01
SIL (Global X Silver Miners ETF) Start Date:2010-04-20
SILJ (ETFmg Prime Junior Silver ETF) Start Date:2012-11-29
SILX (ETFmg Prime 2X Daily Junior Silver Miners ETF) Start Date:2021-06-16
SIMS (SPDR S&P Kensho Intelligent Structures ETF) Start Date:2017-12-27
SIO (Touchstone ETF Trust Touchstone Strategic Income Opportunities) Start Date:2022-07-25
SIVR (Aberdeen Standard Physical Silver Shares ETF) Start Date:2009-07-24
SIXA (6 Meridian Mega Cap Equity ETF) Start Date:2020-05-11
SIXD (Shl Telemedicine Allianzim Us Large Cap 6 Month Buffer10) Start Date:2010-12-15
SIXF (Aim ETF Products Trust Allianzim Us Large Cap 6 Month Buffer) Start Date:2024-02-01
SIXG (Defiance Connective Technologies ETF) Start Date:2019-03-05
SIXH (Etc 6 Meridian Hedged Equity Index Option ETF) Start Date:2020-05-11
SIXJ (Aim ETF Products Trust Allianzim Us Large Cap 6 Month Buffer) Start Date:2022-01-03
SIXL (Etc 6 Meridian Low Beta Equity ETF) Start Date:2020-05-11
SIXO (Allianzim U.S. Large Cap 6 Month Buffer10 Apr/Oct ETF) Start Date:2021-10-01
SIXP (Aim ETF Products Trust Allianzim Us Large Cap 6 Month Buffer) Start Date:2024-03-01
SIXS (Etc 6 Meridian Small Cap Equity ETF) Start Date:2020-05-11
SIXZ (Shl Telemedicine Allianzim Us Large Cap 6 Month Buffer10) Start Date:2024-05-01
SIZE (iShares Edge MSCI Usa Size Factor) Start Date:2013-04-18
SJB (ProShares Short High Yield) Start Date:2011-03-22
SJCP (Sanjac Alpha Core Plus Bond ETF) Start Date:2024-09-10
SJLD (Sanjac Alpha Low Duration ETF) Start Date:2024-09-10
SJNK (SPDR Bloomberg Barclays Short Term High Yield Bond) Start Date:2012-03-15
SKF (ProShares Ultrashort Financials) Start Date:2007-02-01
SKOR (Flexshares Credit-Scored Us Bd ETF) Start Date:2014-11-13
SKRE (Tuttle Capital Daily 2X Inverse Regional Banks ETF) Start Date:2024-01-04
SKYU (ProShares Ultra Nasdaq Cloud Computing ETF) Start Date:2021-01-21
SKYY (First Trust Ise Cloud Computing Index Fund) Start Date:2011-07-06
SLDR (Global X Short-Term Treasury Ladder ETF) Start Date:2024-09-10
SLQD (iShares 0-5 Year Investment Grade Corporate Bond ETF) Start Date:2013-10-17
SLV (iShares Silver Trust) Start Date:2006-04-28
SLVO (Credit Suisse X-Links Silver Covcall ETN) Start Date:2013-04-17
SLVP (iShares MSCI Global Silver Miners ETF) Start Date:2012-02-02
SLVR (Sprott Silver Miners & Physical Silver ETF) Start Date:2021-11-01
SLX (Vaneck Vectors Steel ETF) Start Date:2006-10-17
SLY (SPDR S&P 600 Small Cap ETF) Start Date:2007-05-16
SLYG (SPDR S&P 600 Small Cap Growth ETF) Start Date:2007-05-16
SLYV (SPDR S&P 600 Small Cap Value ETF) Start Date:2007-05-16
SMAP (Amplify ETF Trust Amplify Small-Mid Cap Equity ETF) Start Date:2024-10-24
SMAY (FTCboe Vest Us Small Cap Moderate Buffer ETF - May) Start Date:2023-05-22
SMB (Vaneck Vectors Amt-Free Short Municipal Index ETF) Start Date:2008-02-27
SMBS (Schwab Strategic Trust Schwab Mortgage-Backed Securities ETF) Start Date:2024-11-19
SMCF (Themes Us Small Cap Cash Flow Champions ETF) Start Date:2023-12-13
SMCL (Graniteshares 2X Long Smci Daily ETF) Start Date:2024-12-12
SMCO (Hilton Small-Midcap Opportunity ETF) Start Date:2023-11-29
SMCP (Alphamark Actively Managed Small Cap ETF) Start Date:2015-04-21
SMCX (Defiance Daily Target 2X Long Smci ETF) Start Date:2024-08-22
SMCY (Tidal Trust Ii Yieldmax Smci Option Income Strategy ETF) Start Date:2024-09-12
SMDD (ProShares Ultrapro Short Midcap400) Start Date:2010-02-11
SMDV (ProShares Russell 2000 Dividend Growers ETF) Start Date:2015-02-05
SMDX (Tidal Trust Iii Intech S&P Small-Mid Cap Diversified Alpha ETF) Start Date:2025-02-28
SMDY (Syntax Stratified Midcap ETF) Start Date:2020-01-17
SMH (Market Vectors Semiconductor ETF) Start Date:2000-06-05
SMHB (Etracs 2Xmonthly Pay Leveraged Us Small Cap High Dividend ETN Series B) Start Date:2018-11-09
SMHX (Vaneck Fabless Semiconductor ETF) Start Date:2024-08-28
SMI (Vaneck Hip Sustainable Muni ETF) Start Date:2021-09-10
SMIG (ETF Series Solutions Aam Bahl & Gaynor Small/Mid Cap Income Gr) Start Date:2021-08-26
SMIN (iShares MSCI India Small-Cap) Start Date:2012-02-09
SMIZ (Zacks Small/Mid Cap ETF) Start Date:2023-10-03
SMLE (Xtrackers S&P Smallcap 600 ESG ETF) Start Date:2021-02-24
SMLF (iShares Edge MSCI Multifactor Usa Small-Cap ETF) Start Date:2015-04-30
SMLL (Direxion Daily Small Cap Bull 2X ETF) Start Date:2024-08-29
SMLV (SPDR Ssga Us Small Cap Low Volatility Index ETF) Start Date:2013-02-21
SMMD (iShares Russell 2500 ETF) Start Date:2017-07-07
SMMU (Pimco Short Term Municipal Bond Fund) Start Date:2010-02-03
SMMV (iShares Edge MSCI Min Vol Usa Small-Cap ETF) Start Date:2016-09-09
SMN (ProShares Ultra Short Basic Materials) Start Date:2007-02-02
SMOG (Vaneck Vectors Low Carbon Energy ETF) Start Date:2007-05-16
SMOT (Vaneck Morningstar Smid Moat ETF) Start Date:2022-10-06
SMRI (Bushido Capital Us Equity ETF) Start Date:2023-09-14
SMST (Defiance Daily Target 1.5X Short Mstr ETF) Start Date:2024-08-21
SMTH (Alps ETF Trust Alps) Start Date:2023-12-06
SNAV (Mohr Sector Nav ETF) Start Date:2023-03-15
SNLN (Highland/Iboxx Senior Loan ETF) Start Date:2012-11-08
SNOV (FTVest Us Small Cap Moderate Buffer ETF - November) Start Date:2023-11-20
SNOY (Tidal Trust Ii Yieldmax Snow Option Income Strategy ETF) Start Date:2024-06-11
SNPD (Xtrackers S&P ESG Dividend Aristocrats ETF) Start Date:2023-01-05
SNPE (Xtrackers S&P 500 ESG ETF) Start Date:2019-06-26
SNPG (Xtrackers S&P 500 Growth ESG ETF) Start Date:2022-11-17
SNPV (Xtrackers S&P 500 Value ESG ETF) Start Date:2023-03-31
SNSR (Global X Funds Global X Internet Of Things ETF) Start Date:2016-09-16
SOCL (Global X Social Media ETF) Start Date:2011-11-15
SOFR (Amplify ETF Trust Amplify Samsung Sofr ETF) Start Date:2023-11-15
SOFX (Defiance Daily Target 2X Long Sofi ETF) Start Date:2025-01-16
SOGU (The Short De-SPAC ETF) Start Date:2021-05-19
SOLR (Smartetfs Sustainable Energy Ii ETF) Start Date:2022-01-03
SOVF (Sovereigns Capital Flourish Fund) Start Date:2023-10-03
SOXL (Direxion Daily Semiconductor Bull 3X Shares) Start Date:2010-03-11
SOXQ (Invesco Phlx Semiconductor ETF) Start Date:2021-06-11
SOXS (Direxion Daily Semiconductor Bear 3X Shares) Start Date:2010-03-11
SOXX (iShares Phlx Semiconductor ETF) Start Date:2007-04-27
SOXY (Tidal Trust Ii Yieldmax Target 12 Semiconductor Option Income) Start Date:2024-12-03
SOYB (Teucrium Soybean Fund Etv) Start Date:2011-09-19
SPAB (SPDR Portfolio Aggregate Bond ETF) Start Date:2007-05-30
SPAM (Themes Cybersecurity ETF) Start Date:2023-12-08
SPAQ (Horizon Kinetics SPAC Active ETF) Start Date:2023-01-30
SPAX (Robinson Alternative Yield Pre-Merger SPAC ETF) Start Date:2021-06-23
SPBC (Simplify U.S. Equity Plus Gbtc ETF) Start Date:2021-05-25
SPBO (SPDR Portfolio Corporate Bond ETF) Start Date:2011-04-07
SPBW (Aim ETF Products Trust Allianzim Buffer20 Allocation ETF) Start Date:2025-01-08
SPBX (Aim ETF Products Trust Allianzim 6 Month Buffer10 Allocation E) Start Date:2025-01-08
SPCX (The SPAC And New Issue ETF) Start Date:2020-12-16
SPCY (Stkd 100% Smci & 100% Nvda ETF) Start Date:2025-03-06
SPCZ (Rivernorth Enhanced Pre-Merger SPAC ETF) Start Date:2022-07-12
SPD (Simplify Exchange Traded Funds Simplify Us Equity Plus Downsid) Start Date:2020-09-04
SPDG (SPDR Portfolio S&P Sector Neutral Dividend ETF) Start Date:2023-09-12
SPDV (Aam S&P 500 High Dividend Value ETF) Start Date:2017-11-29
SPDW (SPDR Portfolio World Ex-Us ETF) Start Date:2007-05-16
SPEM (SPDR Portfolio Emerging Markets ETF) Start Date:2007-05-16
SPEU (SPDR Portfolio Europe ETF) Start Date:2007-05-16
SPFF (Global X Superincome Preferred ETF) Start Date:2012-07-17
SPGM (SPDR Portfolio MSCI Global Stock Market ETF) Start Date:2012-02-28
SPGP (Invesco S&P 500 Garp ETF) Start Date:2011-06-16
SPHB (Invesco S&P 500 High Beta ETF) Start Date:2011-05-05
SPHD (Invesco S&P 500Â® High Dividend Low Volatility ETF) Start Date:2012-10-18
SPHQ (Invesco S&P 500Â® Quality ETF) Start Date:2007-05-08
SPHY (SPDR Portfolio High Yield Bond ETF) Start Date:2012-06-19
SPIB (SPDR Portfolio Intermediate Term Corporate Bond ETF) Start Date:2009-02-11
SPIP (SPDR Portfolio Tips ETF) Start Date:2007-05-30
SPLB (SPDR Portfolio Long Term Corporate Bond ETF) Start Date:2009-03-12
SPLG (SPDR Portfolio S&P 500) Start Date:2010-01-01
SPLV (PowerShares S&P 500 Low Volatil) Start Date:2011-05-05
SPMB (SPDR Portfolio Mortgage Backed Bond ETF) Start Date:2009-01-27
SPMD (SPDR Portfolio S&P 400 Mid Cap ETF) Start Date:2007-05-16
SPMO (PowerShares S&P 500 Momentum) Start Date:2015-10-12
SPMV (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-07-13
SPPP (Sprott Physical Platinum And Palladium Trust) Start Date:2012-12-19
SPQ (Simplify Exchange Traded Funds Simplify Us Equity Plus Qis ETF) Start Date:2023-11-14
SPRE (Sp Funds S&P Global Reit Sharia ETF) Start Date:2020-12-30
SPRX (Spear Alpha ETF) Start Date:2021-08-04
SPSB (SPDR Portfolio Short Term Corporate Bond ETF) Start Date:2009-12-17
SPSK (Tidal ETF Trust Sp Funds Dow Jones Global Sukuk ETF) Start Date:2019-12-30
SPSM (SPDR Portfolio S&P 600 Small Cap ETF) Start Date:2013-07-09
SPTB (SPDR Series Trust SPDR Portfolio Treasury ETF) Start Date:2024-05-21
SPTE (Sp Funds Trust Sp Funds S&P Global Technology ETF) Start Date:2023-12-01
SPTI (SPDR Portfolio Intermediate Term Treasury) Start Date:2007-05-30
SPTL (SPDR Portfolio Long Term Treasury ETF) Start Date:2007-05-30
SPTM (SPDR Portfolio S&P 1500 Composite Stock Market ETF) Start Date:2007-05-16
SPTS (SPDR Portfolio Short Term Treasury ETF) Start Date:2011-12-01
SPUC (Simplify Exchange Traded Funds Simplify Us Equity Plus Upside) Start Date:2020-09-04
SPUS (Sp Funds S&P 500 Sharia Industry Exclusions ETF) Start Date:2019-12-18
SPUT (Innovator ETFs Trust Innovator Equity Premium Income - Daily P) Start Date:2025-03-14
SPVM (Invesco S&P 500 Value With Momentum ETF) Start Date:2011-06-16
SPVU (Invesco S&P 500 Enhanced Value ETF) Start Date:2015-10-09
SPWO (Sp Funds Trust Sp Funds S&P World) Start Date:2023-12-20
SPXB (ProShares S&P 500 Bond ETF) Start Date:2018-05-03
SPXE (ProShares S&P 500 Ex-Energy) Start Date:2015-09-24
SPXL (Direxion Daily S&P 500 Bull 3X) Start Date:2008-11-05
SPXN (ProShares S&P 500 Ex-Financials) Start Date:2015-09-24
SPXS (Direxion Daily S&P 500 Bear 3X) Start Date:2008-11-05
SPXT (ProShares S&P 500 Ex-Technology ETF) Start Date:2015-09-24
SPXU (ProShares Ultrapro Short S&P500) Start Date:2009-06-25
SPXV (ProShares S&P 500 Ex-Health Care ETF) Start Date:2015-09-24
SPY (SPDR S&P 500) Start Date:2000-01-03
SPYB (SPDR S&P 500 Buyback ETF) Start Date:2024-09-03
SPYC (Simplify Exchange Traded Funds Simplify Us Equity Plus Convexi) Start Date:2020-09-04
SPYD (SPDR Portfolio S&P 500 High Dividend ETF) Start Date:2015-10-22
SPYG (SPDR Portfolio S&P 500 Growth ETF) Start Date:2007-05-16
SPYI (Neos S&P 500 High Income ETF) Start Date:2022-08-30
SPYQ (Tradr 2X Long Spy Quarterly ETF) Start Date:2024-10-01
SPYT (Tidal Trust Ii Defiance S&P 500 Target Income ETF) Start Date:2024-03-07
SPYU (Bank Of Montreal Max S&P 500 4X Leveraged ETNs Due October 30) Start Date:2023-12-05
SPYV (SPDR Portfolio S&P 500 Value ETF) Start Date:2007-05-16
SPYX (SPDR S&P 500 Fossil Fuel Rsrv Free ETF) Start Date:2015-12-01
SQEW (Leadershares Equity Skew ETF) Start Date:2020-05-12
SQLV (Legg Mason Small-Cap Quality Value ETF) Start Date:2017-07-13
SQQQ (ProShares Ultrapro Short Qqq) Start Date:2010-02-11
SQY (Tidal Trust Ii Yieldmax Sq Option Income Strategy ETF) Start Date:2023-10-11
SRET (Global X Superdividend Reit ETF) Start Date:2015-03-17
SRHQ (Elevation Series Trust Srh Us Quality ETF) Start Date:2022-10-05
SRHR (Elevation Series Trust Srh Reit Covered Call ETF) Start Date:2023-11-02
SRLN (SPDR Blackstone/Gso Senior Loan) Start Date:2013-04-04
SROI (Calamos ETF Trust Calamos Antetokounmpo Global Sustainable Equ) Start Date:2023-02-06
SRS (ProShares Ultrashort Real Estate) Start Date:2007-02-01
SRTY (Proshareultrapro Short Russell 2000) Start Date:2010-02-11
SRVR (Pacer Benchmark Data & Infrastructure Real Estate Sctr ETF) Start Date:2018-05-16
SSFI (Day Hagan/Ned Davis Research Smart Sector Fixed Income ETF) Start Date:2021-09-29
SSG (ProShares Ultrashort Semiconductors) Start Date:2007-02-05
SSLY (Syntax Stratified Smallcap ETF) Start Date:2020-05-29
SSO (ProShares Ultra S&P500) Start Date:2006-06-21
SSPX (Janus Henderson U.S. Sustainable Equity ETF) Start Date:2021-09-09
SSPY (Syntax Stratified Largecap ETF) Start Date:2019-01-04
SSUS (Day Hagan/Ned Davis Research Smart Sector ETF) Start Date:2020-01-17
SSXU (Strategy Shares Day Hagan/Ned Davis Research Smart Sector Inte) Start Date:2022-07-01
STAX (Macquarie ETF Trust Macquarie Tax-Free Usa Short Term ETF) Start Date:2024-03-05
STBF (Trust For Professional Managers Performance Trust Short Term B) Start Date:2024-04-09
STCE (Schwab Strategic Trust Schwab Crypto Thematic ETF) Start Date:2022-08-04
STIP (iShares 0-5 Year Tips Bond ETF) Start Date:2010-12-03
STLG (iShares Global 100 ETF) Start Date:2020-01-16
STLV (iShares Global 100 ETF) Start Date:2020-01-16
STNC (Stance Equity ESG Large Cap Core ETF) Start Date:2021-03-16
STOT (Ssga Active Trust) Start Date:2016-04-14
STPZ (Pimco 1-5 Year U.S. Tips Index Exchange-Traded Fund) Start Date:2009-08-21
STRV (Ea Series Trust Strive 500 ETF) Start Date:2022-09-15
STXD (Strive 1000 Dividend Growth ETF) Start Date:2022-11-10
STXE (Ea Series Trust Strive Emerging Markets Ex-China ETF) Start Date:2023-01-31
STXG (Strive 1000 Growth ETF) Start Date:2022-11-10
STXI (Ea Series Trust Strive International Developed Markets ETF) Start Date:2024-06-26
STXK (Strive Small-Cap ETF) Start Date:2022-11-10
STXM (Ea Series Trust Strive Mid-Cap ETF) Start Date:2024-04-11
STXT (Ea Series Trust Strive Total Return Bond ETF) Start Date:2023-08-10
STXV (Strive 1000 Value ETF) Start Date:2022-11-10
SUB (iShares S&P Short Term National Amt-Free Bond ETF) Start Date:2008-11-07
SUBS (Fount Subscription Economy ETF) Start Date:2021-10-28
SUPL (ProShares Trust ProShares Supply Chain Logistics ETF) Start Date:2022-04-07
SUPP (TCWTransform Supply Chain ETF) Start Date:2023-02-15
SURE (AdvisorShares Insider Advantage ETF) Start Date:2011-10-05
SURI (Simplify Exchange Traded Funds Simplify Propel Opportunities E) Start Date:2023-02-10
SUSA (iShares MSCI Usa ESG Select ETF) Start Date:2017-07-13
SUSB (iShares ESG 1-5 Year Usd Corporate Bond ETF) Start Date:2017-07-18
SUSC (iShares ESG Usd Corporate Bond ETF) Start Date:2017-07-20
SUSL (iShares ESG MSCI Usa Leaders ETF) Start Date:2019-05-10
SVAL (iShares Us Small Cap Value Factor ETF) Start Date:2020-11-02
SVIX (-1X Short VIX Futures ETF) Start Date:2022-03-30
SVXY (ProShares Short VIX Short Term) Start Date:2011-10-04
SWAN (Amplify Blackswan Growth & Treasury Core ETF) Start Date:2018-11-06
SWIN (Alps/Dorsey Wright Sector Momentum ETF) Start Date:2023-09-07
SWP (Swp Growth & Income ETF) Start Date:2024-09-25
SXQG (Etc 6 Meridian Quality Growth ETF) Start Date:2021-05-11
SXUS (Janus Henderson International Sustainable Equity ETF) Start Date:2021-09-09
SYFI (Ab Active ETFs Ab Short Duration High Yield ETF) Start Date:2024-06-10
SYLD (Cambria Shareholder Yield ETF) Start Date:2013-05-14
SYNB (Putnam ETF Trust Putnam Biorevolution ETF) Start Date:2022-09-30
SYUS (Syntax Stratified U.S. Total Market ETF) Start Date:2021-03-19
SZK (ProShares Ultra Short Consumer Goods) Start Date:2007-02-05
SZNE (Pacer Cfra-Stovall Equal Weight Seasonal Rotation ETF) Start Date:2018-07-24
TACK (Capitol Series Trust Fairlead Tactical Sector ETF) Start Date:2022-03-23
TAFI (Ab Active ETFs Ab Tax-Aware Short Duration Municipal ETF) Start Date:2022-09-14
TAFL (Ab Active ETFs Ab Tax-Aware Long Municipal ETF) Start Date:2023-12-13
TAFM (Ab Active ETFs Ab Tax-Aware Intermediate Municipal ETF) Start Date:2023-12-21
TAGG (T. Rowe Price Qm U.S. Bond ETF) Start Date:2021-09-29
TAGS (Teucrium Agricultural Fund Etv) Start Date:2012-03-28
TAIL (Cambria Tail Risk ETF) Start Date:2017-04-06
TAN (Invesco Solar ETF) Start Date:2008-04-15
TAPR (Barclays Inverse Us Treasury Aggt ETN) Start Date:2014-07-15
TARK (Axs 2X Innovation ETF) Start Date:2022-05-02
TAX (Cambria Tax Aware ETF) Start Date:2012-07-02
TAXE (Intermediate Municipal Income ETF) Start Date:2024-07-10
TAXF (American Century Diversified Municipal Bond ETF) Start Date:2018-09-12
TAXX (Bondbloxx ETF Trust Bondbloxx Ir+M Tax-Aware Short Duration Et) Start Date:2024-03-14
TBF (ProShares Short 20+ Year Treasu) Start Date:2009-08-20
TBFC (ETF Series Solutions The Brinsmere Fund Conservative ETF) Start Date:2024-01-16
TBFG (ETF Series Solutions The Brinsmere Fund Growth ETF) Start Date:2024-01-16
TBG (Ea Series Trust Tbg Dividend Focus ETF) Start Date:2023-11-07
TBIL (Us Treasury 3 Month Bill ETF) Start Date:2022-08-09
TBJL (Innovator 20 Year Treasury Bond 9 Buffer ETF - July) Start Date:2020-08-18
TBLL (Invesco Short Term Treasury ETF) Start Date:2017-01-12
TBLU (Tortoise Water ESG Fund) Start Date:2020-08-21
TBT (ProShares Ultrashort Lehman 20+) Start Date:2008-05-01
TBUX (T. Rowe Price Ultra Short-Term Bond ETF) Start Date:2021-09-29
TBX (ProShares Short 7-10 Year Treasury) Start Date:2011-04-05
TCAF (T Rowe Price Exchange-Traded Funds T Rowe Price Capita) Start Date:2023-06-15
TCHI (Rbs China Trendpilot ETN) Start Date:2022-02-01
TCHP (T. Rowe Price Blue Chip Growth ETF) Start Date:2020-08-05
TCPB (Thrivent ETF Trust Thrivent Core Plus Bond ETF) Start Date:2025-02-19
TDI (Touchstone Dynamic International ETF) Start Date:2023-12-11
TDIV (First Trust Nasdaq Technology Dividend Index Fund) Start Date:2012-08-14
TDSA (Cabana Target Drawdown 5 ETF) Start Date:2020-09-17
TDSB (Cabana Target Drawdown 7 ETF) Start Date:2020-09-17
TDSC (Cabana Target Drawdown 10 ETF) Start Date:2020-09-17
TDSD (Cabana Target Drawdown 13 ETF) Start Date:2020-09-17
TDSE (Cabana Target Drawdown 16 ETF) Start Date:2020-09-17
TDTF (Flexshares Iboxx 5Yr Target Dur Tips ETF) Start Date:2011-09-22
TDTT (Flexshares Iboxx 3-Year Target Duration Tips Index Fund) Start Date:2011-09-23
TDV (ProShares S&P Technology Dividend Aristocrats ETF) Start Date:2019-11-07
TDVG (T. Rowe Price Dividend Growth ETF) Start Date:2020-08-05
TDVI (First Trust Exchange-Traded Fund Iv FTCboe Vest Technology Di) Start Date:2023-08-10
TECB (iShares U.S. Tech Breakthrough Multisector ETF) Start Date:2020-01-10
TECL (Direxion Daily Technology Bull 3X Shares) Start Date:2008-12-17
TECS (Direxion Daily Technology Bear 3X Shares) Start Date:2008-12-17
TEK (Blackrock ETF Trust iShares Technology Opportunities Active ETF) Start Date:2024-10-22
TEKX (SPDR Galaxy Transformative Tech Accelerators ETF) Start Date:2024-09-10
TEMP (JP Morgan Exchange-Traded Fund Trust JP Morgan Climate Change) Start Date:2021-12-14
TEQI (T. Rowe Price Equity Income ETF) Start Date:2020-08-05
TESL (Simplify Volt Tsla Revolution ETF) Start Date:2020-12-29
TFI (SPDR Barclays Capital Municipal Bond ETF) Start Date:2007-09-13
TFJL (Innovator 20 Year Treasury Bond 5 Floor ETF - July) Start Date:2020-08-18
TFLO (iShares Treasury Floating Rate Bond ETF) Start Date:2014-02-04
TFLR (T Rowe Price Exchange-Traded Funds T Rowe Price Floati) Start Date:2022-11-17
TFPN (Return Stacked Bonds & Managed Futures ETF Blueprint Chesapeak) Start Date:2023-07-12
TGIF (Sofi Weekly Income ETF) Start Date:2020-10-02
TGLR (ETF Opportunities Trust Laffer Tengler Equity Income ETF) Start Date:2023-08-08
TGR (iShares S&P Target Date Retirem) Start Date:2022-03-28
TGRT (T Rowe Price Exchange-Traded Funds T Rowe Price Growth) Start Date:2023-06-15
TGRW (T. Rowe Price Growth Stock ETF) Start Date:2020-08-05
THCX (Cannabis ETF) Start Date:2019-07-09
THD (iShares MSCI Thailand Index Fund) Start Date:2008-03-28
THLV (Thor Financial Technologies Trust Thor Low Volatility ETF) Start Date:2022-09-13
THNQ (Robo Global Artificial Intelligence ETF) Start Date:2020-05-11
THNR (Amplify ETF Trust Amplify Weight Loss Drug & Treatment ETF) Start Date:2024-05-21
THRO (iShares U.S. Thematic Rotation Active ETF) Start Date:2021-12-16
THTA (Tidal ETF Trust Sofi Enhanced Yield ETF) Start Date:2023-11-15
THY (Toews Agility Shares Dynamic Tactical Income ETF) Start Date:2020-06-25
THYF (T Rowe Price Exchange-Traded Funds T Rowe Price Us H) Start Date:2022-10-26
TILL (Listed Funds Trust Teucrium Agricultural Strategy No K-1 ETF) Start Date:2022-05-17
TILT (Flexshares Morningstar Us Market Factor Tilt Index Fund) Start Date:2011-09-22
TIME (Clockwise Core Equity & Innovation ETF) Start Date:2022-01-28
TINT (ProShares Smart Materials ETF) Start Date:2021-10-27
TINY (ProShares Nanotechnology ETF) Start Date:2021-10-27
TIP (iShares Barclays Tips Bond Fund) Start Date:2003-12-05
TIPX (SPDR Bloomberg 1-10 Year Tips ETF) Start Date:2013-05-30
TIPZ (Pimco Broad Us Tips ETF) Start Date:2009-09-09
TJAN (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2025-01-02
TJUL (Innovator ETFs Trust Innovator Equity Defined Protection ETF -) Start Date:2023-07-18
TLCI (Touchstone ETF Trust Touchstone International Equity ETF) Start Date:2025-03-05
TLH (iShares 10-20 Year Treasury Bond ETF) Start Date:2007-01-11
TLT (iShares Barclays 20+ Year Treas Bond) Start Date:2002-07-30
TLTD (Flexshares Morningstar Developed Markets Ex-Us Market Factor Tilt Index ETF) Start Date:2012-09-28
TLTE (Flexshares Mstar Emgmkts Fcttilt ETF) Start Date:2012-09-28
TLTW (iShares Trust iShares 20+ Year Treasury Bond Buywrite Strategy) Start Date:2022-08-22
TMAT (Main Thematic Innovation ETF) Start Date:2021-01-29
TMB (Thornburg Multi Sector Bond ETF) Start Date:2025-02-05
TMDV (ProShares Russell Us Dividend Growers ETF) Start Date:2019-11-07
TMET (iShares Transition-Enabling Metals ETF) Start Date:2023-09-28
TMF (Direxion Daily 20+ Year Treasury Bull 3X Shares) Start Date:2009-04-16
TMFC (Motley Fool 100 Index ETF) Start Date:2018-01-30
TMFE (The Rbb Fund Motley Fool Capital Efficiency 100 Index Et) Start Date:2021-12-31
TMFG (Motley Fool Global Opportunities ETF) Start Date:2021-12-13
TMFM (Motley Fool Mid-Cap Growth ETF) Start Date:2021-12-13
TMFS (Motley Fool Small-Cap Growth ETF) Start Date:2021-12-31
TMFX (The Rbb Fund Motley Fool Next Index ETF) Start Date:2021-12-31
TMSL (T Rowe Price Exchange-Traded Funds T Rowe Price Small-) Start Date:2023-06-15
TMV (Direxion Daily 30-Yr Treasury B) Start Date:2009-04-16
TNA (Direxion Daily Small Cap Bull 3X Shares) Start Date:2008-11-05
TOAK (Manager Directed Portfolios Twin Oak Short Horizon Absolute Re) Start Date:2024-08-20
TOGA (Managed Portfolio Series Tremblant Global ETF) Start Date:2024-05-03
TOK (iShares MSCI Kokusai) Start Date:2007-12-12
TOKE (Cambria ETF Trust) Start Date:2019-07-25
TOLL (Tema ETF Trust Tema Monopolies And Oligopolies ETF) Start Date:2023-05-11
TOLZ (ProShares Dj Brookfield Global Infras) Start Date:2014-03-27
TOPT (iShares Trust iShares Top 20 U.S. Stocks ETF) Start Date:2024-10-24
TOTL (SPDR Doubleline Total Return Tactical ETF) Start Date:2015-02-24
TOTR (T. Rowe Price Total Return ETF) Start Date:2021-09-29
TOUS (T Rowe Price Exchange-Traded Funds T Rowe Price Intern) Start Date:2023-06-15
TOV (Ea Series Trust Jlens 500 Jewish Advocacy U.S. ETF) Start Date:2025-02-27
TPHD (Timothy Plan High Dividend Stock ETF) Start Date:2019-05-01
TPHE (Timothy Plan High Dividend Stock Enhanced ETF) Start Date:2021-07-29
TPIF (Timothy Plan International ETF) Start Date:2019-12-03
TPLC (Timothy Plan Us Large/Mid Cap Core ETF) Start Date:2019-05-01
TPLE (Timothy Plan Us Large/Mid Cap Core Enhanced ETF) Start Date:2021-07-29
TPLS (Thornburg Core Plus Bond ETF) Start Date:2025-02-05
TPMN (The Timothy Plan Timothy Plan Market Neutral ETF) Start Date:2023-01-25
TPOR (Direxion Daily Transportation Bull 3X Shares) Start Date:2017-05-03
TPSC (Timothy Plan Us Small Cap Core ETF) Start Date:2019-12-03
TPYP (Tortoise North American Pipeline Fund) Start Date:2015-06-30
TQQQ (ProShares Ultrapro Qqq) Start Date:2010-02-11
TQQY (Graniteshares Yieldboost Qqq ETF) Start Date:2025-02-26
TRFK (Pacer Funds Pacer Data And Digital Revolution ETF) Start Date:2022-06-10
TRFM (ETF Series Solutions Aam Transformers ETF) Start Date:2022-07-12
TRND (Rbs Us Large Cap Trendpilot ETN) Start Date:2019-05-06
TRPA (Hartford Aaa Clo ETF) Start Date:2025-04-15
TRPL (Pacer Metaurus Us Large Cap Dividend Multiplier 300 ETF) Start Date:2021-07-13
TRTY (Cambria Trinity ETF) Start Date:2018-09-12
TRUD (Vaneck Consumer Discretionary Trusector ETF) Start Date:2025-08-21
TRUT (Vaneck Technology Trusector ETF) Start Date:2025-08-21
TSDD (Graniteshares 1.5X Short Tsla Daily ETF) Start Date:2023-08-22
TSEC (Touchstone ETF Trust Touchstone Securitized Income ETF) Start Date:2023-07-19
TSEL (Touchstone Sands Capital Us Select Growth ETF) Start Date:2025-01-03
TSJA (Innovator Triple Stacker ETF - January) Start Date:2021-01-04
TSL (Graniteshares 1.25X Long Tsla Daily ETF) Start Date:2022-08-09
TSLG (Leverage Shares 2X Long Tsla Daily ETF) Start Date:2024-12-13
TSLH (Innovator ETFs Trust Innovator Hedged Tsla Strategy ETF) Start Date:2022-07-26
TSLL (Direxion Daily Tsla Bull 1.5X Shares) Start Date:2022-08-09
TSLP (Neos ETF Trust Kurv Yield Premium Strategy Tesla) Start Date:2023-10-27
TSLQ (Axs Tsla Bear Daily ETF) Start Date:2022-07-14
TSLR (Graniteshares 1.75X Long Tsla Daily ETF) Start Date:2023-08-22
TSLS (Direxion Daily Tsla Bear 1X Shares) Start Date:2022-08-09
TSLT (T-Rex 2X Long Tesla Daily Target ETF) Start Date:2023-10-19
TSLW (Tradr 1.5X Long Tsla Weekly ETF) Start Date:2024-09-03
TSLY (Tidal ETF Trust Ii Yieldmax Tsla Option Income Strategy ETF) Start Date:2022-11-23
TSLZ (T-Rex 2X Inverse Tesla Daily Target ETF) Start Date:2023-10-19
TSME (Thrivent ETF Trust Thrivent Small-Mid Cap ESG ETF) Start Date:2022-10-05
TSMG (Leverage Shares 2X Long Tsm Daily ETF) Start Date:2025-01-14
TSMU (Graniteshares 2X Long Tsm Daily ETF) Start Date:2024-11-12
TSMX (Direxion Daily Tsm Bull 2X Shares) Start Date:2024-10-03
TSMY (Tidal Trust Ii Yieldmax Tsm Option Income Strategy ETF) Start Date:2024-08-21
TSMZ (Direxion Daily Tsm Bear 1X Shares) Start Date:2024-10-03
TSOC (Innovator Triple Stacker ETF - October) Start Date:2020-10-01
TSPA (T. Rowe Price U.S. Equity Research ETF) Start Date:2021-06-09
TSPY (Tappalpha Spy Growth & Daily Income ETF) Start Date:2024-08-15
TSYY (Graniteshares Yieldboost Tsla ETF) Start Date:2024-12-18
TTAC (Trimtabs Float Shrink ETF) Start Date:2016-09-28
TTAI (Fcf International Quality ETF) Start Date:2017-06-28
TTEQ (T Rowe Price Technology ETF) Start Date:2024-10-24
TTT (ProShares Ultrapro Short 20+ Year Treasury) Start Date:2012-03-29
TUA (Simplify Exchange Traded Funds Simplify Short Term Treasury Fu) Start Date:2022-11-15
TUG (Stf Tactical Growth ETF) Start Date:2022-05-19
TUGN (Stf Tactical Growth & Income ETF) Start Date:2022-05-19
TUR (iShares MSCI Turkey Investable) Start Date:2008-03-28
TUSB (Thrivent ETF Trust Thrivent Ultra Short Bond ETF) Start Date:2025-02-19
TUSI (Touchstone ETF Trust Touchstone Ultra Short Income ETF) Start Date:2022-08-09
TVAL (T Rowe Price Exchange-Traded Funds T Rowe Price Value) Start Date:2023-06-15
TWIO (Spinnaker ETF Series Trajan Wealth Income Opportunities ETF) Start Date:2021-04-01
TWM (ProShares Ultrashort Russell200) Start Date:2007-01-25
TXS (Texas Capital Funds Trust Texas Capital Texas Equity Index ETF) Start Date:2023-07-13
TXSS (Texas Capital Texas Small Cap Equity Index ETF) Start Date:2023-12-21
TXUE (Thornburg International Equity ETF) Start Date:2025-01-22
TXUG (Thornburg International Growth Fund ETF) Start Date:2025-01-23
TYA (Simplify Intermediate Term Treasury Futures Strategy ETF) Start Date:2021-09-28
TYD (Direxion Daily 10-Yr Treasury B) Start Date:2009-04-17
TYLD (Cambria ETF Trust Cambria Tactical Yield ETF) Start Date:2024-01-04
TYLG (Global X Funds Global X Information Technology Covered Call &) Start Date:2022-11-22
TYO (Direxion Daily 7-10 Yr Trs Bear 3X ETF) Start Date:2009-04-16
TZA (Direxion Daily Small Cap Bear 3X Shares) Start Date:2008-11-05
UAE (iShares MSCI Uae Capped) Start Date:2014-05-01
UAPR (Innovator S&P 500 Ultra Buffer ETF) Start Date:2019-04-01
UAUG (Innovator Us Equity Ultra Buffer ETF - August) Start Date:2019-08-01
UBND (WisdomTree Western Asset Uncnstnd Bd ETF) Start Date:2021-10-05
UBOT (Direxion Daily Robotics) Start Date:2018-04-19
UBR (ProShares Ultra MSCI Brazil Capped) Start Date:2010-04-29
UBRL (Graniteshares 2X Long Uber Daily ETF) Start Date:2024-09-04
UBT (ProShares Ultra 20+ Year Treasury) Start Date:2010-01-21
UCC (ProShares Ultra Consumer Services) Start Date:2007-02-05
UCIB (Ubs Etracs Bloomberg Constant Maturity Commodity Index Cmci Total Return ETN Series B Due 5 April 2038) Start Date:2015-10-09
UCO (ProShares Ultra Dj-Aig Crude Oil) Start Date:2008-11-25
UCON (First Trust TCWUnconstrained Plus Bond ETF) Start Date:2018-06-05
UCRD (Victoryshares ESG Corporate Bond ETF) Start Date:2021-10-05
UCYB (ProShares Ultra Nasdaq Cybersecurity ETF) Start Date:2021-01-21
UDEC (Innovator Us Equity Ultra Buffer ETF - December) Start Date:2019-12-02
UDI (Uscf ETF Trust Uscf Dividend Income Fund) Start Date:2022-06-08
UDIV (Franklin Us Core Dividend Tilt Index ETF) Start Date:2016-06-03
UDN (PowerShares DB Us Dollar Bearish ETF) Start Date:2007-03-01
UDOW (ProShares Ultrapro Dow30) Start Date:2010-02-11
UEVM (Victoryshares Usaa MSCI Emerging Markets Value Momentum ETF) Start Date:2017-10-26
UFEB (Innovator S&P 500 Ultra Buffer ETF February Series) Start Date:2020-02-03
UFIV (Us Treasury 5 Year Note ETF) Start Date:2023-03-28
UFO (Procure Space ETF) Start Date:2019-04-11
UGA (United States Gasoline) Start Date:2008-02-27
UGE (ProShares Ultra Consumer Goods) Start Date:2007-05-18
UGL (ProShares Ultra Gold) Start Date:2008-12-03
UITB (Victoryshares Usaa Core Intermediate-Term Bond ETF) Start Date:2017-10-26
UIVM (Victoryshares Usaa MSCI International Value Momentum ETF) Start Date:2017-10-26
UJAN (Innovator S&P 500 Ultra Buffer ETF) Start Date:2019-01-02
UJB (ProShares Ultra High Yield) Start Date:2011-04-14
UJUL (Innovator S&P 500 Ultra Buffer ETF) Start Date:2018-08-08
UJUN (Innovator Us Equity Ultra Buffer ETF - June) Start Date:2019-06-03
ULE (ProShares Ultra Euro) Start Date:2008-11-25
ULST (SPDR Ssga Ultra Short Term Bond ETF Of Ssga Active Trust) Start Date:2013-10-10
ULTR (IQ Ultra Short Duration ETF) Start Date:2019-07-31
ULTY (Tidal Trust Ii Yieldmax Ultra Option Income Strategy ETF) Start Date:2024-02-29
ULVM (Victoryshares Usaa MSCI Usa Value Momentum ETF) Start Date:2017-10-26
UMAR (Innovator Us Equity Ultra Buffer ETF - March) Start Date:2020-03-02
UMAY (Innovator Us Equity Ultra Buffer ETF - May) Start Date:2020-05-01
UMDD (ProShares Ultrapro Midcap400) Start Date:2010-02-11
UMI (Uscf Midstream Energy Income Fund ETF) Start Date:2021-03-24
UMMA (Wahed Dow Jones Islamic World ETF) Start Date:2022-01-07
UNG (United States Natural Gas Fund) Start Date:2007-04-18
UNIY (WisdomTree Voya Yield Enhanced Usd Universal Bond Fund) Start Date:2023-02-07
UNL (United States 12 Month Natural Gas) Start Date:2009-11-18
UNOV (Innovator Us Equity Ultra Buffer ETF - November) Start Date:2019-11-01
UOCT (Innovator S&P 500 Ultra Buffer ETF) Start Date:2018-10-01
UPAR (Tidal ETF Trust Upar Ultra Risk Parity ETF) Start Date:2022-01-04
UPGD (Invesco Bloomberg Analyst Rating Improvers ETF) Start Date:2007-05-16
UPGR (Xtrackers Us Green Infrastructure Select Equity ETF) Start Date:2023-07-13
UPRO (ProShares Ultrapro S&P500) Start Date:2009-06-25
UPV (ProShares Ultra FTSE Europe) Start Date:2010-04-30
UPW (ProShares Ultra Utilities) Start Date:2007-02-01
URA (Global X Uranium ETF) Start Date:2010-11-05
URAA (Direxion Shares ETF Trust Direxion Daily Uranium Industry Bull) Start Date:2024-06-26
URAN (Themes ETF Trust Themes Uranium & Nuclear ETF) Start Date:2024-09-24
URAX (Tidal Trust Ii Defiance Daily Target 2X Long Uranium ETF) Start Date:2024-05-28
URE (ProShares Ultra Real Estate) Start Date:2007-02-06
URNJ (Sprott Junior Uranium Miners ETF) Start Date:2023-02-02
URNM (Northshore Global Uranium Mining ETF) Start Date:2019-12-04
URTH (iShares MSCI World ETF) Start Date:2012-01-12
URTY (ProShares Ultrapro Russell2000) Start Date:2010-02-11
USAF (Atlas America Fund) Start Date:2024-11-20
USAI (Pacer American Energy Independence ETF) Start Date:2017-12-13
USCA (DBx ETF Trust Xtrackers MSCI Usa Climate Action Equity ETF) Start Date:2023-04-06
USCF (Themes Us Cash Flow Champions ETF) Start Date:2023-12-13
USCI (United States Commodity Index) Start Date:2010-08-10
USCL (iShares Climate Conscious & Transition MSCI Usa ETF) Start Date:2023-06-08
USD (ProShares Ultra Semiconductors) Start Date:2007-02-01
USDU (WisdomTree Bloomberg Us Dllr Bullish ETF) Start Date:2013-12-18
USDX (Sgi Enhanced Core ETF) Start Date:2024-02-29
USE (Uscf ETF Trust Uscf Energy Commodity Strategy Absolute Return) Start Date:2023-05-04
USEP (Innovator ETFs Trust) Start Date:2019-09-03
USEQ (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-07-13
USFI (Brandywineglobal - Us Fixed Income ETF) Start Date:2023-07-27
USFR (WisdomTree Floating Rate Treasury Fund) Start Date:2014-02-04
USG (Uscf Gold Strategy Plus Income Fund) Start Date:2021-11-03
USHY (iShares Broad Usd High Yield Corporate Bond) Start Date:2017-10-26
USI (Principal Ultra-Short Active Income ETF) Start Date:2019-04-25
USIG (iShares Broad Usd Investment Grade Corporate Bond ETF) Start Date:2014-06-12
USIN (WisdomTree 7-10 Year Laddered Treasury Fund) Start Date:2024-03-14
USL (United States 12 Month Oil) Start Date:2007-12-06
USLB (PowerShares Russell 1000 Low Beta Eq Wgt) Start Date:2015-11-05
USMC (Principal U.S. Mega-Cap ETF) Start Date:2017-10-12
USMF (WisdomTree Us Multifactor Fund) Start Date:2017-06-29
USML (Etracs 2X Leveraged MSCI Us Minimum Volatility Factor Tr ETN) Start Date:2021-02-09
USMV (iShares Edge MSCI Min Vol Usa) Start Date:2011-10-20
USNZ (DBx ETF Trust Xtrackers Net Zero Pathway Paris Aligned Us Equi) Start Date:2022-06-28
USO (United States Oil) Start Date:2006-04-10
USOI (Credit Suisse Ag Credit Suisse X-Links Crude Oil Shares Covered Call ETN) Start Date:2017-04-26
USOY (Defiance Oil Enhanced Options Income ETF) Start Date:2024-05-10
USPX (Franklin Us Equity Index ETF) Start Date:2016-06-03
USRD (Themes Us R&D Champions ETF) Start Date:2023-12-13
USRT (iShares Core U.S. Reit ETF) Start Date:2016-11-03
USSE (Segall Bryant & Hamill Trust Segall Bryant & Hamill Select Equ) Start Date:2023-08-30
USSG (MSCI Usa ESG Leaders Equity ETF) Start Date:2019-03-07
USSH (WisdomTree 1-3 Year Laddered Treasury Fund) Start Date:2024-03-14
UST (ProShares Ultra 7-10 Year Treasury) Start Date:2010-01-22
USTB (Victoryshares Usaa Core Short-Term Bond ETF) Start Date:2017-10-26
USVM (Victoryshares Usaa MSCI Usa Small Cap Value Momentum ETF) Start Date:2017-10-26
USVN (Us Treasury 7 Year Note ETF) Start Date:2023-03-28
USVT (Us Value ETF) Start Date:2021-09-14
USXF (iShares ESG Advanced MSCI Usa ETF) Start Date:2020-06-18
UTEN (Us Treasury 10 Year Note ETF) Start Date:2022-08-09
UTES (Virtus Reaves Utilities ETF) Start Date:2015-09-24
UTHY (Us Treasury 30 Year Bond ETF) Start Date:2023-03-28
UTRE (Us Treasury 3 Year Note ETF) Start Date:2023-03-28
UTRN (Vesper Us Large Cap Short-Term Reversal Strategy ETF) Start Date:2018-09-21
UTSL (Direxion Daily Utilities Bull 3X Shares) Start Date:2017-05-03
UTWO (Us Treasury 2 Year Note ETF) Start Date:2022-08-09
UTWY (Us Treasury 20 Year Bond ETF) Start Date:2023-03-28
UUP (PowerShares DB Usd Index Bullis) Start Date:2007-02-20
UVDV (Uva Dividend Value ETF) Start Date:2021-11-19
UVIX (2X Long VIX Futures ETF) Start Date:2022-03-30
UVXY (ProShares Trust Ultra VIX Short) Start Date:2011-10-04
UWM (ProShares Ultra Russell2000) Start Date:2007-01-25
UXI (ProShares Ultra Industrials) Start Date:2007-02-05
UYG (ProShares Ultra Financials) Start Date:2007-02-01
UYLD (Angel Oak Funds Trust Angel Oak Ultrashort Income ETF) Start Date:2022-10-25
UYM (ProShares Ultra Basic Materials) Start Date:2007-03-13
VABS (Virtus Newfleet Abs/Mbs ETF) Start Date:2021-02-10
VALQ (American Century STOXX U.S. Quality Value ETF) Start Date:2018-01-16
VALT (ETFmg Sit Ultra Short ETF) Start Date:2019-10-09
VAMO (Cambria Value And Momentum ETF) Start Date:2015-09-09
VAW (Vanguard Materials ETF) Start Date:2004-01-30
VB (Vanguard Small-Cap ETF) Start Date:2004-01-30
VBIL (Vanguard 0-3 Month Treasury Bill ETF) Start Date:2025-02-12
VBK (Vanguard Small Cap Growth ETF) Start Date:2004-01-30
VBND (Vident Core Us Bond Strategy ETF) Start Date:2014-10-16
VBR (Vanguard Small Cap Value ETF) Start Date:2004-01-30
VCAR (Simplify Volt Robocar Disruption And Tech ETF) Start Date:2020-12-29
VCEB (Vanguard World Funds) Start Date:2020-09-24
VCIT (Vanguard It Bond ETF) Start Date:2009-11-23
VCLN (Virtus Duff & Phelps Clean Energy ETF) Start Date:2021-08-04
VCLO (Simplify Volt Cloud And Cybersecurity Disruption ETF) Start Date:2020-12-29
VCLT (Vanguard Long-Term Corporate Bonds) Start Date:2009-11-23
VCR (Vanguard Consumer Discretionary ETF) Start Date:2004-01-30
VCRB (Vanguard Core Bond ETF) Start Date:2023-12-14
VCSH (Vanguard St Bond ETF) Start Date:2009-11-23
VDC (Vanguard Consumer Staples ETF) Start Date:2004-01-30
VDE (Vanguard Energy ETF) Start Date:2004-10-01
VEA (Vanguard Europe Pacific ETF) Start Date:2007-07-26
VEGA (AdvisorShares Star Global Buy-Write ETF) Start Date:2012-09-18
VEGI (iShares MSCI Global Agriculture Producers ETF) Start Date:2012-02-02
VEGN (Us Vegan Climate Index) Start Date:2019-09-10
VEMY (Virtus ETF Trust Ii Virtus Stone Harbor Emerging Markets High) Start Date:2022-12-13
VERS (ProShares Trust ProShares Metaverse ETF) Start Date:2022-03-17
VETZ (Tidal ETF Trust Academy Veteran Impact ETF) Start Date:2023-08-02
VEU (Vanguard FTSE Aw Ex-Us ETF) Start Date:2007-03-08
VFH (Vanguard Financials ETF) Start Date:2004-01-30
VFLO (Victoryshares Free Cash Flow ETF) Start Date:2023-06-22
VFMF (Vanguard Us Multifactor Fund ETF) Start Date:2018-02-15
VFMO (Vanguard Us Momentum Factor ETF) Start Date:2018-02-15
VFMV (Vanguard Us Minimum Volatility ETF) Start Date:2018-02-15
VFQY (Vanguard U.S. Quality Factor ETF) Start Date:2018-02-15
VFVA (Vanguard Us Value Factor ETF) Start Date:2018-02-15
VGIT (Vanguard Intermediate-Term Treasury ETF) Start Date:2009-11-23
VGK (Vanguard European ETF) Start Date:2005-03-10
VGLT (Vanguard Long-Term Treasury ETF) Start Date:2009-11-24
VGSH (Vanguard Short-Term Treasury ETF) Start Date:2009-11-23
VGSR (Vert Global Sustainable Real Estate ETF) Start Date:2023-12-04
VGT (Vanguard Information Tech ETF) Start Date:2004-01-30
VGUS (Vanguard Ultra-Short Treasury ETF) Start Date:2025-02-12
VHT (Vanguard Healthcare ETF) Start Date:2004-01-30
VICE (AdvisorShares Trust AdvisorShares Vice ETF) Start Date:2017-12-13
VIDI (Vident International Equity Fund) Start Date:2013-10-30
VIG (Vanguard Dividend Apprec ETF) Start Date:2006-04-27
VIGI (Vanguard International Dividend Appreciation Index Fund) Start Date:2016-03-02
VIOG (Vanguard S&P Small-Cap 600 Growth ETF) Start Date:2010-09-09
VIOO (Vanguard S&P Small-Cap 600 ETF) Start Date:2010-09-09
VIOV (Vanguard S&P Small-Cap 600 Value ETF) Start Date:2010-09-09
VIRS (Pacer Biothreat Strategy ETF) Start Date:2020-06-25
VIS (Vanguard Industrial ETF) Start Date:2004-10-22
VIXM (ProShares VIX Mid-Term Futures ETF) Start Date:2011-01-04
VIXY (ProShares Trust VIX Short-Term) Start Date:2011-01-04
VLLU (Harbor ETF Trust Harbor Alphaedge Large Cap Value ETF) Start Date:2024-09-05
VLU (SPDR S&P 1500 Value Tilt ETF) Start Date:2012-10-25
VLUE (iShares Edge MSCI Usa Value Factor ETF) Start Date:2013-04-18
VMAX (Rex Volmaxx Lng VIX Wkly Futs Strat ETF) Start Date:2016-05-03
VMBS (Vanguard Mortgage-Backed Securities ETF) Start Date:2009-11-23
VMOT (Alpha Architect ETF Trust) Start Date:2017-05-03
VNAM (Global X Funds Global X MSCI Vietnam ETF) Start Date:2021-12-09
VNLA (Janus Henderson Short Duration Income ETF) Start Date:2016-11-17
VNM (Vaneck Vectors Vietnam ETF) Start Date:2009-08-14
VNMC (Natixis Vaughan Nelson Mid Cap ETF) Start Date:2020-09-17
VNQ (Vanguard Reit ETF) Start Date:2004-09-29
VNQI (Vanguard Global Ex-Us Real Estate) Start Date:2010-11-01
VNSE (Natixis Vaughan Nelson Select ETF) Start Date:2020-09-17
VO (Vanguard Mid-Cap ETF) Start Date:2004-01-30
VOE (Vanguard Mid-Cap Value ETF) Start Date:2006-08-25
VOLT (Tema Electrification ETF) Start Date:2007-07-26
VONE (Vanguard Russell 1000 ETF) Start Date:2010-09-22
VONG (Vanguard Russell 1000 Growth ETF) Start Date:2010-09-22
VONV (Vanguard Russell 1000 Value ETF) Start Date:2010-09-22
VOO (Vanguard S&P 500 ETF) Start Date:2010-09-09
VOOG (Vanguard S&P 500 Growth ETF) Start Date:2010-09-09
VOOV (Vanguard S&P 500 Value ETF) Start Date:2010-09-09
VOT (Vanguard Mid-Cap Growth ETF) Start Date:2006-08-25
VOTE (Engine No. 1 Transform 500 ETF) Start Date:2021-06-23
VOX (Vanguard Communication Services ETF) Start Date:2004-09-29
VPC (Virtus Private Credit Strategy ETF) Start Date:2019-02-08
VPL (Vanguard Pacific ETF) Start Date:2005-03-10
VPLS (Vanguard Core Plus Bond ETF) Start Date:2023-12-07
VPN (Global X Data Center Reits & Digital Infrastructure ETF) Start Date:2020-11-02
VPU (Vanguard Utilities ETF) Start Date:2007-03-13
VRAI (Virtus Real Asset Income ETF) Start Date:2019-02-08
VRIG (Invesco Variable Rate Investment Grade ETF) Start Date:2016-09-22
VRP (Invesco Variable Rate Preferred ETF) Start Date:2014-05-01
VSDA (Victoryshares Dividend Accelerator ETF) Start Date:2017-04-18
VSGX (Vanguard ESG International Stock ETF) Start Date:2018-09-20
VSHY (Virtus Newfleet Short Duration High Yield Bond ETF) Start Date:2023-11-29
VSLU (Applied Finance Valuation Large Cap ETF) Start Date:2021-04-30
VSMV (Victoryshares Us Multi-Factor Minimum Volatility ETF) Start Date:2017-06-22
VSS (Vanguard FTSE All-World Ex-Us Small-Cap ETF) Start Date:2009-04-06
VT (Vanguard Total World Stock ETF) Start Date:2008-06-26
VTC (Vanguard Total Corporate Bond ETF) Start Date:2017-11-09
VTEB (Vanguard Tax-Exempt Bond Index ETF) Start Date:2015-08-25
VTEC (Vanguard California Tax-Exempt Bond ETF Vanguard California Ta) Start Date:2024-01-30
VTEI (Vanguard Tax-Managed Funds Vanguard Intermediate-Term Tax-Exem) Start Date:2024-01-30
VTES (Vanguard Wellington Fund Vanguard Short-Term Tax Exempt Bond E) Start Date:2023-03-09
VTHR (Vanguard Russell 3000 ETF) Start Date:2010-09-22
VTI (Vanguard Total Stock Market ETF) Start Date:2001-06-15
VTIP (Vanguard Short-Term Inflation-Protected Securities ETF) Start Date:2012-10-16
VTV (Vanguard Value ETF) Start Date:2004-01-30
VTWG (Vanguard Russell 2000 Growth ETF) Start Date:2010-09-22
VTWO (Vanguard Russell 2000 ETF) Start Date:2010-09-22
VTWV (Vanguard Russell 2000 Value ETF) Start Date:2010-09-22
VUG (Vanguard Growth ETF) Start Date:2004-01-30
VUSB (Vanguard Ultra-Short Bond ETF) Start Date:2021-04-07
VUSE (Vident Core Us Equity) Start Date:2014-01-22
VV (Vanguard Large-Cap ETF) Start Date:2004-01-30
VWI (Trust For Advised Portfolios Arch Indices Voi Absolute Income) Start Date:2023-10-05
VWID (ETFis Series Trust I) Start Date:2020-07-20
VWO (Vanguard MSCI Emerging Markets ETF) Start Date:2005-03-10
VWOB (Vanguard Emerging Markets Government Bond ETF) Start Date:2013-06-04
VXF (Vanguard Extended Market Vipers ETF) Start Date:2002-01-04
VXUS (Vanguard Total International Stock Index) Start Date:2011-01-28
VXX (iPath S&P 500 VIX Short-Term Futures) Start Date:2009-03-02
VXZ (iPath Series B S&P 500Â® VIX Mid-Term Futures ETN) Start Date:2009-02-20
VYM (Vanguard High Dividend Yld ETF) Start Date:2006-11-16
VYMI (Vanguard International High Dividend Yield Index Fund) Start Date:2016-03-02
WABF (Western Asset Bond ETF) Start Date:2023-09-21
WANT (Direxion Daily Consumer Discretionary Bull 3X Shares) Start Date:2018-11-29
WAR (ETF Series Solutions Us Global Tech And Aerospace & Defense) Start Date:2024-12-30
WBAT (WisdomTree Trust WisdomTree Battery Value Chain And Innovation) Start Date:2022-02-17
WBIF (Wbi Bull|Bear Value 1000 ETF) Start Date:2014-08-27
WBIG (Wbi Tactical Lcy Shares ETF) Start Date:2014-08-27
WBIL (Wbi Bull|Bear Quality 1000 ETF) Start Date:2014-09-03
WBIY (Wbi Power Factor High Dividend ETF) Start Date:2016-12-22
WBND (Western Asset Total Return ETF) Start Date:2018-10-04
WCBR (WisdomTree Cybersecurity Fund) Start Date:2021-01-28
WCEO (Affinity World Leaders Equity ETF Hypatia Women Ceo ETF) Start Date:2023-01-09
WCLD (WisdomTree Cloud Computing Fund) Start Date:2019-09-06
WCME (First Trust Exchange-Traded Fund First Trust Wcm Developing World) Start Date:2024-10-11
WCMI (First Trust Exchange-Traded Fund First Trust Wcm International) Start Date:2024-10-07
WDIV (SPDR S&P Global Dividend ETF) Start Date:2013-05-30
WDTE (Defiance S&P 500 Enhanced Options & 0Dte Income ETF) Start Date:2023-09-19
WEAT (Teucrium Wheat Fund) Start Date:2011-09-19
WEBL (Direxion Daily Dow Jones Internet Bull 3X Shares) Start Date:2019-11-07
WEBS (Direxion Daily Dow Jones Internet Bear 3X Shares) Start Date:2019-11-07
WEED (Listed Funds Trust Roundhill Cannabis ETF) Start Date:2022-04-20
WEEI (Westwood Salient Enhanced Energy Income ETF) Start Date:2024-05-01
WEEL (Tidal Trust Ii Peerless Option Income Wheel ETF) Start Date:2024-05-16
WEIX (Dynamic Shares Trust Dynamic Short Short-Term Volatility Futur) Start Date:2022-01-13
WFH (Direxion Work From Home ETF) Start Date:2020-06-25
WFHY (WisdomTree Us High Yield Corporate Bond Fund) Start Date:2020-06-25
WFIG (WisdomTree Us Corporate Bond Fund) Start Date:2016-04-27
WGMI (Valkyrie Bitcoin Miners ETF) Start Date:2022-02-08
WGRO (WisdomTree U.S. Growth & Momentum Fund) Start Date:2021-06-24
WINC (Western Asset Short Duration Income ETF) Start Date:2019-02-08
WINN (Harbor ETF Trust Harbor Long-Term Growers ETF) Start Date:2022-02-03
WIP (SPDR DB International Government) Start Date:2008-03-19
WISE (Themes Generative Artificial Intelligence ETF) Start Date:2023-12-08
WIZ (Alpha Architect Merlyn.AI Bull-Rider Bear-Fighter ETF) Start Date:2019-10-17
WKLY (Sofi Weekly Dividend ETF) Start Date:2021-05-11
WLDR (Affinity World Leaders Equity ETF) Start Date:2018-01-17
WLTG (Wealthtrust DBs Long Term Growth ETF) Start Date:2021-12-07
WNDY (Global X Wind Energy ETF) Start Date:2021-09-15
WOMN (Impact Shares Trust I ETF Impact Shares Ywca Womenas Empowerme) Start Date:2018-08-28
WOOD (iShares Global Timber & Forestry) Start Date:2008-06-25
WPS (iShares Trust iShares S&P Devel) Start Date:2007-08-07
WRND (IQ Global Equity R&D Leaders ETF) Start Date:2022-02-08
WTAI (WisdomTree Trust WisdomTree Artificial Intelligence And Innovation) Start Date:2021-12-09
WTBN (WisdomTree Bianco Total Return Fund) Start Date:2023-12-20
WTID (Ubs Etracs ProShares Dly 3X Invrs Crdetn) Start Date:2023-02-15
WTIU (Ubs Etracs ProShares Dly 3X Lng Crud ETN) Start Date:2023-02-15
WTMF (WisdomTree Managed Futures Strategy Fund) Start Date:2011-01-05
WTPI (WisdomTree Equity Premium Income Fund) Start Date:2025-04-04
WTRE (WisdomTree New Economy Real Estate Fund) Start Date:2007-06-05
WTV (WisdomTree U.S. Value Fund) Start Date:2007-05-16
WUCT (Etracs Whitney Us Critical Technologies Index ETN) Start Date:2023-03-27
WUGI (Esoterica Nextg Economy ETF) Start Date:2020-03-31
WWJD (Inspire International ESG ETF) Start Date:2019-10-01
WXET (Listed Funds Trust Teucrium 2X Daily Wheat ETF) Start Date:2024-12-24
XAIX (Xtrackers Artificial Intelligence And Big Data ETF) Start Date:2024-08-06
XAPR (Shl Telemedicine FTVest Us Equity Enhance & Moderate Bu) Start Date:2024-04-22
XAR (SPDR S&P Aerospace & Defense ETF) Start Date:2011-09-29
XAUG (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-08-21
XB (Bondbloxx ETF Trust Bondbloxx B-Rated Usd High Yield Corporate) Start Date:2022-05-26
XBAP (Innovator U.S. Equity Accelerated 9 Buffer ETF - April) Start Date:2021-04-01
XBB (Bondbloxx ETF Trust Bondbloxx Bb-Rated Usd High Yield Corporat) Start Date:2022-05-26
XBI (SPDR Series Trust SPDR S&P Bio) Start Date:2006-02-06
XBIL (Us Treasury 6 Month Bill ETF) Start Date:2023-03-07
XBJA (Innovator ETFs Trust Innovator Us Equity Accelerated 9 Buffe) Start Date:2022-01-03
XBJL (Innovator U.S. Equity Accelerated 9 Buffer ETF - July) Start Date:2021-07-01
XBOC (Innovator U.S. Equity Accelerated 9 Buffer ETF - October) Start Date:2021-10-01
XC (WisdomTree Trust WisdomTree Emerging Markets Ex-China Fund) Start Date:2022-09-22
XCCC (Bondbloxx ETF Trust Bondbloxx Ccc-Rated Usd High Yield Corpora) Start Date:2022-05-26
XCEM (Columbia Em Core Ex-China ETF) Start Date:2015-09-02
XCLR (Global X Funds Global X S&P 500 Collar 95-110 ETF) Start Date:2021-08-26
XCNY (SPDR S&P Emerging Markets Ex-China ETF) Start Date:2024-09-05
XCOR (Fundx Investment Trust Fundx ETF) Start Date:2022-10-17
XDAP (Innovator U.S. Equity Accelerated ETF - April) Start Date:2021-04-01
XDAT (Franklin Exponential Data ETF) Start Date:2021-01-14
XDEC (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2021-12-20
XDJA (Innovator ETFs Trust Innovator Us Equity Accelerated ETF - J) Start Date:2022-01-03
XDJL (Innovator U.S. Equity Accelerated ETF - July) Start Date:2021-07-01
XDOC (Innovator U.S. Equity Accelerated ETF - October) Start Date:2021-10-01
XDQQ (Innovator Growth Accelerated ETF - Quarterly) Start Date:2021-04-01
XDSQ (Innovator ETFs Trust Innovator U.S. Equity Accelerated ETF - Q) Start Date:2021-04-01
XDTE (Roundhill ETF Trust Roundhill S&P 500 0Dte Covered Call Strate) Start Date:2024-03-07
XEMD (Bondbloxx ETF Trust Bondbloxx JP Morgan Usd Emerging Markets 1) Start Date:2022-06-30
XES (SPDR S&P Oil & Gas Equipment & Services ETF) Start Date:2006-06-22
XFEB (First Trust Exchange-Traded Fund Viii FTVest Us Equity Enha) Start Date:2024-02-20
XFIV (Bondbloxx ETF Trust Bondbloxx Bloomberg Five Year Target Durat) Start Date:2022-09-15
XFIX (F/M Opportunistic Income ETF) Start Date:2023-09-06
XFLX (Fundx Investment Trust Fundx Flexible ETF) Start Date:2023-10-11
XHB (SPDR Series Trust SPDR Homebuil) Start Date:2006-02-06
XHE (SPDR S&P Health Care Equipment ETF) Start Date:2011-01-27
XHLF (Bondbloxx ETF Trust Bondbloxx Bloomberg Six Month Target Durat) Start Date:2022-09-15
XHS (SPDR S&P Health Care Services ETF) Start Date:2011-09-29
XHYC (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Consumer Cyc) Start Date:2022-02-17
XHYD (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Consumer Non) Start Date:2022-02-17
XHYE (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Energy Secto) Start Date:2022-02-17
XHYF (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Financial &) Start Date:2022-02-17
XHYH (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Healthcare S) Start Date:2022-02-17
XHYI (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Industrial S) Start Date:2022-02-17
XHYT (Bondbloxx ETF Trust Bondbloxx Usd High Yield Bond Telecom Med) Start Date:2022-02-17
XIDV (Franklin Templeton ETF Trust Franklin International Dividend) Start Date:2025-01-23
XIJN (First Trust Exchange-Traded Fund Viii FTVest U.S. Equity Buffer) Start Date:2024-06-24
XIMR (First Trust Exchange-Traded Fund Viii FTVest Us Equity Buff) Start Date:2024-03-19
XISE (FTVest Us Equity Buffer & Premium Income ETF - September) Start Date:2023-09-18
XITK (SPDR Factset Innovative Technology ETF) Start Date:2016-01-14
XJH (iShares ESG Screened S&P Mid-Cap ETF) Start Date:2020-09-24
XJR (iShares ESG Screened S&P Small-Cap ETF) Start Date:2020-09-24
XJUL (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-07-24
XJUN (FTCboe Vest U.S. Equity Enhance & Moderate Buffer ETF - June) Start Date:2021-07-13
XLB (Materials Select Sector SPDR) Start Date:2000-01-03
XLC (Communication Services Select Sector SPDR Fund) Start Date:2018-06-19
XLE (Energy Select Sector SPDR) Start Date:2000-01-03
XLF (Financial Select Sector SPDR) Start Date:2000-01-03
XLG (Invesco S&P 500Â® Top 50 ETF) Start Date:2005-05-10
XLI (Industrial Select Sector SPDR) Start Date:2000-01-03
XLK (Technology Select Sector SPDR) Start Date:2000-01-03
XLP (Consumer Staples Select Sector SPDR) Start Date:2000-01-03
XLRE (Real Estate Select Sector SPDR Fund) Start Date:2015-10-08
XLSR (SPDR Ssga U.S. Sector Rotation ETF) Start Date:2019-04-03
XLU (Utilities Select Sector SPDR) Start Date:2000-01-03
XLV (Health Care Select Sector SPDR) Start Date:2000-01-03
XLY (Consumer Discret Select Sector SPDR) Start Date:2000-01-03
XMAR (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2023-03-20
XMAY (First Trust Exchange-Traded Fund Viii FTVest Us Equity Enha) Start Date:2024-05-20
XME (SPDR S&P Metals & Mining) Start Date:2006-06-22
XMHQ (Invesco S&P Midcap Quality ETF) Start Date:2007-05-16
XMLV (Invesco S&P Midcap Low Volatility ETF) Start Date:2013-02-15
XMMO (Invesco S&P Midcap Momentum ETF) Start Date:2007-05-07
XMPT (Vaneck Vectors Cef Municipal Income ETF) Start Date:2011-07-13
XMVM (Invesco S&P Midcap Value With Momentum ETF) Start Date:2007-05-16
XNAV (Fundx Investment Trust Fundx Aggressive ETF) Start Date:2022-10-17
XNOV (FTVest Us Equity Enhance & Moderate Buffer ETF - November) Start Date:2023-11-20
XNTK (Nyse Technology ETF) Start Date:2007-05-16
XOCT (FTVest Us Equity Enhance & Moderate Buffer ETF - October) Start Date:2023-10-23
XOMO (Tidal ETF Trust Ii Yieldmax Xom Option Income Strategy ETF) Start Date:2023-08-31
XONE (Bondbloxx ETF Trust Bondbloxx Bloomberg One Year Target Durati) Start Date:2022-09-15
XOP (SPDR S&P Oil&Gas Exploration & Prod) Start Date:2006-06-22
XOUT (Graniteshares Xout U.S. Large Cap ETF) Start Date:2019-10-07
XOVR (Ershares Private-Public Crossover ETF) Start Date:2024-08-30
XPAY (Roundhill ETF Trust Roundhill S&P 500 Target 20 Managed Distribution) Start Date:2024-10-31
XPH (SPDR S&P Pharmaceuticals ETF) Start Date:2006-06-22
XPND (First Trust Expanded Technology ETF) Start Date:2021-06-15
XPP (ProShares Ultra FTSE China 50) Start Date:2009-06-04
XRLV (PowerShares S&P 500Ex-Rate Snsvlwvtl ETF) Start Date:2015-04-09
XRLX (Fundx Investment Trust Fundx Conservative ETF) Start Date:2023-10-11
XRMI (Global X Funds Global X S&P 500 Risk Managed Income ETF) Start Date:2021-08-26
XRT (SPDR S&P Retail) Start Date:2006-06-22
XSD (SPDR S&P Semiconductor ETF) Start Date:2006-02-06
XSEP (First Trust Exchange-Traded Fund Viii FTCboe Vest Us Equity) Start Date:2022-09-22
XSHD (PowerShares S&P Smcp Hi Div Low Volatil) Start Date:2016-12-01
XSHQ (Invesco Exchange-Traded Fund Trust Ii) Start Date:2017-04-06
XSLV (Invesco S&P Smallcap Low Volatility ETF) Start Date:2013-02-15
XSMO (Invesco S&P Smallcap Momentum ETF) Start Date:2007-05-16
XSOE (WisdomTree Emerging Markets Ex-State-Owned Enterprises Fund) Start Date:2014-12-10
XSVM (Invesco S&P Smallcap Value With Momentum ETF) Start Date:2007-05-16
XSVN (Bondbloxx ETF Trust Bondbloxx Bloomberg Seven Year Target Dura) Start Date:2022-09-15
XSW (SPDR S&P Software & Services ETF) Start Date:2011-09-29
XT (iShares Exponential Technologies ETF) Start Date:2015-03-23
XTAP (Innovator U.S. Equity Accelerated Plus ETF - April) Start Date:2021-04-01
XTEN (Bondbloxx ETF Trust Bondbloxx Bloomberg Ten Year Target Durati) Start Date:2022-09-15
XTJA (Innovator ETFs Trust Innovator Us Equity Accelerated Plus Et) Start Date:2022-01-03
XTJL (Innovator U.S. Equity Accelerated Plus ETF - July) Start Date:2021-07-01
XTL (SPDR S&P Telecom ETF) Start Date:2011-01-27
XTN (SPDR S&P Transportation ETF) Start Date:2011-01-27
XTOC (Innovator U.S. Equity Accelerated Plus ETF - October) Start Date:2021-10-01
XTR (Global X Funds Global X S&P 500 Tail Risk ETF) Start Date:2021-08-26
XTRE (Bondbloxx ETF Trust Bondbloxx Bloomberg Three Year Target Dura) Start Date:2022-09-15
XTWO (Bondbloxx ETF Trust Bondbloxx Bloomberg Two Year Target Durati) Start Date:2022-09-15
XTWY (Bondbloxx ETF Trust Bondbloxx Bloomberg Twenty Year Target Dur) Start Date:2022-09-15
XUDV (Franklin Templeton ETF Trust Franklin U.S. Dividend Multiplier) Start Date:2025-01-23
XUSP (Innovator ETFs Trust Innovator Uncapped Accelerated Us Equit) Start Date:2022-08-11
XVOL (Acruence Active Hedge U.S. Equity ETF) Start Date:2021-04-22
XVV (iShares ESG Screened S&P 500 ETF) Start Date:2020-09-24
XWEB (SPDR S&P Internet ETF) Start Date:2016-06-28
XXCH (Direxion Shares ETF Trust Direxion Daily MSCI Emerging Markets) Start Date:2024-02-07
XYLD (Global X S&P 500 Covered Call ETF) Start Date:2013-06-24
XYLE (Global X Funds Global X S&P 500 ESG Covered Call ETF) Start Date:2023-02-23
XYLG (Global X S&P 500 Covered Call & Growth ETF) Start Date:2020-09-21
XYZY (Tidal Trust Ii Yieldmax Xyz Option Income Strategy ETF) Start Date:2025-04-01
YALL (Tidal ETF Trust God Bless America ETF) Start Date:2022-10-11
YANG (Direxion Daily FTSE China Bear 3X Shares) Start Date:2009-12-03
YBIT (Tidal Trust Ii Yieldmax Bitcoin Option Income Strategy ETF) Start Date:2024-04-23
YBTC (Roundhill ETF Trust Roundhill Bitcoin Covered Call Strategy Et) Start Date:2024-01-18
YCL (ProShares Ultra Yen) Start Date:2008-11-25
YCS (ProShares Ultrashort Yen New) Start Date:2008-11-25
YDEC (FTCboe Vest International Equity Buffer ETF - December) Start Date:2020-12-21
YEAR (Ab Active ETFs Ab Ultra Short Income ETF) Start Date:2022-09-14
YFFI (Spinnaker ETF Series Indexperts Yield Focused Fixed Income ETF) Start Date:2025-01-02
YFYA (Yields For You Income Strategy A ETF) Start Date:2025-01-31
YGLD (Simplify Exchange Traded Funds Simplify Gold Strategy Plus Inc) Start Date:2024-12-03
YINN (Direxion Daily FTSE China Bull 3X Shares) Start Date:2009-12-03
YLD (Principal Active Income ETF) Start Date:2015-07-09
YLDE (Clearbridge Dividend Strategy ESG ETF) Start Date:2017-05-23
YMAG (Tidal Trust Ii Yieldmax Magnificent 7 Fund Of Option Income Et) Start Date:2024-01-30
YMAR (FTCboe Vest International Equity Buffer ETF - March) Start Date:2021-03-22
YMAX (Tidal Trust Ii Yieldmax Universe Fund Of Option Income ETFs) Start Date:2024-01-17
YOKE (Yoke Core ETF) Start Date:2025-02-24
YOLO (AdvisorShares Pure Cannabis ETF) Start Date:2019-04-18
YPS (Arrow Reverse Cap 500 ETF) Start Date:2021-05-24
YQQQ (Yieldmax Short N100 Option Income Strategy ETF) Start Date:2024-08-15
YSEP (FTCboe Vest International Equity Buffer ETF - September) Start Date:2021-09-20
YSPY (Graniteshares Yieldboost Spy ETF) Start Date:2025-04-03
YXI (ProShares Short FTSE China 50) Start Date:2010-03-18
YYY (Amplify High Income ETF) Start Date:2013-06-21
ZALT (Innovator ETFs Trust Innovator Us Equity 10 Buffer ETF - Qua) Start Date:2023-10-02
ZAP (Global X U.S. Electrification ETF) Start Date:2024-12-18
ZAUG (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2024-08-01
ZDEK (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2024-12-02
ZECP (Zacks Trust Zacks Earnings Consistent Portfolio ETF) Start Date:2021-08-24
ZFEB (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2025-02-03
ZHDG (Zega Buy And Hedge ETF) Start Date:2021-07-07
ZIG (The Acquirers Fund) Start Date:2019-05-15
ZIPP (Stkd 100% Uber & 100% Tsla ETF) Start Date:2025-03-06
ZIVB (-1X Short VIX Mid-Term Futures Strategy ETF -1X Short VIX Mid-) Start Date:2023-04-19
ZJAN (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2025-01-02
ZJUL (Shl Telemedicine Innovator Equity Defined Protection ETF) Start Date:2024-07-01
ZMAR (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2025-03-03
ZNOV (Innovator ETFs Trust Innovator Equity Defined Protection ETF) Start Date:2024-11-01
ZOCT (Innovator Equity Defined Protection ETF - 1 Yr October) Start Date:2024-10-01
ZROZ (Pimco 25+ Year Zero Coupon Us Treasury) Start Date:2009-11-04
ZSB (Uscf ETF Trust Uscf Sustainable Battery Metals Strategy Fund) Start Date:2023-01-13
ZSC (Uscf ETF Trust Uscf Sustainable Commodity Strategy Fund) Start Date:2023-09-19
ZSEP (Innovator U.S. Small Cap Power Buffer ETF) Start Date:2024-09-03
ZSL (ProShares Ultrashort Silver) Start Date:2008-12-03
ZTAX (X-Square Series Trust X-Square Municipal Income Tax Free ETF) Start Date:2023-05-19
ZTEN (The Rbb Fund F/M 10-Year Investment Grade Corporate Bond) Start Date:2024-01-11
ZTRE (The Rbb Fund F/M 3-Year Investment Grade Corporate Bond) Start Date:2024-01-11
ZTWO (The Rbb Fund F/M 2-Year Investment Grade Corporate Bond) Start Date:2024-01-11
ZVOL (Volatility Premium Plus ETF) Start Date:2024-11-22
ZZZ (Cyber Hornet S&P 500 And Bitcoin 75/25 Strategy ETF) Start Date:2010-01-11

